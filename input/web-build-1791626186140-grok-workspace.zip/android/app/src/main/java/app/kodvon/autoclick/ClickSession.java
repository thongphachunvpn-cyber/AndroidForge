package app.kodvon.autoclick;

import java.util.Locale;

/**
 * Click-loop rules with no Android dependencies, so a late gesture callback
 * cannot restart a stopped run and two callbacks cannot schedule two loops.
 */
public final class ClickSession {
    public static final int GESTURE_TIMEOUT_MS = 800;
    public static final int MIN_GAP_MS = 20;

    public static final int[] INTERVALS = {100, 200, 300, 500, 700, 1000, 1500, 2000, 3000, 5000};
    public static final int[] DURATIONS = {0, 60_000, 300_000, 1_800_000};

    private boolean running;
    private boolean inFlight;
    private int generation;
    private int clicks;
    private long deadlineElapsed;

    public boolean isRunning() {
        return running;
    }

    public boolean isInFlight() {
        return inFlight;
    }

    public int generation() {
        return generation;
    }

    public int clicks() {
        return clicks;
    }

    public long deadlineElapsed() {
        return deadlineElapsed;
    }

    /** @return false when a run is already active, so a second loop is not started */
    public boolean start(long nowElapsed, int durationMs) {
        if (running) return false;
        generation++;
        clicks = 0;
        inFlight = false;
        running = true;
        applyDuration(nowElapsed, durationMs);
        return true;
    }

    public void stop() {
        running = false;
        inFlight = false;
        deadlineElapsed = 0L;
        generation++;
    }

    public void applyDuration(long nowElapsed, int durationMs) {
        int duration = clampDuration(durationMs);
        deadlineElapsed = duration > 0 ? nowElapsed + duration : 0L;
    }

    public boolean expired(long nowElapsed) {
        return running && deadlineElapsed > 0L && nowElapsed >= deadlineElapsed;
    }

    public long remainingMs(long nowElapsed) {
        if (!running || deadlineElapsed <= 0L) return 0L;
        return Math.max(0L, deadlineElapsed - nowElapsed);
    }

    /** @return generation token for this gesture, or -1 if a gesture must not start */
    public int beginGesture() {
        if (!running || inFlight) return -1;
        inFlight = true;
        return generation;
    }

    /**
     * Accepts one gesture result. A matching successful gesture increments the
     * counter. The twin timeout or a late callback from an older run returns false.
     *
     * @return true when the caller should schedule the next tap
     */
    public boolean onGestureResult(int gen, boolean ok) {
        if (gen != generation || !inFlight) return false;
        if (ok && running) clicks++;
        return release(gen);
    }

    /** Unsticks a gesture that never called back. Does not count a tap. */
    public boolean onGestureTimeout(int gen) {
        if (gen != generation || !inFlight) return false;
        return release(gen);
    }

    /** Drops a gesture that was invalidated before it was dispatched. */
    public void cancelGesture(int gen) {
        if (gen != generation || !inFlight) return;
        inFlight = false;
        generation++;
    }

    private boolean release(int gen) {
        if (gen != generation || !inFlight) return false;
        inFlight = false;
        generation++;
        return running;
    }

    public static int clampInterval(int value) {
        return nearest(INTERVALS, value, 500);
    }

    public static int clampDuration(int value) {
        return nearest(DURATIONS, value, 300_000);
    }

    public static int stepInterval(int current, int direction) {
        int clamped = clampInterval(current);
        int index = 0;
        for (int i = 0; i < INTERVALS.length; i++) {
            if (INTERVALS[i] == clamped) index = i;
        }
        int next = Math.max(0, Math.min(INTERVALS.length - 1, index + direction));
        return INTERVALS[next];
    }

    public static long nextDelayMs(int intervalMs, long spentMs, boolean succeeded) {
        long interval = clampInterval(intervalMs);
        if (!succeeded) return interval;
        long spent = Math.max(0L, spentMs);
        return Math.max(MIN_GAP_MS, interval - spent);
    }

    public static String intervalLabel(int ms) {
        int value = clampInterval(ms);
        if (value % 1000 == 0) return "ทุก " + (value / 1000) + " วินาที";
        return String.format(Locale.US, "ทุก %.1f วินาที", value / 1000.0);
    }

    public static String durationLabel(int ms) {
        int value = clampDuration(ms);
        if (value <= 0) return "ไม่จำกัด";
        if (value % 60_000 == 0) return (value / 60_000) + " นาที";
        return (value / 1000) + " วินาที";
    }

    /** Ceil to the next second so a fresh minute reads 1:00, not 0:59. */
    public static String remainingLabel(long ms) {
        long sec = Math.max(0L, (ms + 999L) / 1000L);
        return String.format(Locale.US, "%d:%02d", sec / 60, sec % 60);
    }

    private static int nearest(int[] options, int value, int fallback) {
        int best = fallback;
        long bestDiff = Long.MAX_VALUE;
        for (int candidate : options) {
            long diff = Math.abs((long) candidate - value);
            if (diff < bestDiff) {
                best = candidate;
                bestDiff = diff;
            }
        }
        return best;
    }
}
