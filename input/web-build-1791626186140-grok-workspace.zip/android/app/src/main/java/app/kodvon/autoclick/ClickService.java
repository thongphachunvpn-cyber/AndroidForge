package app.kodvon.autoclick;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Dispatches a single tap at a point the user chose. It does not read the
 * screen and does not observe accessibility events.
 */
public class ClickService extends AccessibilityService {
    public interface Done {
        void onDone(boolean ok);
    }

    public interface ConnectionListener {
        void onConnectionChanged(boolean connected);

        void onInterrupted();
    }

    private static ClickService instance;
    private static ConnectionListener listener;
    private final Handler main = new Handler(Looper.getMainLooper());

    public static ClickService get() {
        return instance;
    }

    public static void setConnectionListener(ConnectionListener next) {
        listener = next;
    }

    @Override
    protected void onServiceConnected() {
        instance = this;
        super.onServiceConnected();
        notifyConnection(true);
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        if (instance == this) instance = null;
        notifyConnection(false);
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        notifyConnection(false);
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Gestures do not need window content. Events are ignored on purpose.
    }

    @Override
    public void onInterrupt() {
        ConnectionListener current = listener;
        if (current == null) return;
        main.post(current::onInterrupted);
    }

    public void tap(float x, float y, Done done) {
        if (done == null) return;
        if (Float.isNaN(x) || Float.isNaN(y) || Float.isInfinite(x) || Float.isInfinite(y)) {
            done.onDone(false);
            return;
        }
        Path path = new Path();
        path.moveTo(x, y);
        // A 1px stroke is a tap. A zero-length path is dropped on some devices.
        path.lineTo(x + 1f, y + 1f);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 40);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        AtomicBoolean finished = new AtomicBoolean(false);
        Done once = ok -> {
            if (finished.compareAndSet(false, true)) done.onDone(ok);
        };
        boolean sent;
        try {
            sent = dispatchGesture(gesture, new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gestureDescription) {
                    once.onDone(true);
                }

                @Override
                public void onCancelled(GestureDescription gestureDescription) {
                    once.onDone(false);
                }
            }, null);
        } catch (RuntimeException ex) {
            once.onDone(false);
            return;
        }
        if (!sent) once.onDone(false);
    }

    private void notifyConnection(boolean connected) {
        ConnectionListener current = listener;
        if (current == null) return;
        main.post(() -> current.onConnectionChanged(connected));
    }
}
