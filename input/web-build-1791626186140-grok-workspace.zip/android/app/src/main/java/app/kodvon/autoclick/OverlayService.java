package app.kodvon.autoclick;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentCallbacks;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    public static final String ACTION_STOP = "app.kodvon.autoclick.STOP";
    private static final String CHANNEL = "kodvon";
    private static final int NOTIF_ID = 7;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ClickSession session = new ClickSession();
    private Prefs prefs;
    private WindowManager wm;
    private View root;
    private WindowManager.LayoutParams params;
    private FrameLayout bubble;
    private View dot;
    private TextView countdown;
    private TextView coord;
    private TextView status;
    private TextView intervalLabel;
    private View panel;
    private Button startBtn;
    private Button stopBtn;

    private boolean dragging;
    private boolean passing;
    private boolean foregroundStarted;
    private int anchorX;
    private int anchorY;
    private int insetX;
    private int insetY;
    private int layoutGen;
    private boolean clickScheduled;
    private long lastNotificationAt;

    private final Runnable longPress = () -> {
        if (!dragging && session.isRunning()) stopClicking(getString(R.string.stopped_long_press));
    };

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (!session.isRunning()) return;
            if (!Settings.canDrawOverlays(OverlayService.this)) {
                stopClicking(getString(R.string.stopped_overlay));
                stopSelf();
                return;
            }
            if (ClickService.get() == null) {
                stopClicking(getString(R.string.stopped_access));
                return;
            }
            long now = SystemClock.elapsedRealtime();
            if (session.expired(now)) {
                stopClicking(getString(R.string.stopped_time));
                return;
            }
            renderRunState();
            if (!session.isInFlight() && !clickScheduled && !dragging) {
                scheduleClick(0);
            }
            if (now - lastNotificationAt > 1000L) publishNotification(false);
            handler.postDelayed(this, 250);
        }
    };

    private final Runnable clickLoop = () -> {
        clickScheduled = false;
        fireClick();
    };

    private final ClickService.ConnectionListener connectionListener = new ClickService.ConnectionListener() {
        @Override
        public void onConnectionChanged(boolean connected) {
            if (!connected && session.isRunning()) {
                stopClicking(getString(R.string.stopped_access));
            }
        }

        @Override
        public void onInterrupted() {
            if (session.isRunning()) stopClicking(getString(R.string.stopped_interrupt));
        }
    };

    private final ComponentCallbacks componentCallbacks = new ComponentCallbacks() {
        @Override
        public void onConfigurationChanged(Configuration newConfig) {
            handler.post(() -> {
                if (root == null) return;
                clampAnchor();
                layoutChrome();
            });
        }

        @Override
        public void onLowMemory() {
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = new Prefs(this);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
        ClickService.setConnectionListener(connectionListener);
        getApplicationContext().registerComponentCallbacks(componentCallbacks);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // A foreground service must call startForeground before any early return.
        if (!enterForeground()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopClicking(getString(R.string.stopped_notification));
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            stopClicking(getString(R.string.stopped_overlay));
            stopForeground(STOP_FOREGROUND_REMOVE);
            foregroundStarted = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        if (root == null) attach();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        session.stop();
        clickScheduled = false;
        handler.removeCallbacksAndMessages(null);
        ClickService.setConnectionListener(null);
        try {
            getApplicationContext().unregisterComponentCallbacks(componentCallbacks);
        } catch (RuntimeException ignored) {
        }
        if (root != null) {
            try {
                wm.removeView(root);
            } catch (RuntimeException ignored) {
            }
            root = null;
        }
        if (foregroundStarted) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            foregroundStarted = false;
        }
        super.onDestroy();
    }

    private void attach() {
        root = View.inflate(this, R.layout.overlay_hud, null);
        bubble = root.findViewById(R.id.bubble);
        dot = root.findViewById(R.id.dot);
        countdown = root.findViewById(R.id.countdown);
        coord = root.findViewById(R.id.coord);
        status = root.findViewById(R.id.status);
        intervalLabel = root.findViewById(R.id.interval_label);
        panel = root.findViewById(R.id.panel);
        startBtn = root.findViewById(R.id.start);
        stopBtn = root.findViewById(R.id.stop);

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                baseFlags(),
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 30) {
            params.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        } else if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        if (prefs.placed()) {
            anchorX = prefs.x();
            anchorY = prefs.y();
        } else {
            int[] size = screen();
            anchorX = Math.max(0, (size[0] - dp(64)) / 2);
            anchorY = Math.max(0, size[1] / 3);
        }
        clampAnchor();
        params.x = anchorX;
        params.y = anchorY;
        wm.addView(root, params);

        bubble.setOnTouchListener(this::onBubbleTouch);
        root.findViewById(R.id.interval_minus).setOnClickListener(v -> changeInterval(-1));
        root.findViewById(R.id.interval_plus).setOnClickListener(v -> changeInterval(1));
        wireDuration(R.id.dur_0, 0);
        wireDuration(R.id.dur_1, 60_000);
        wireDuration(R.id.dur_5, 300_000);
        wireDuration(R.id.dur_30, 1_800_000);
        startBtn.setOnClickListener(v -> startClicking());
        stopBtn.setOnClickListener(v -> stopClicking(getString(R.string.stopped_user)));
        root.findViewById(R.id.hide).setOnClickListener(v -> {
            stopClicking(getString(R.string.stopped_hide));
            stopForeground(STOP_FOREGROUND_REMOVE);
            foregroundStarted = false;
            stopSelf();
        });
        refreshPanel();
        layoutChrome();
    }

    private boolean onBubbleTouch(View v, MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = false;
                v.setTag(R.id.bubble, new float[]{
                        event.getRawX(), event.getRawY(), anchorX, anchorY
                });
                handler.postDelayed(longPress, 500);
                return true;
            case MotionEvent.ACTION_MOVE:
                float[] origin = (float[]) v.getTag(R.id.bubble);
                if (origin == null || params == null) return true;
                float dx = event.getRawX() - origin[0];
                float dy = event.getRawY() - origin[1];
                if (Math.hypot(dx, dy) > dp(8)) {
                    dragging = true;
                    handler.removeCallbacks(longPress);
                }
                if (dragging) {
                    anchorX = Math.round(origin[2] + dx);
                    anchorY = Math.round(origin[3] + dy);
                    clampAnchor();
                    params.x = anchorX - insetX;
                    params.y = anchorY - insetY;
                    try {
                        wm.updateViewLayout(root, params);
                    } catch (RuntimeException ignored) {
                    }
                    prefs.position(anchorX, anchorY);
                    updateCoord();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPress);
                boolean wasDragging = dragging;
                dragging = false;
                if (!wasDragging && event.getActionMasked() == MotionEvent.ACTION_UP) {
                    panel.setVisibility(panel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                    refreshPanel();
                    layoutChrome();
                } else if (wasDragging) {
                    layoutChrome();
                }
                return true;
            default:
                return false;
        }
    }

    private void wireDuration(int id, int value) {
        root.findViewById(id).setOnClickListener(v -> {
            prefs.duration(value);
            if (session.isRunning()) {
                session.applyDuration(SystemClock.elapsedRealtime(), value);
            }
            refreshPanel();
            layoutChrome();
        });
    }

    private void changeInterval(int direction) {
        prefs.interval(Prefs.stepInterval(prefs.interval(), direction));
        refreshPanel();
    }

    private void startClicking() {
        if (session.isRunning()) return;
        if (ClickService.get() == null) {
            status.setText(R.string.access_needed);
            panel.setVisibility(View.VISIBLE);
            layoutChrome();
            try {
                Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } catch (RuntimeException ex) {
                status.setText(R.string.access_settings_failed);
            }
            return;
        }
        if (!session.start(SystemClock.elapsedRealtime(), prefs.duration())) return;
        panel.setVisibility(View.GONE);
        renderRunState();
        layoutChrome();
        publishNotification(true);
        handler.removeCallbacks(ticker);
        handler.post(ticker);
        scheduleClick(0);
    }

    private void stopClicking(String reason) {
        boolean was = session.isRunning();
        int count = session.clicks();
        session.stop();
        clickScheduled = false;
        handler.removeCallbacks(clickLoop);
        handler.removeCallbacks(ticker);
        handler.removeCallbacks(longPress);
        setPassThrough(false);
        if (status != null) {
            status.setText(was
                    ? getString(R.string.stopped_with_count, reason, count)
                    : getString(R.string.ready, Prefs.durationLabel(prefs.duration())));
        }
        renderRunState();
        if (foregroundStarted) publishNotification(true);
    }

    private void fireClick() {
        if (!session.isRunning()) return;
        if (dragging) {
            scheduleClick(40);
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (session.expired(now)) {
            stopClicking(getString(R.string.stopped_time));
            return;
        }
        if (ClickService.get() == null) {
            stopClicking(getString(R.string.stopped_access));
            return;
        }
        if (session.isInFlight() || bubble == null) return;
        final int gen = session.beginGesture();
        if (gen < 0) return;
        // Apply NOT_TOUCHABLE one frame before the gesture so the bubble does not eat it.
        setPassThrough(true);
        handler.post(() -> dispatchTap(gen));
    }

    private void dispatchTap(int gen) {
        if (gen != session.generation() || !session.isRunning() || bubble == null) {
            setPassThrough(false);
            return;
        }
        if (dragging) {
            session.cancelGesture(gen);
            setPassThrough(false);
            scheduleClick(40);
            return;
        }
        ClickService service = ClickService.get();
        if (service == null) {
            session.cancelGesture(gen);
            setPassThrough(false);
            stopClicking(getString(R.string.stopped_access));
            return;
        }
        int[] loc = new int[2];
        bubble.getLocationOnScreen(loc);
        float x = loc[0] + bubble.getWidth() / 2f;
        float y = loc[1] + bubble.getHeight() / 2f;
        final long started = SystemClock.elapsedRealtime();
        Runnable timeout = () -> settle(gen, false, started, true);
        handler.postDelayed(timeout, ClickSession.GESTURE_TIMEOUT_MS);
        try {
            service.tap(x, y, ok -> handler.post(() -> {
                handler.removeCallbacks(timeout);
                settle(gen, ok, started, false);
            }));
        } catch (RuntimeException ex) {
            handler.removeCallbacks(timeout);
            settle(gen, false, started, false);
        }
    }

    private void settle(int gen, boolean ok, long started, boolean timedOut) {
        boolean schedule = timedOut
                ? session.onGestureTimeout(gen)
                : session.onGestureResult(gen, ok);
        if (!schedule) return;
        setPassThrough(false);
        renderRunState();
        if (!session.isRunning()) return;
        if (session.expired(SystemClock.elapsedRealtime())) {
            stopClicking(getString(R.string.stopped_time));
            return;
        }
        long spent = SystemClock.elapsedRealtime() - started;
        scheduleClick(ClickSession.nextDelayMs(prefs.interval(), spent, ok && !timedOut));
    }

    private void scheduleClick(long delay) {
        if (!session.isRunning()) return;
        handler.removeCallbacks(clickLoop);
        clickScheduled = true;
        handler.postDelayed(clickLoop, Math.max(0L, delay));
    }

    private void refreshPanel() {
        if (root == null) return;
        updateCoord();
        intervalLabel.setText(Prefs.intervalLabel(prefs.interval()));
        int duration = prefs.duration();
        paintChip(R.id.dur_0, duration == 0);
        paintChip(R.id.dur_1, duration == 60_000);
        paintChip(R.id.dur_5, duration == 300_000);
        paintChip(R.id.dur_30, duration == 1_800_000);
        if (!session.isRunning()) {
            status.setText(getString(R.string.ready, Prefs.durationLabel(duration)));
        }
        renderRunState();
    }

    private void renderRunState() {
        if (root == null) return;
        boolean running = session.isRunning();
        bubble.setBackgroundResource(running ? R.drawable.bubble_run : R.drawable.bubble_idle);
        dot.setBackgroundResource(running ? R.drawable.dot_run : R.drawable.dot_idle);
        startBtn.setEnabled(!running);
        startBtn.setAlpha(running ? 0.45f : 1f);
        stopBtn.setEnabled(running);
        stopBtn.setAlpha(running ? 1f : 0.45f);
        if (!running) {
            countdown.setVisibility(View.GONE);
            return;
        }
        countdown.setVisibility(View.VISIBLE);
        int count = session.clicks();
        if (session.deadlineElapsed() > 0L) {
            countdown.setText(getString(
                    R.string.countdown_limited,
                    Prefs.remainingLabel(session.remainingMs(SystemClock.elapsedRealtime())),
                    count));
        } else {
            countdown.setText(getString(R.string.countdown_unlimited, count));
        }
    }

    private void updateCoord() {
        if (bubble == null) return;
        if (bubble.getWidth() == 0) {
            bubble.post(this::updateCoord);
            return;
        }
        int x = anchorX + bubble.getWidth() / 2;
        int y = anchorY + bubble.getHeight() / 2;
        coord.setText(getString(R.string.coord, x, y));
    }

    private void paintChip(int id, boolean on) {
        Button button = root.findViewById(id);
        button.setBackgroundResource(on ? R.drawable.chip_on : R.drawable.chip);
        button.setTextColor(on ? 0xFFD6FF4A : 0xFFB7C2B8);
    }

    private void setPassThrough(boolean pass) {
        if (root == null || params == null || passing == pass) return;
        passing = pass;
        params.flags = baseFlags() | (pass ? WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE : 0);
        try {
            wm.updateViewLayout(root, params);
        } catch (RuntimeException ignored) {
        }
    }

    private int baseFlags() {
        return WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
    }

    private void clampAnchor() {
        int[] size = screen();
        int bubbleW = bubble != null && bubble.getWidth() > 0 ? bubble.getWidth() : dp(64);
        int bubbleH = bubble != null && bubble.getHeight() > 0 ? bubble.getHeight() : dp(64);
        anchorX = Math.max(0, Math.min(Math.max(0, size[0] - bubbleW), anchorX));
        anchorY = Math.max(0, Math.min(Math.max(0, size[1] - bubbleH), anchorY));
    }

    private void layoutChrome() {
        if (root == null || params == null || !(root instanceof LinearLayout)) return;
        final int token = ++layoutGen;
        boolean panelOn = panel.getVisibility() == View.VISIBLE;
        int[] size = screen();
        int bubbleW = dp(64);
        int bubbleH = dp(64);
        int panelW = dp(240);
        int panelH = dp(420);
        int countH = countdown.getVisibility() == View.VISIBLE ? dp(28) : 0;
        int shiftX = 0;
        if (panelOn) {
            int overflow = anchorX + panelW - size[0];
            if (overflow > 0) shiftX = Math.min(Math.max(0, anchorX), overflow);
        }
        int needBelow = bubbleH + countH + (panelOn ? panelH : 0);
        int spaceBelow = size[1] - anchorY;
        boolean above = panelOn && needBelow > spaceBelow && anchorY > spaceBelow;
        setLeftMargin(bubble, shiftX);
        setLeftMargin(countdown, shiftX);
        setLeftMargin(panel, 0);
        placePanel(above);
        try {
            wm.updateViewLayout(root, params);
        } catch (RuntimeException ignored) {
        }
        root.post(() -> {
            if (token != layoutGen || root == null || bubble.getWidth() == 0) return;
            int[] loc = new int[2];
            bubble.getLocationOnScreen(loc);
            int dx = anchorX - loc[0];
            int dy = anchorY - loc[1];
            if (dx != 0 || dy != 0) {
                params.x += dx;
                params.y += dy;
                try {
                    wm.updateViewLayout(root, params);
                } catch (RuntimeException ignored) {
                }
            }
            insetX = anchorX - params.x;
            insetY = anchorY - params.y;
            updateCoord();
        });
    }

    private void placePanel(boolean above) {
        if (!(root instanceof LinearLayout)) return;
        LinearLayout column = (LinearLayout) root;
        int panelIndex = column.indexOfChild(panel);
        int bubbleIndex = column.indexOfChild(bubble);
        if (panelIndex < 0 || bubbleIndex < 0) return;
        boolean isAbove = panelIndex < bubbleIndex;
        if (above == isAbove) return;
        column.removeView(panel);
        bubbleIndex = column.indexOfChild(bubble);
        column.addView(panel, above ? bubbleIndex : column.getChildCount());
    }

    private void setLeftMargin(View view, int margin) {
        ViewGroup.LayoutParams raw = view.getLayoutParams();
        if (!(raw instanceof ViewGroup.MarginLayoutParams)) return;
        ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) raw;
        if (lp.leftMargin == margin) return;
        lp.leftMargin = margin;
        view.setLayoutParams(lp);
    }

    @SuppressWarnings("deprecation")
    private int[] screen() {
        if (Build.VERSION.SDK_INT >= 30) {
            android.graphics.Rect bounds = wm.getMaximumWindowMetrics().getBounds();
            return new int[]{bounds.width(), bounds.height()};
        }
        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return new int[]{dm.widthPixels, dm.heightPixels};
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW);
        channel.setDescription(getString(R.string.channel_desc));
        channel.setSound(null, null);
        channel.enableVibration(false);
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private boolean enterForeground() {
        return publishNotification(true);
    }

    private boolean publishNotification(boolean foreground) {
        Notification notification = buildNotification();
        try {
            if (foreground || !foregroundStarted) {
                if (Build.VERSION.SDK_INT >= 34) {
                    startForeground(
                            NOTIF_ID,
                            notification,
                            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
                } else {
                    startForeground(NOTIF_ID, notification);
                }
                foregroundStarted = true;
            } else {
                NotificationManager manager = getSystemService(NotificationManager.class);
                if (manager != null) manager.notify(NOTIF_ID, notification);
            }
            lastNotificationAt = SystemClock.elapsedRealtime();
            return true;
        } catch (RuntimeException ex) {
            foregroundStarted = false;
            return false;
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(this, CHANNEL);
        boolean running = session.isRunning();
        String text = running
                ? getString(R.string.notif_running, session.clicks())
                : getString(R.string.notif_idle);
        builder.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(text)
                .setContentIntent(content)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE);
        if (running) {
            Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
            PendingIntent stopPi = PendingIntent.getService(
                    this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            builder.addAction(android.R.drawable.ic_media_pause, getString(R.string.notif_stop), stopPi);
        }
        return builder.build();
    }
}
