package app.kodvon.autoclick;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_NOTIF = 41;

    private boolean notifPrompted;
    private TextView message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        message = findViewById(R.id.message);
        applyEdgeToEdge(findViewById(R.id.root_scroll));
        findViewById(R.id.btn_overlay).setOnClickListener(v -> requestOverlay());
        findViewById(R.id.btn_access).setOnClickListener(v -> openAccessibility());
        findViewById(R.id.btn_show).setOnClickListener(v -> showBubble());
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        View scroll = findViewById(R.id.root_scroll);
        if (scroll != null) scroll.requestApplyInsets();
    }

    @Override
    protected void onResume() {
        super.onResume();
        TextView overlay = findViewById(R.id.status_overlay);
        TextView access = findViewById(R.id.status_access);
        boolean over = Settings.canDrawOverlays(this);
        boolean acc = accessibilityOn();
        overlay.setText(over ? R.string.status_on : R.string.status_off);
        overlay.setTextColor(over ? 0xFFD6FF4A : 0xFFFFB15A);
        access.setText(acc ? R.string.status_on : R.string.status_off);
        access.setTextColor(acc ? 0xFFD6FF4A : 0xFFFFB15A);
        Button show = findViewById(R.id.btn_show);
        show.setEnabled(over);
        show.setAlpha(over ? 1f : 0.4f);
        if (!over) {
            showMessage(getString(R.string.overlay_needed));
        } else if (!acc) {
            showMessage(getString(R.string.access_needed_home));
        } else {
            showMessage("");
        }
    }

    private boolean accessibilityOn() {
        try {
            int enabledFlag = Settings.Secure.getInt(
                    getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 0);
            if (enabledFlag != 1) return false;
        } catch (RuntimeException ex) {
            return false;
        }
        String enabled = Settings.Secure.getString(
                getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null || enabled.isEmpty()) return false;
        String id = new ComponentName(this, ClickService.class).flattenToString();
        for (String part : enabled.split(":")) {
            if (id.equalsIgnoreCase(part.trim())) return true;
        }
        return false;
    }

    private void requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            showMessage(getString(R.string.overlay_already));
            return;
        }
        try {
            Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (RuntimeException ex) {
            showMessage(getString(R.string.overlay_settings_failed));
        }
    }

    private void openAccessibility() {
        try {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            String id = new ComponentName(this, ClickService.class).flattenToString();
            Bundle args = new Bundle();
            args.putString(":settings:fragment_args_key", id);
            intent.putExtra(":settings:fragment_args_key", id);
            intent.putExtra(":settings:show_fragment_args", args);
            startActivity(intent);
        } catch (RuntimeException ex) {
            showMessage(getString(R.string.access_settings_failed));
        }
    }

    private void showBubble() {
        if (!Settings.canDrawOverlays(this)) {
            showMessage(getString(R.string.overlay_needed));
            requestOverlay();
            return;
        }
        if (needsNotificationPrompt()) {
            notifPrompted = true;
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        startOverlay();
    }

    private boolean needsNotificationPrompt() {
        if (Build.VERSION.SDK_INT < 33 || notifPrompted) return false;
        return checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED;
    }

    private void startOverlay() {
        try {
            startForegroundService(new Intent(this, OverlayService.class));
            showMessage(getString(R.string.bubble_shown));
        } catch (RuntimeException ex) {
            showMessage(getString(R.string.bubble_failed));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_NOTIF) return;
        boolean granted = grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (!granted) showMessage(getString(R.string.notif_denied));
        if (Settings.canDrawOverlays(this)) startOverlay();
    }

    private void showMessage(String text) {
        if (message == null) return;
        if (text == null || text.isEmpty()) {
            message.setVisibility(View.GONE);
            message.setText("");
            return;
        }
        message.setVisibility(View.VISIBLE);
        message.setText(text);
    }

    @SuppressWarnings("deprecation")
    private void applyEdgeToEdge(View scroll) {
        if (scroll == null || Build.VERSION.SDK_INT < 30) return;
        getWindow().setDecorFitsSystemWindows(false);
        getWindow().setStatusBarColor(0x00000000);
        getWindow().setNavigationBarColor(0x00000000);
        WindowInsetsController controller = getWindow().getInsetsController();
        if (controller != null) {
            controller.setSystemBarsAppearance(
                    0,
                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        }
        scroll.setOnApplyWindowInsetsListener((view, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });
        scroll.requestApplyInsets();
    }
}
