package app.kodvon.autoclick;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    public static final int[] INTERVALS = ClickSession.INTERVALS;
    public static final int[] DURATIONS = ClickSession.DURATIONS;

    private final SharedPreferences sp;

    public Prefs(Context context) {
        sp = context.getApplicationContext().getSharedPreferences("kodvon", Context.MODE_PRIVATE);
    }

    public int interval() {
        return ClickSession.clampInterval(sp.getInt("interval", 500));
    }

    public void interval(int value) {
        sp.edit().putInt("interval", ClickSession.clampInterval(value)).apply();
    }

    public int duration() {
        return ClickSession.clampDuration(sp.getInt("duration", 300_000));
    }

    public void duration(int value) {
        sp.edit().putInt("duration", ClickSession.clampDuration(value)).apply();
    }

    public boolean placed() {
        return sp.getBoolean("placed", false);
    }

    public int x() {
        return sp.getInt("x", 0);
    }

    public int y() {
        return sp.getInt("y", 0);
    }

    public void position(int x, int y) {
        sp.edit().putInt("x", x).putInt("y", y).putBoolean("placed", true).apply();
    }

    public static int stepInterval(int current, int direction) {
        return ClickSession.stepInterval(current, direction);
    }

    public static String intervalLabel(int ms) {
        return ClickSession.intervalLabel(ms);
    }

    public static String durationLabel(int ms) {
        return ClickSession.durationLabel(ms);
    }

    public static String remainingLabel(long ms) {
        return ClickSession.remainingLabel(ms);
    }
}
