package app.kodvon.autoclick;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ClickSessionTest {
    @Test
    public void secondStartDoesNotResetOrDuplicate() {
        ClickSession session = new ClickSession();
        assertTrue(session.start(1_000L, 60_000));
        assertEquals(1, session.beginGesture());
        assertTrue(session.onGestureResult(1, true));
        assertEquals(1, session.clicks());
        assertFalse(session.start(2_000L, 60_000));
        assertEquals(1, session.clicks());
        assertTrue(session.isRunning());
    }

    @Test
    public void stopInvalidatesLateSuccess() {
        ClickSession session = new ClickSession();
        session.start(0L, 60_000);
        int gen = session.beginGesture();
        session.stop();
        assertFalse(session.onGestureResult(gen, true));
        assertEquals(0, session.clicks());
        assertFalse(session.isRunning());
        assertFalse(session.isInFlight());
    }

    @Test
    public void successAndTimeoutScheduleOnce() {
        ClickSession session = new ClickSession();
        session.start(0L, 0);
        int gen = session.beginGesture();
        assertTrue(session.onGestureResult(gen, true));
        assertEquals(1, session.clicks());
        assertFalse(session.onGestureTimeout(gen));
        assertEquals(1, session.clicks());
        assertFalse(session.isInFlight());
    }

    @Test
    public void timeoutDoesNotCountAndBlocksLateSuccess() {
        ClickSession session = new ClickSession();
        session.start(0L, 0);
        int gen = session.beginGesture();
        assertTrue(session.onGestureTimeout(gen));
        assertEquals(0, session.clicks());
        assertFalse(session.onGestureResult(gen, true));
        assertEquals(0, session.clicks());
    }

    @Test
    public void overlappingGestureIsRejected() {
        ClickSession session = new ClickSession();
        session.start(0L, 0);
        assertEquals(1, session.beginGesture());
        assertEquals(-1, session.beginGesture());
    }

    @Test
    public void cancelledGestureCannotComplete() {
        ClickSession session = new ClickSession();
        session.start(0L, 0);
        int gen = session.beginGesture();
        session.cancelGesture(gen);
        assertFalse(session.onGestureResult(gen, true));
        assertEquals(0, session.clicks());
        assertFalse(session.isInFlight());
    }

    @Test
    public void expiryUsesMonotonicDeadline() {
        ClickSession session = new ClickSession();
        session.start(1_000L, 60_000);
        assertFalse(session.expired(60_999L));
        assertTrue(session.expired(61_000L));
        assertEquals(1_000L, session.remainingMs(60_000L));
        session.applyDuration(60_000L, 0);
        assertFalse(session.expired(999_999L));
        assertEquals(0L, session.remainingMs(999_999L));
    }

    @Test
    public void failedGestureWaitsFullInterval() {
        assertEquals(100L, ClickSession.nextDelayMs(100, 0L, false));
        assertEquals(500L, ClickSession.nextDelayMs(500, 800L, false));
        assertEquals(20L, ClickSession.nextDelayMs(100, 90L, true));
        assertEquals(400L, ClickSession.nextDelayMs(500, 100L, true));
        assertEquals(100L, ClickSession.nextDelayMs(-5, 0L, false));
    }

    @Test
    public void intervalAndDurationAreBounded() {
        assertEquals(100, ClickSession.clampInterval(1));
        assertEquals(5000, ClickSession.clampInterval(99_000));
        assertEquals(500, ClickSession.clampInterval(500));
        assertEquals(300_000, ClickSession.clampDuration(600_000));
        assertEquals(0, ClickSession.clampDuration(-1));
        assertEquals(100, ClickSession.stepInterval(100, -1));
        assertEquals(200, ClickSession.stepInterval(100, 1));
        assertEquals(5000, ClickSession.stepInterval(5000, 1));
    }

    @Test
    public void labelsMatchTheControls() {
        assertEquals("ทุก 0.5 วินาที", ClickSession.intervalLabel(500));
        assertEquals("ทุก 1 วินาที", ClickSession.intervalLabel(1000));
        assertEquals("ไม่จำกัด", ClickSession.durationLabel(0));
        assertEquals("5 นาที", ClickSession.durationLabel(300_000));
        assertEquals("1:00", ClickSession.remainingLabel(60_000L));
        assertEquals("0:01", ClickSession.remainingLabel(1L));
        assertEquals("0:00", ClickSession.remainingLabel(0L));
    }
}
