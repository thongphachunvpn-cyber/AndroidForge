import { createFileRoute } from "@tanstack/react-router";
import { AutoConsole } from "@/components/auto-console";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <AutoConsole />;
}
