import { useEffect, useRef, useState } from "react";
import { Download, OctagonX, Play, Smartphone } from "lucide-react";
import { clsx } from "clsx";

const INTERVALS = [100, 200, 300, 500, 700, 1000, 1500, 2000, 3000, 5000];
const DURATIONS = [
  { ms: 0, label: "ไม่จำกัด" },
  { ms: 60_000, label: "1 นาที" },
  { ms: 300_000, label: "5 นาที" },
  { ms: 1_800_000, label: "30 นาที" },
];

function intervalLabel(ms: number) {
  if (ms % 1000 === 0) return `ทุก ${ms / 1000} วินาที`;
  return `ทุก ${(ms / 1000).toFixed(1)} วินาที`;
}

function clock(ms: number) {
  const sec = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`;
}

export function AutoConsole() {
  const stageRef = useRef<HTMLDivElement>(null);
  const bubbleRef = useRef<HTMLButtonElement>(null);
  const timer = useRef<number | null>(null);
  const deadline = useRef(0);
  const drag = useRef<{ dx: number; dy: number } | null>(null);
  const moved = useRef(false);

  const [pos, setPos] = useState({ x: 118, y: 168 });
  const [open, setOpen] = useState(false);
  const [running, setRunning] = useState(false);
  const [intervalMs, setIntervalMs] = useState(500);
  const [durationMs, setDurationMs] = useState(300_000);
  const [leftMs, setLeftMs] = useState(0);
  const [clicks, setClicks] = useState(0);
  const [reward, setReward] = useState(0);
  const [lamp, setLamp] = useState(false);
  const [note, setNote] = useState("ลากวงกลมไปจุดที่จะกด แล้วกดเริ่ม");
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);

  function stop(reason: string) {
    if (timer.current != null) window.clearInterval(timer.current);
    timer.current = null;
    setRunning(false);
    setNote(reason);
  }

  function tick() {
    const stage = stageRef.current;
    const bubble = bubbleRef.current;
    if (!stage || !bubble) return;
    if (deadline.current > 0 && Date.now() >= deadline.current) {
      stop("ครบเวลาที่ตั้งไว้ จึงหยุดเอง");
      return;
    }
    const stageBox = stage.getBoundingClientRect();
    const bubbleBox = bubble.getBoundingClientRect();
    const x = bubbleBox.left + bubbleBox.width / 2;
    const y = bubbleBox.top + bubbleBox.height / 2;
    const hit = document
      .elementsFromPoint(x, y)
      .find(
        (el) =>
          stage.contains(el) &&
          el !== bubble &&
          !bubble.contains(el) &&
          el instanceof HTMLElement &&
          el.dataset.hit,
      ) as HTMLElement | undefined;
    if (hit?.dataset.hit === "reward") setReward((n) => n + 1);
    if (hit?.dataset.hit === "lamp") setLamp((on) => !on);
    const id = Date.now();
    setRipples((items) => [
      ...items.slice(-5),
      { id, x: x - stageBox.left, y: y - stageBox.top },
    ]);
    window.setTimeout(() => {
      setRipples((items) => items.filter((item) => item.id !== id));
    }, 420);
    setClicks((n) => n + 1);
    if (deadline.current > 0) setLeftMs(deadline.current - Date.now());
  }

  function start() {
    if (timer.current != null) window.clearInterval(timer.current);
    setClicks(0);
    deadline.current = durationMs > 0 ? Date.now() + durationMs : 0;
    setLeftMs(durationMs);
    setRunning(true);
    setOpen(false);
    setNote(
      durationMs > 0
        ? "กำลังกดจุดที่วงกลมวางอยู่ จะหยุดเองเมื่อครบเวลา"
        : "กำลังกดจุดที่วงกลมวางอยู่ จะไม่หยุดจนกว่าจะกดหยุด",
    );
    timer.current = window.setInterval(tick, intervalMs);
    tick();
  }

  useEffect(() => {
    if (!running) return;
    if (timer.current != null) window.clearInterval(timer.current);
    timer.current = window.setInterval(tick, intervalMs);
    return () => {
      if (timer.current != null) window.clearInterval(timer.current);
    };
    // restart the cadence when the interval changes mid-run
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running, intervalMs]);

  useEffect(() => () => {
    if (timer.current != null) window.clearInterval(timer.current);
  }, []);

  function onPointerDown(event: React.PointerEvent<HTMLButtonElement>) {
    moved.current = false;
    drag.current = { dx: event.clientX - pos.x, dy: event.clientY - pos.y };
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function onPointerMove(event: React.PointerEvent<HTMLButtonElement>) {
    if (!drag.current || !stageRef.current) return;
    const bounds = stageRef.current.getBoundingClientRect();
    const maxX = bounds.width - 56;
    const maxY = bounds.height - 56;
    const next = {
      x: Math.min(maxX, Math.max(0, event.clientX - drag.current.dx)),
      y: Math.min(maxY, Math.max(0, event.clientY - drag.current.dy)),
    };
    if (Math.hypot(next.x - pos.x, next.y - pos.y) > 4) moved.current = true;
    setPos(next);
  }

  function stepInterval(direction: number) {
    const index = INTERVALS.findIndex((item) => item === intervalMs);
    const next = Math.min(INTERVALS.length - 1, Math.max(0, (index < 0 ? 3 : index) + direction));
    setIntervalMs(INTERVALS[next] ?? 500);
  }

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-6xl flex-col gap-4 px-4 py-4 sm:px-6 sm:py-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-mono text-xs tracking-widest text-lime">Android</p>
          <h1 className="text-balance text-3xl font-semibold tracking-tight sm:text-4xl">กดวน</h1>
          <p className="max-w-xl text-pretty text-sm text-fog">
            ปุ่มลอยสีดำอยู่เหนือแอปอื่น ลากไปจุดที่อยากให้แตะ แล้วกดเริ่ม ระบบแตะซ้ำจนคุณกดหยุดหรือครบเวลา
          </p>
        </div>
      </header>

      <section className="rounded-card border border-line bg-panel p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="flex-1">
            <h2 className="text-lg font-semibold">ไฟล์ติดตั้ง Android</h2>
            <p className="mt-1 text-sm text-pretty text-fog">
              ไฟล์นี้เป็นรุ่นทดสอบสำหรับติดตั้งเอง เซ็นด้วยคีย์ดีบัก ยังไม่ใช่ไฟล์ที่ลง Play Store ได้ เปิดบนมือถือแล้วอนุญาตให้ติดตั้งจากเบราว์เซอร์ถ้าเครื่องถาม iOS ติดตั้งไฟล์นี้ไม่ได้
            </p>
          </div>
          <a
            href="/kodvon-autoclick.apk"
            download="kodvon-autoclick.apk"
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-lime px-4 font-semibold text-lime-ink"
          >
            <Download className="size-5" />
            ดาวน์โหลด APK
          </a>
        </div>
        <ol className="mt-4 grid gap-2 text-sm sm:grid-cols-2">
          {[
            "ติดตั้งไฟล์ แล้วเปิดแอปกดวน",
            "เปิดสิทธิ์แสดงทับแอปอื่น",
            "เปิดกดวนในเมนูการช่วยเหลือ",
            "กดแสดงปุ่มลอย แล้วลากวงกลมไปจุดที่จะกด",
          ].map((step, index) => (
            <li key={step} className="flex gap-2 rounded-xl border border-line bg-ink px-3 py-2">
              <span className="font-mono text-lime">{index + 1}</span>
              <span>{step}</span>
            </li>
          ))}
        </ol>
      </section>

      <div className="grid items-start gap-4 lg:grid-cols-5">
        <section className="rounded-card border border-line bg-panel p-4 lg:col-span-3">
          <div className="mb-3 flex items-center gap-2 text-sm text-fog">
            <Smartphone className="size-4" />
            ลองควบคุมในจอนี้ก่อน ตัวจริงบนเครื่องคือไฟล์ APK
          </div>
          <div
            ref={stageRef}
            className="relative mx-auto h-[32rem] max-w-sm overflow-hidden rounded-card border border-line bg-ink"
          >
            <div className="flex items-center justify-between border-b border-line px-4 py-3 text-sm">
              <span>แอปอื่น</span>
              <span className="font-mono text-xs text-fog">ด้านล่างปุ่มลอย</span>
            </div>
            <div className="space-y-3 p-4">
              <button
                type="button"
                data-hit="reward"
                onClick={() => setReward((n) => n + 1)}
                className="flex min-h-28 w-full flex-col items-start justify-between rounded-xl border border-line bg-panel-2 p-4 text-left"
              >
                <span className="text-sm text-fog">รับรางวัล</span>
                <span className="font-mono text-4xl tabular-nums">{reward}</span>
              </button>
              <button
                type="button"
                data-hit="lamp"
                aria-pressed={lamp}
                onClick={() => setLamp((on) => !on)}
                className="flex min-h-12 w-full items-center justify-between rounded-xl border border-line px-3"
              >
                <span>ไฟในแอป</span>
                <span className={clsx("h-6 w-11 rounded-full", lamp ? "bg-lime" : "bg-line")}>
                  <span
                    className={clsx(
                      "mt-0.5 block size-5 rounded-full bg-paper",
                      lamp ? "ml-5" : "ml-0.5",
                    )}
                  />
                </span>
              </button>
              <p className="text-sm text-pretty text-fog">
                ลากวงกลมดำไปทับปุ่ม แล้วกดเริ่ม การแตะจะเกิดตรงกลางวงกลม ย้ายวงกลมระหว่างทำงานได้
              </p>
            </div>

            {ripples.map((ripple) => (
              <span
                key={ripple.id}
                className="kod-ripple pointer-events-none absolute z-20 size-14 rounded-full border-2 border-lime"
                style={{ left: ripple.x, top: ripple.y }}
              />
            ))}

            <button
              ref={bubbleRef}
              type="button"
              aria-label="ปุ่มลอย ลากเพื่อย้าย แตะเพื่อเปิดแผง"
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={() => {
                drag.current = null;
              }}
              onClick={() => {
                if (moved.current) {
                  moved.current = false;
                  return;
                }
                setOpen((value) => !value);
              }}
              className={clsx(
                "absolute z-30 size-14 touch-none rounded-full border-4 bg-ink",
                running ? "border-ember" : "border-lime",
              )}
              style={{ left: pos.x, top: pos.y }}
            >
              <span
                className={clsx(
                  "absolute top-1/2 left-1/2 size-3 -translate-x-1/2 -translate-y-1/2",
                  running ? "rounded-sm bg-ember" : "rounded-full bg-lime",
                )}
              />
            </button>

            {running ? (
              <p className="pointer-events-none absolute top-16 right-3 rounded-lg border border-line bg-panel px-2 py-1 font-mono text-xs">
                {durationMs > 0 ? `เหลือ ${clock(leftMs)}` : "กำลังกด"}
                {running ? ` · ${clicks}` : ""}
              </p>
            ) : null}

            {open ? (
              <div className="absolute bottom-3 left-3 right-3 z-40 rounded-xl border border-line bg-panel p-3">
                <p className="font-mono text-xs text-fog">
                  X {Math.round(pos.x + 28)} · Y {Math.round(pos.y + 28)}
                </p>
                <div className="mt-2 flex items-center gap-2">
                  <button type="button" className="min-h-11 min-w-11 rounded-lg border border-line" onClick={() => stepInterval(-1)}>
                    −
                  </button>
                  <p className="flex-1 text-center text-sm">{intervalLabel(intervalMs)}</p>
                  <button type="button" className="min-h-11 min-w-11 rounded-lg border border-line" onClick={() => stepInterval(1)}>
                    +
                  </button>
                </div>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  {DURATIONS.map((item) => (
                    <button
                      key={item.label}
                      type="button"
                      onClick={() => setDurationMs(item.ms)}
                      className={clsx(
                        "min-h-11 rounded-lg border text-sm",
                        durationMs === item.ms ? "border-lime text-lime" : "border-line text-fog",
                      )}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
            ) : null}
          </div>
        </section>

        <aside className="flex flex-col gap-4 lg:col-span-2">
          <section className="rounded-card border border-line bg-panel p-4">
            <p className="text-sm text-fog" aria-live="polite">
              {note}
              {running ? ` · กดแล้ว ${clicks} ครั้ง` : ""}
            </p>
            <div className="mt-3 flex flex-col gap-2">
              <button
                type="button"
                onClick={start}
                disabled={running}
                className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-lime font-semibold text-lime-ink disabled:opacity-40"
              >
                <Play className="size-5" />
                เริ่มกด
              </button>
              <button
                type="button"
                onClick={() => stop(clicks > 0 ? `หยุดแล้ว · กดไป ${clicks} ครั้ง` : "ยังไม่ได้เริ่ม")}
                className={clsx(
                  "inline-flex min-h-12 items-center justify-center gap-2 rounded-xl font-semibold",
                  running ? "bg-ember text-ember-ink" : "border border-ember text-ember",
                )}
              >
                <OctagonX className="size-5" />
                หยุด
              </button>
            </div>
          </section>
          <section className="rounded-card border border-line bg-panel p-4 text-sm text-pretty text-fog">
            บนเครื่องจริง ปุ่มลอยตัวเล็กอยู่เหนือทุกแอป พิกัดถูกจำทันทีที่ปล่อยนิ้ว ระหว่างกดสามารถลากย้ายจุด แตะหน้าจอเอง หรือกดหยุดได้ตลอด ครบเวลาที่ตั้งไว้ระบบหยุดเอง เพื่อไม่ให้กดค้างทั้งคืน
          </section>
        </aside>
      </div>
    </main>
  );
}
