import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Download, i as OctagonX, n as Smartphone, r as Play } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Gl1QRTH_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var INTERVALS = [
	100,
	200,
	300,
	500,
	700,
	1e3,
	1500,
	2e3,
	3e3,
	5e3
];
var DURATIONS = [
	{
		ms: 0,
		label: "ไม่จำกัด"
	},
	{
		ms: 6e4,
		label: "1 นาที"
	},
	{
		ms: 3e5,
		label: "5 นาที"
	},
	{
		ms: 18e5,
		label: "30 นาที"
	}
];
function intervalLabel(ms) {
	if (ms % 1e3 === 0) return `ทุก ${ms / 1e3} วินาที`;
	return `ทุก ${(ms / 1e3).toFixed(1)} วินาที`;
}
function clock(ms) {
	const sec = Math.max(0, Math.ceil(ms / 1e3));
	return `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`;
}
function AutoConsole() {
	const stageRef = (0, import_react.useRef)(null);
	const bubbleRef = (0, import_react.useRef)(null);
	const timer = (0, import_react.useRef)(null);
	const deadline = (0, import_react.useRef)(0);
	const drag = (0, import_react.useRef)(null);
	const moved = (0, import_react.useRef)(false);
	const [pos, setPos] = (0, import_react.useState)({
		x: 118,
		y: 168
	});
	const [open, setOpen] = (0, import_react.useState)(false);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [intervalMs, setIntervalMs] = (0, import_react.useState)(500);
	const [durationMs, setDurationMs] = (0, import_react.useState)(3e5);
	const [leftMs, setLeftMs] = (0, import_react.useState)(0);
	const [clicks, setClicks] = (0, import_react.useState)(0);
	const [reward, setReward] = (0, import_react.useState)(0);
	const [lamp, setLamp] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("ลากวงกลมไปจุดที่จะกด แล้วกดเริ่ม");
	const [ripples, setRipples] = (0, import_react.useState)([]);
	function stop(reason) {
		if (timer.current != null) window.clearInterval(timer.current);
		timer.current = null;
		setRunning(false);
		setNote(reason);
	}
	function tick() {
		const stage = stageRef.current;
		const bubble = bubbleRef.current;
		if (!stage || !bubble) return;
		if (deadline.current > 0 && Date.now() >= deadline.current) {
			stop("ครบเวลาที่ตั้งไว้ จึงหยุดเอง");
			return;
		}
		const stageBox = stage.getBoundingClientRect();
		const bubbleBox = bubble.getBoundingClientRect();
		const x = bubbleBox.left + bubbleBox.width / 2;
		const y = bubbleBox.top + bubbleBox.height / 2;
		const hit = document.elementsFromPoint(x, y).find((el) => stage.contains(el) && el !== bubble && !bubble.contains(el) && el instanceof HTMLElement && el.dataset.hit);
		if (hit?.dataset.hit === "reward") setReward((n) => n + 1);
		if (hit?.dataset.hit === "lamp") setLamp((on) => !on);
		const id = Date.now();
		setRipples((items) => [...items.slice(-5), {
			id,
			x: x - stageBox.left,
			y: y - stageBox.top
		}]);
		window.setTimeout(() => {
			setRipples((items) => items.filter((item) => item.id !== id));
		}, 420);
		setClicks((n) => n + 1);
		if (deadline.current > 0) setLeftMs(deadline.current - Date.now());
	}
	function start() {
		if (timer.current != null) window.clearInterval(timer.current);
		setClicks(0);
		deadline.current = durationMs > 0 ? Date.now() + durationMs : 0;
		setLeftMs(durationMs);
		setRunning(true);
		setOpen(false);
		setNote(durationMs > 0 ? "กำลังกดจุดที่วงกลมวางอยู่ จะหยุดเองเมื่อครบเวลา" : "กำลังกดจุดที่วงกลมวางอยู่ จะไม่หยุดจนกว่าจะกดหยุด");
		timer.current = window.setInterval(tick, intervalMs);
		tick();
	}
	(0, import_react.useEffect)(() => {
		if (!running) return;
		if (timer.current != null) window.clearInterval(timer.current);
		timer.current = window.setInterval(tick, intervalMs);
		return () => {
			if (timer.current != null) window.clearInterval(timer.current);
		};
	}, [running, intervalMs]);
	(0, import_react.useEffect)(() => () => {
		if (timer.current != null) window.clearInterval(timer.current);
	}, []);
	function onPointerDown(event) {
		moved.current = false;
		drag.current = {
			dx: event.clientX - pos.x,
			dy: event.clientY - pos.y
		};
		event.currentTarget.setPointerCapture(event.pointerId);
	}
	function onPointerMove(event) {
		if (!drag.current || !stageRef.current) return;
		const bounds = stageRef.current.getBoundingClientRect();
		const maxX = bounds.width - 56;
		const maxY = bounds.height - 56;
		const next = {
			x: Math.min(maxX, Math.max(0, event.clientX - drag.current.dx)),
			y: Math.min(maxY, Math.max(0, event.clientY - drag.current.dy))
		};
		if (Math.hypot(next.x - pos.x, next.y - pos.y) > 4) moved.current = true;
		setPos(next);
	}
	function stepInterval(direction) {
		const index = INTERVALS.findIndex((item) => item === intervalMs);
		const next = Math.min(INTERVALS.length - 1, Math.max(0, (index < 0 ? 3 : index) + direction));
		setIntervalMs(INTERVALS[next] ?? 500);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen w-full max-w-6xl flex-col gap-4 px-4 py-4 sm:px-6 sm:py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tracking-widest text-lime",
						children: "Android"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-balance text-3xl font-semibold tracking-tight sm:text-4xl",
						children: "กดวน"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-xl text-pretty text-sm text-fog",
						children: "ปุ่มลอยสีดำอยู่เหนือแอปอื่น ลากไปจุดที่อยากให้แตะ แล้วกดเริ่ม ระบบแตะซ้ำจนคุณกดหยุดหรือครบเวลา"
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-panel p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 sm:flex-row sm:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: "ไฟล์ติดตั้ง Android"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-pretty text-fog",
							children: "ไฟล์นี้เป็นรุ่นทดสอบสำหรับติดตั้งเอง เซ็นด้วยคีย์ดีบัก ยังไม่ใช่ไฟล์ที่ลง Play Store ได้ เปิดบนมือถือแล้วอนุญาตให้ติดตั้งจากเบราว์เซอร์ถ้าเครื่องถาม iOS ติดตั้งไฟล์นี้ไม่ได้"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "/kodvon-autoclick.apk",
						download: "kodvon-autoclick.apk",
						className: "inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-lime px-4 font-semibold text-lime-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-5" }), "ดาวน์โหลด APK"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 grid gap-2 text-sm sm:grid-cols-2",
					children: [
						"ติดตั้งไฟล์ แล้วเปิดแอปกดวน",
						"เปิดสิทธิ์แสดงทับแอปอื่น",
						"เปิดกดวนในเมนูการช่วยเหลือ",
						"กดแสดงปุ่มลอย แล้วลากวงกลมไปจุดที่จะกด"
					].map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-2 rounded-xl border border-line bg-ink px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-lime",
							children: index + 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: step })]
					}, step))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-card border border-line bg-panel p-4 lg:col-span-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center gap-2 text-sm text-fog",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-4" }), "ลองควบคุมในจอนี้ก่อน ตัวจริงบนเครื่องคือไฟล์ APK"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						ref: stageRef,
						className: "relative mx-auto h-[32rem] max-w-sm overflow-hidden rounded-card border border-line bg-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between border-b border-line px-4 py-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "แอปอื่น" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-fog",
									children: "ด้านล่างปุ่มลอย"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3 p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										"data-hit": "reward",
										onClick: () => setReward((n) => n + 1),
										className: "flex min-h-28 w-full flex-col items-start justify-between rounded-xl border border-line bg-panel-2 p-4 text-left",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm text-fog",
											children: "รับรางวัล"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-4xl tabular-nums",
											children: reward
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										"data-hit": "lamp",
										"aria-pressed": lamp,
										onClick: () => setLamp((on) => !on),
										className: "flex min-h-12 w-full items-center justify-between rounded-xl border border-line px-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ไฟในแอป" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: clsx("h-6 w-11 rounded-full", lamp ? "bg-lime" : "bg-line"),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: clsx("mt-0.5 block size-5 rounded-full bg-paper", lamp ? "ml-5" : "ml-0.5") })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-pretty text-fog",
										children: "ลากวงกลมดำไปทับปุ่ม แล้วกดเริ่ม การแตะจะเกิดตรงกลางวงกลม ย้ายวงกลมระหว่างทำงานได้"
									})
								]
							}),
							ripples.map((ripple) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "kod-ripple pointer-events-none absolute z-20 size-14 rounded-full border-2 border-lime",
								style: {
									left: ripple.x,
									top: ripple.y
								}
							}, ripple.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								ref: bubbleRef,
								type: "button",
								"aria-label": "ปุ่มลอย ลากเพื่อย้าย แตะเพื่อเปิดแผง",
								onPointerDown,
								onPointerMove,
								onPointerUp: () => {
									drag.current = null;
								},
								onClick: () => {
									if (moved.current) {
										moved.current = false;
										return;
									}
									setOpen((value) => !value);
								},
								className: clsx("absolute z-30 size-14 touch-none rounded-full border-4 bg-ink", running ? "border-ember" : "border-lime"),
								style: {
									left: pos.x,
									top: pos.y
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: clsx("absolute top-1/2 left-1/2 size-3 -translate-x-1/2 -translate-y-1/2", running ? "rounded-sm bg-ember" : "rounded-full bg-lime") })
							}),
							running ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "pointer-events-none absolute top-16 right-3 rounded-lg border border-line bg-panel px-2 py-1 font-mono text-xs",
								children: [durationMs > 0 ? `เหลือ ${clock(leftMs)}` : "กำลังกด", running ? ` · ${clicks}` : ""]
							}) : null,
							open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute bottom-3 left-3 right-3 z-40 rounded-xl border border-line bg-panel p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-mono text-xs text-fog",
										children: [
											"X ",
											Math.round(pos.x + 28),
											" · Y ",
											Math.round(pos.y + 28)
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "min-h-11 min-w-11 rounded-lg border border-line",
												onClick: () => stepInterval(-1),
												children: "−"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "flex-1 text-center text-sm",
												children: intervalLabel(intervalMs)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "min-h-11 min-w-11 rounded-lg border border-line",
												onClick: () => stepInterval(1),
												children: "+"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2 grid grid-cols-2 gap-2",
										children: DURATIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setDurationMs(item.ms),
											className: clsx("min-h-11 rounded-lg border text-sm", durationMs === item.ms ? "border-lime text-lime" : "border-line text-fog"),
											children: item.label
										}, item.label))
									})
								]
							}) : null
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "flex flex-col gap-4 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-card border border-line bg-panel p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-fog",
							"aria-live": "polite",
							children: [note, running ? ` · กดแล้ว ${clicks} ครั้ง` : ""]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-col gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: start,
								disabled: running,
								className: "inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-lime font-semibold text-lime-ink disabled:opacity-40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5" }), "เริ่มกด"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => stop(clicks > 0 ? `หยุดแล้ว · กดไป ${clicks} ครั้ง` : "ยังไม่ได้เริ่ม"),
								className: clsx("inline-flex min-h-12 items-center justify-center gap-2 rounded-xl font-semibold", running ? "bg-ember text-ember-ink" : "border border-ember text-ember"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OctagonX, { className: "size-5" }), "หยุด"]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "rounded-card border border-line bg-panel p-4 text-sm text-pretty text-fog",
						children: "บนเครื่องจริง ปุ่มลอยตัวเล็กอยู่เหนือทุกแอป พิกัดถูกจำทันทีที่ปล่อยนิ้ว ระหว่างกดสามารถลากย้ายจุด แตะหน้าจอเอง หรือกดหยุดได้ตลอด ครบเวลาที่ตั้งไว้ระบบหยุดเอง เพื่อไม่ให้กดค้างทั้งคืน"
					})]
				})]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AutoConsole, {});
}
//#endregion
export { Home as component };
