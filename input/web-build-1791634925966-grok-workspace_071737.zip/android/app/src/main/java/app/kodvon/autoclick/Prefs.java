package app.kodvon.autoclick;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    public static final int[] INTERVALS = ClickSession.INTERVALS;
    public static final int[] DURATIONS = ClickSession.DURATIONS;

    private final SharedPreferences sp;

    public Prefs(Context context) {
        sp = context.getApplicationContext().getSharedPreferences("kodvon", Context.MODE_PRIVATE);
    }

    public int interval() {
        return ClickSession.clampInterval(sp.getInt("interval", 500));
    }

    public void interval(int value) {
        sp.edit().putInt("interval", ClickSession.clampInterval(value)).apply();
    }

    public int duration() {
        return ClickSession.clampDuration(sp.getInt("duration", 300_000));
    }

    public void duration(int value) {
        sp.edit().putInt("duration", ClickSession.clampDuration(value)).apply();
    }

    public boolean placed() {
        return sp.getBoolean("placed", false);
    }

    public int x() {
        return sp.getInt("x", 0);
    }

    public int y() {
        return sp.getInt("y", 0);
    }

    public void position(int x, int y) {
        sp.edit().putInt("x", x).putInt("y", y).putBoolean("placed", true).apply();
    }

    public boolean hasRoster() {
        return sp.contains("roster");
    }

    public String roster() {
        return sp.getString("roster", "");
    }

    public void roster(String value) {
        sp.edit().putString("roster", value == null ? "" : value).apply();
    }

    public boolean panelPlaced() {
        return sp.getBoolean("panel_placed", false);
    }

    public int panelX() {
        return sp.getInt("panel_x", 0);
    }

    public int panelY() {
        return sp.getInt("panel_y", 0);
    }

    public void panelPosition(int x, int y) {
        sp.edit().putInt("panel_x", x).putInt("panel_y", y).putBoolean("panel_placed", true).apply();
    }

    /** 0 small, 1 medium, 2 large */
    public int panelMode() {
        return Math.max(0, Math.min(2, sp.getInt("panel_mode", 1)));
    }

    public void panelMode(int mode) {
        sp.edit().putInt("panel_mode", Math.max(0, Math.min(2, mode))).apply();
    }

    public boolean panelHidden() {
        return sp.getBoolean("panel_hidden", false);
    }

    public void panelHidden(boolean hidden) {
        sp.edit().putBoolean("panel_hidden", hidden).apply();
    }

    public static int stepInterval(int current, int direction) {
        return ClickSession.stepInterval(current, direction);
    }

    public static String intervalLabel(int ms) {
        return ClickSession.intervalLabel(ms);
    }

    public static String durationLabel(int ms) {
        return ClickSession.durationLabel(ms);
    }

    public static String remainingLabel(long ms) {
        return ClickSession.remainingLabel(ms);
    }
}
