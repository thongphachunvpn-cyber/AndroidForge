package app.kodvon.autoclick;

/**
 * Up to five independent click points. Gesture timing stays in {@link ClickSession}
 * so a late callback still cannot restart a stopped point.
 *
 * One accessibility service dispatches a single gesture at a time. A stroke also
 * needs about {@link #DEVICE_FLOOR_MS} before the next one is real, so requested
 * intervals faster than that are stored but not promised.
 */
public final class ClickerBoard {
    public static final int MAX = 5;
    public static final int MIN_INTERVAL_MS = 50;
    public static final int MAX_INTERVAL_MS = 10_000;
    public static final int DEVICE_FLOOR_MS = 80;
    public static final int HONEST_TAPS_PER_SEC = 12;
    public static final int MIN_COUNT = 1;
    public static final int MAX_COUNT = 100_000;
    public static final int STEP_MS = 50;
    public static final int[] DEFAULT_INTERVALS = {500, 1000, 2000, 300, 1500};

    public static final class Slot {
        public final int index;
        public boolean present;
        public boolean enabled = true;
        public int intervalMs = 500;
        public boolean continuous = true;
        public int targetCount = 20;
        public int x;
        public int y;
        public final ClickSession session = new ClickSession();
        public long nextDue;

        Slot(int index) {
            this.index = index;
        }
    }

    private final Slot[] slots = new Slot[MAX];
    private int selected;

    public ClickerBoard() {
        for (int i = 0; i < MAX; i++) slots[i] = new Slot(i);
    }

    public Slot slot(int index) {
        return slots[index];
    }

    public int selected() {
        return selected;
    }

    public void select(int index) {
        if (present(index) != null) selected = index;
    }

    public int count() {
        int n = 0;
        for (Slot slot : slots) if (slot.present) n++;
        return n;
    }

    public boolean isFull() {
        return count() >= MAX;
    }

    public int add(int x, int y) {
        if (isFull()) return -1;
        for (int i = 0; i < MAX; i++) {
            if (slots[i].present) continue;
            Slot slot = slots[i];
            slot.present = true;
            slot.enabled = true;
            slot.intervalMs = DEFAULT_INTERVALS[i];
            slot.continuous = true;
            slot.targetCount = 20;
            slot.x = x;
            slot.y = y;
            slot.nextDue = 0L;
            slot.session.stop();
            selected = i;
            return i;
        }
        return -1;
    }

    public boolean remove(int index) {
        Slot slot = present(index);
        if (slot == null) return false;
        slot.session.stop();
        slot.present = false;
        slot.enabled = false;
        if (selected == index) selected = firstPresent();
        return true;
    }

    public void setInterval(int index, int value) {
        Slot slot = present(index);
        if (slot == null) return;
        slot.intervalMs = clampCustomInterval(value);
    }

    public void setContinuous(int index, boolean continuous) {
        Slot slot = present(index);
        if (slot == null) return;
        slot.continuous = continuous;
        if (!continuous && slot.session.isRunning() && slot.session.clicks() >= slot.targetCount) {
            slot.session.stop();
        }
    }

    public void setTargetCount(int index, int count) {
        Slot slot = present(index);
        if (slot == null) return;
        slot.targetCount = clampCount(count);
    }

    public void setEnabled(int index, boolean enabled) {
        Slot slot = present(index);
        if (slot == null) return;
        slot.enabled = enabled;
        if (!enabled) slot.session.stop();
    }

    public void move(int index, int x, int y) {
        Slot slot = present(index);
        if (slot == null) return;
        slot.x = x;
        slot.y = y;
    }

    public boolean startOne(int index, long now, int durationMs) {
        Slot slot = present(index);
        if (slot == null || !slot.enabled) return false;
        if (slot.session.isPaused()) {
            if (!slot.session.resume()) return false;
            slot.nextDue = now;
            return true;
        }
        if (!slot.session.start(now, durationMs)) return false;
        slot.nextDue = now;
        return true;
    }

    public int startEnabled(long now, int durationMs) {
        int started = 0;
        for (int i = 0; i < MAX; i++) if (startOne(i, now, durationMs)) started++;
        return started;
    }

    public void pauseOne(int index) {
        Slot slot = present(index);
        if (slot != null) slot.session.pause();
    }

    public void pauseAll() {
        for (Slot slot : slots) if (slot.present) slot.session.pause();
    }

    public boolean resumeOne(int index, long now) {
        Slot slot = present(index);
        if (slot == null || !slot.session.resume()) return false;
        slot.nextDue = now;
        return true;
    }

    public int resumeAll(long now) {
        int resumed = 0;
        for (int i = 0; i < MAX; i++) if (resumeOne(i, now)) resumed++;
        return resumed;
    }

    public void stopOne(int index) {
        Slot slot = present(index);
        if (slot != null) slot.session.stop();
    }

    public void stopAll() {
        for (Slot slot : slots) if (slot.present) slot.session.stop();
    }

    public void applyDurationAll(long now, int durationMs) {
        for (Slot slot : slots) {
            if (slot.present && slot.session.isRunning()) slot.session.applyDuration(now, durationMs);
        }
    }

    public void noteExpired(long now) {
        for (Slot slot : slots) {
            if (slot.present && slot.session.expired(now)) slot.session.stop();
        }
    }

    public boolean anyActive() {
        for (Slot slot : slots) if (slot.present && slot.session.isRunning()) return true;
        return false;
    }

    public boolean anyRunningUnpaused() {
        for (Slot slot : slots) {
            if (slot.present && slot.session.isRunning() && !slot.session.isPaused()) return true;
        }
        return false;
    }

    public int runningCount() {
        int n = 0;
        for (Slot slot : slots) {
            if (slot.present && slot.session.isRunning() && !slot.session.isPaused()) n++;
        }
        return n;
    }

    public int totalClicks() {
        int n = 0;
        for (Slot slot : slots) if (slot.present) n += slot.session.clicks();
        return n;
    }

    /** @return slot to dispatch, or -1 when the shared gesture dispatcher is busy or nobody is due */
    public int pollDue(long now, boolean dispatcherBusy) {
        if (dispatcherBusy) return -1;
        int best = -1;
        long bestDue = Long.MAX_VALUE;
        for (Slot slot : slots) {
            if (!ready(slot) || slot.session.expired(now)) continue;
            if (slot.nextDue <= now && slot.nextDue < bestDue) {
                best = slot.index;
                bestDue = slot.nextDue;
            }
        }
        return best;
    }

    public long nextWake(long now) {
        long best = Long.MAX_VALUE;
        for (Slot slot : slots) {
            if (!ready(slot) || slot.session.expired(now)) continue;
            if (slot.nextDue < best) best = slot.nextDue;
        }
        if (best == Long.MAX_VALUE) return 200L;
        return Math.max(16L, best - now);
    }

    /**
     * @return 0 ignored, 1 still running, 2 stopped because the count or the timer finished
     */
    public int afterGesture(int index, int gen, boolean ok, boolean timedOut, long now, long spentMs) {
        Slot slot = present(index);
        if (slot == null) return 0;
        boolean schedule = timedOut
                ? slot.session.onGestureTimeout(gen)
                : slot.session.onGestureResult(gen, ok);
        if (!schedule) return 0;
        boolean finished = ok && !timedOut && !slot.continuous && slot.session.clicks() >= slot.targetCount;
        if (finished || slot.session.expired(now)) {
            slot.session.stop();
            return 2;
        }
        slot.nextDue = now + delayAfter(slot.intervalMs, spentMs, ok && !timedOut);
        return 1;
    }

    public boolean overBudget() {
        // A single point at the device floor is honest. Two or more that share
        // the one-gesture dispatcher are not, and the warning must show while
        // the user is still setting speeds — not only after Start.
        return combinedTapsPerSec() > (1000.0 / DEVICE_FLOOR_MS) + 0.2;
    }

    public double combinedTapsPerSec() {
        double sum = 0;
        for (Slot slot : slots) {
            if (!slot.present || !slot.enabled) continue;
            sum += 1000.0 / effectiveInterval(slot.intervalMs);
        }
        return sum;
    }

    public String encode() {
        StringBuilder raw = new StringBuilder();
        for (Slot slot : slots) {
            if (!slot.present) continue;
            if (raw.length() > 0) raw.append(';');
            raw.append(slot.index).append(',')
                    .append(slot.enabled ? 1 : 0).append(',')
                    .append(slot.intervalMs).append(',')
                    .append(slot.continuous ? 1 : 0).append(',')
                    .append(slot.targetCount).append(',')
                    .append(slot.x).append(',')
                    .append(slot.y);
        }
        return raw.toString();
    }

    public int decode(String raw) {
        for (Slot slot : slots) {
            slot.session.stop();
            slot.present = false;
            slot.enabled = false;
        }
        if (raw == null || raw.isEmpty()) {
            selected = 0;
            return 0;
        }
        int n = 0;
        for (String part : raw.split(";")) {
            String[] fields = part.split(",");
            if (fields.length < 7) continue;
            try {
                int index = Integer.parseInt(fields[0].trim());
                if (index < 0 || index >= MAX || slots[index].present) continue;
                Slot slot = slots[index];
                slot.present = true;
                slot.enabled = !"0".equals(fields[1].trim());
                slot.intervalMs = clampCustomInterval(Integer.parseInt(fields[2].trim()));
                slot.continuous = !"0".equals(fields[3].trim());
                slot.targetCount = clampCount(Integer.parseInt(fields[4].trim()));
                slot.x = Integer.parseInt(fields[5].trim());
                slot.y = Integer.parseInt(fields[6].trim());
                n++;
            } catch (NumberFormatException ignored) {
                // Skip a damaged point instead of dropping the rest of the roster.
            }
        }
        selected = firstPresent();
        return n;
    }

    public static int clampCustomInterval(int value) {
        if (value < MIN_INTERVAL_MS) return MIN_INTERVAL_MS;
        if (value > MAX_INTERVAL_MS) return MAX_INTERVAL_MS;
        return value;
    }

    public static int effectiveInterval(int requested) {
        return Math.max(DEVICE_FLOOR_MS, clampCustomInterval(requested));
    }

    public static int stepCustomInterval(int current, int direction) {
        int dir = direction < 0 ? -1 : 1;
        return clampCustomInterval(clampCustomInterval(current) + dir * STEP_MS);
    }

    public static int clampCount(int value) {
        if (value < MIN_COUNT) return MIN_COUNT;
        if (value > MAX_COUNT) return MAX_COUNT;
        return value;
    }

    public static int stepCount(int current, int direction) {
        int dir = direction < 0 ? -1 : 1;
        int base = clampCount(current);
        int magnitude = base < 20 ? 1 : base < 100 ? 5 : 10;
        return clampCount(base + dir * magnitude);
    }

    public static long delayAfter(int intervalMs, long spentMs, boolean succeeded) {
        long interval = effectiveInterval(intervalMs);
        if (!succeeded) return interval;
        return Math.max(ClickSession.MIN_GAP_MS, interval - Math.max(0L, spentMs));
    }

    private boolean ready(Slot slot) {
        return slot.present
                && slot.enabled
                && slot.session.isRunning()
                && !slot.session.isPaused()
                && !slot.session.isInFlight();
    }

    private Slot present(int index) {
        if (index < 0 || index >= MAX || !slots[index].present) return null;
        return slots[index];
    }

    private int firstPresent() {
        for (int i = 0; i < MAX; i++) if (slots[i].present) return i;
        return 0;
    }
}
