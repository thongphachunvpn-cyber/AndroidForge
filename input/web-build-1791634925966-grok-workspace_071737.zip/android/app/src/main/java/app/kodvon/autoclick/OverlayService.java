package app.kodvon.autoclick;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentCallbacks;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Locale;

/**
 * Floating panel plus one marker window per click point. The panel can move,
 * resize, and hide without moving the points and without stopping a run.
 * Taps are dispatched at the marker center, never at the panel buttons.
 */
public class OverlayService extends Service {
    public static final String ACTION_STOP = "app.kodvon.autoclick.STOP";
    private static final String CHANNEL = "kodvon";
    private static final int NOTIF_ID = 7;
    private static final int[] COLORS = {
            0xFFD6FF4A, 0xFFFF4D2E, 0xFF3EE0FF, 0xFFC084FC, 0xFFFFB15A
    };

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ClickerBoard board = new ClickerBoard();
    private final View[] markers = new View[ClickerBoard.MAX];
    private final WindowManager.LayoutParams[] markerParams = new WindowManager.LayoutParams[ClickerBoard.MAX];
    private final Runnable[] timeouts = new Runnable[ClickerBoard.MAX];
    private final int[] markerVisual = new int[ClickerBoard.MAX];

    private Prefs prefs;
    private WindowManager wm;
    private View panel;
    private View nub;
    private WindowManager.LayoutParams panelParams;
    private WindowManager.LayoutParams nubParams;
    private LinearLayout rows;
    private ScrollView scroller;
    private TextView summary;
    private TextView warn;
    private Button addButton;
    private Button sizeButton;
    private View durationBox;
    private View closeButton;
    private boolean binding;
    private boolean alive = true;
    private boolean foregroundStarted;
    private boolean draggingPanel;
    private int draggingMarker = -1;
    private int longPressIndex = -1;
    private int inFlight = -1;
    private int rowSignature = Integer.MIN_VALUE;
    private int panelX;
    private int panelY;
    private long lastNotificationAt;
    private String statusLine;

    private final Runnable longPress = () -> {
        int index = longPressIndex;
        if (index < 0 || draggingMarker >= 0) return;
        board.stopOne(index);
        if (inFlight == index) clearInFlight(index);
        statusLine = getString(R.string.stopped_long_press);
        refreshUi();
        saveRoster();
        publishNotification(false);
    };

    private final Runnable pumpTask = this::pump;

    private final ClickService.ConnectionListener connectionListener = new ClickService.ConnectionListener() {
        @Override
        public void onConnectionChanged(boolean connected) {
            if (!connected && board.anyActive()) {
                stopClicking(getString(R.string.stopped_access));
            }
        }

        @Override
        public void onInterrupted() {
            if (board.anyActive()) stopClicking(getString(R.string.stopped_interrupt));
        }
    };

    private final ComponentCallbacks componentCallbacks = new ComponentCallbacks() {
        @Override
        public void onConfigurationChanged(Configuration newConfig) {
            handler.post(() -> {
                clampAll();
                placeAll();
                applyMode();
            });
        }

        @Override
        public void onLowMemory() {
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = new Prefs(this);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
        loadBoard();
        ClickService.setConnectionListener(connectionListener);
        getApplicationContext().registerComponentCallbacks(componentCallbacks);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!enterForeground()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopClicking(getString(R.string.stopped_notification));
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            stopClicking(getString(R.string.stopped_overlay));
            stopForeground(STOP_FOREGROUND_REMOVE);
            foregroundStarted = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        if (panel == null && nub == null) attach();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        alive = false;
        board.stopAll();
        handler.removeCallbacksAndMessages(null);
        ClickService.setConnectionListener(null);
        try {
            getApplicationContext().unregisterComponentCallbacks(componentCallbacks);
        } catch (RuntimeException ignored) {
        }
        for (int i = 0; i < markers.length; i++) removeMarker(i);
        removeWindow(panel);
        removeWindow(nub);
        panel = null;
        nub = null;
        if (foregroundStarted) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            foregroundStarted = false;
        }
        super.onDestroy();
    }

    private void loadBoard() {
        if (prefs.hasRoster()) {
            board.decode(prefs.roster());
            return;
        }
        int x;
        int y;
        if (prefs.placed()) {
            x = prefs.x() + dp(32);
            y = prefs.y() + dp(32);
        } else {
            Rect area = safeArea();
            x = area.centerX();
            y = area.top + area.height() / 3;
        }
        int index = board.add(x, y);
        if (index >= 0) {
            board.setInterval(index, prefs.interval());
            clampCenter(index);
        }
        saveRoster();
    }

    private void attach() {
        if (!prefs.panelPlaced()) {
            Rect area = safeArea();
            panelX = area.left + dp(8);
            panelY = area.top + dp(8);
        } else {
            panelX = prefs.panelX();
            panelY = prefs.panelY();
        }
        syncMarkers();
        if (prefs.panelHidden()) showNub();
        else showPanel();
        refreshUi();
    }

    private void showPanel() {
        if (panel != null) return;
        removeWindow(nub);
        nub = null;
        panel = LayoutInflater.from(this).inflate(R.layout.overlay_panel, null);
        rows = panel.findViewById(R.id.rows);
        scroller = panel.findViewById(R.id.scroller);
        summary = panel.findViewById(R.id.summary);
        warn = panel.findViewById(R.id.warn);
        addButton = panel.findViewById(R.id.add);
        sizeButton = panel.findViewById(R.id.size);
        durationBox = panel.findViewById(R.id.duration_box);
        closeButton = panel.findViewById(R.id.close);
        panelParams = overlayParams(dp(modeWidth()), WindowManager.LayoutParams.WRAP_CONTENT);
        panelParams.x = panelX;
        panelParams.y = panelY;
        panelParams.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
        wm.addView(panel, panelParams);
        panel.findViewById(R.id.handle).setOnTouchListener(this::onPanelTouch);
        sizeButton.setOnClickListener(v -> {
            prefs.panelMode((prefs.panelMode() + 1) % 3);
            rowSignature = Integer.MIN_VALUE;
            applyMode();
        });
        panel.findViewById(R.id.hide).setOnClickListener(v -> hidePanel());
        panel.findViewById(R.id.start_all).setOnClickListener(v -> startAll());
        panel.findViewById(R.id.pause_all).setOnClickListener(v -> {
            board.pauseAll();
            refreshUi();
            publishNotification(false);
        });
        panel.findViewById(R.id.resume_all).setOnClickListener(v -> resumeAll());
        panel.findViewById(R.id.stop_all).setOnClickListener(v -> stopClicking(getString(R.string.stopped_user)));
        addButton.setOnClickListener(v -> addClicker());
        closeButton.setOnClickListener(v -> shutdown(getString(R.string.stopped_hide)));
        wireDuration(R.id.dur_0, 0);
        wireDuration(R.id.dur_1, 60_000);
        wireDuration(R.id.dur_5, 300_000);
        wireDuration(R.id.dur_30, 1_800_000);
        rowSignature = Integer.MIN_VALUE;
        applyMode();
    }

    private void hidePanel() {
        prefs.panelHidden(true);
        clearTyping();
        removeWindow(panel);
        panel = null;
        rows = null;
        showNub();
    }

    private void showNub() {
        if (nub != null) return;
        TextView chip = new TextView(this);
        chip.setText(R.string.show_panel);
        chip.setTextColor(0xFF101410);
        chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        chip.setTypeface(Typeface.DEFAULT_BOLD);
        chip.setGravity(Gravity.CENTER);
        chip.setBackground(circle(0xFFD6FF4A, 0));
        chip.setContentDescription(getString(R.string.nub_desc));
        int size = dp(52);
        nubParams = overlayParams(size, size);
        nubParams.x = panelX;
        nubParams.y = panelY;
        nub = chip;
        chip.setOnTouchListener(this::onNubTouch);
        wm.addView(nub, nubParams);
        clampPanel();
        nubParams.x = panelX;
        nubParams.y = panelY;
        try {
            wm.updateViewLayout(nub, nubParams);
        } catch (RuntimeException ignored) {
        }
    }

    private void syncMarkers() {
        for (int i = 0; i < ClickerBoard.MAX; i++) {
            ClickerBoard.Slot slot = board.slot(i);
            if (slot.present && markers[i] == null) addMarker(i);
            if (!slot.present && markers[i] != null) removeMarker(i);
            if (slot.present) {
                clampCenter(i);
                int half = markerSize() / 2;
                int x = board.slot(i).x - half;
                int y = board.slot(i).y - half;
                if (markerParams[i] != null && (markerParams[i].x != x || markerParams[i].y != y)) {
                    placeMarker(i);
                }
            }
        }
    }

    private void addMarker(int index) {
        FrameLayout marker = new FrameLayout(this);
        TextView label = new TextView(this);
        label.setGravity(Gravity.CENTER);
        label.setText(String.valueOf(index + 1));
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        label.setTextColor(COLORS[index]);
        marker.addView(label, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        marker.setContentDescription(getString(R.string.marker_desc, index + 1));
        int size = markerSize();
        WindowManager.LayoutParams params = overlayParams(size, size);
        markers[index] = marker;
        markerParams[index] = params;
        markerVisual[index] = Integer.MIN_VALUE;
        marker.setOnTouchListener((view, event) -> onMarkerTouch(index, event));
        wm.addView(marker, params);
    }

    private void removeMarker(int index) {
        clearTimeout(index);
        if (inFlight == index) inFlight = -1;
        removeWindow(markers[index]);
        markers[index] = null;
        markerParams[index] = null;
    }

    private void removeWindow(View view) {
        if (view == null || wm == null) return;
        try {
            wm.removeView(view);
        } catch (RuntimeException ignored) {
        }
    }

    private boolean onMarkerTouch(int index, MotionEvent event) {
        ClickerBoard.Slot slot = board.slot(index);
        if (!slot.present || markerParams[index] == null) return false;
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                draggingMarker = -1;
                longPressIndex = index;
                markers[index].setTag(new float[]{
                        event.getRawX(), event.getRawY(), slot.x, slot.y
                });
                handler.removeCallbacks(longPress);
                handler.postDelayed(longPress, 500);
                return true;
            case MotionEvent.ACTION_MOVE:
                float[] origin = (float[]) markers[index].getTag();
                if (origin == null) return true;
                float dx = event.getRawX() - origin[0];
                float dy = event.getRawY() - origin[1];
                if (Math.hypot(dx, dy) > dp(8)) {
                    draggingMarker = index;
                    handler.removeCallbacks(longPress);
                }
                if (draggingMarker == index) {
                    board.move(index, Math.round(origin[2] + dx), Math.round(origin[3] + dy));
                    clampCenter(index);
                    placeMarker(index);
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPress);
                boolean dragged = draggingMarker == index;
                if (draggingMarker == index) draggingMarker = -1;
                longPressIndex = -1;
                if (dragged) {
                    saveRoster();
                    refreshUi();
                } else if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                    board.select(index);
                    if (panel == null) {
                        prefs.panelHidden(false);
                        showPanel();
                    }
                    refreshUi();
                }
                return true;
            default:
                return false;
        }
    }

    private boolean onPanelTouch(View view, MotionEvent event) {
        if (panelParams == null) return false;
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                draggingPanel = false;
                view.setTag(new float[]{event.getRawX(), event.getRawY(), panelX, panelY});
                return true;
            case MotionEvent.ACTION_MOVE:
                float[] origin = (float[]) view.getTag();
                if (origin == null) return true;
                float dx = event.getRawX() - origin[0];
                float dy = event.getRawY() - origin[1];
                if (Math.hypot(dx, dy) > dp(8)) draggingPanel = true;
                if (draggingPanel) {
                    panelX = Math.round(origin[2] + dx);
                    panelY = Math.round(origin[3] + dy);
                    clampPanel();
                    panelParams.x = panelX;
                    panelParams.y = panelY;
                    try {
                        wm.updateViewLayout(panel, panelParams);
                    } catch (RuntimeException ignored) {
                    }
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (draggingPanel) prefs.panelPosition(panelX, panelY);
                draggingPanel = false;
                return true;
            default:
                return false;
        }
    }

    private boolean onNubTouch(View view, MotionEvent event) {
        if (nubParams == null) return false;
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                draggingPanel = false;
                view.setTag(new float[]{event.getRawX(), event.getRawY(), panelX, panelY});
                return true;
            case MotionEvent.ACTION_MOVE:
                float[] origin = (float[]) view.getTag();
                if (origin == null) return true;
                float dx = event.getRawX() - origin[0];
                float dy = event.getRawY() - origin[1];
                if (Math.hypot(dx, dy) > dp(8)) draggingPanel = true;
                if (draggingPanel) {
                    panelX = Math.round(origin[2] + dx);
                    panelY = Math.round(origin[3] + dy);
                    clampPanel();
                    nubParams.x = panelX;
                    nubParams.y = panelY;
                    try {
                        wm.updateViewLayout(nub, nubParams);
                    } catch (RuntimeException ignored) {
                    }
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                boolean dragged = draggingPanel;
                draggingPanel = false;
                if (dragged) {
                    prefs.panelPosition(panelX, panelY);
                } else if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                    prefs.panelHidden(false);
                    removeWindow(nub);
                    nub = null;
                    showPanel();
                }
                return true;
            default:
                return false;
        }
    }

    private void addClicker() {
        if (board.isFull()) {
            statusLine = getString(R.string.add_full);
            refreshUi();
            return;
        }
        Rect area = safeArea();
        int n = board.count();
        int x = area.centerX() + (n - 2) * dp(34);
        int y = area.top + area.height() / 3 + (n % 2) * dp(40);
        int index = board.add(x, y);
        if (index < 0) return;
        clampCenter(index);
        statusLine = null;
        saveRoster();
        syncMarkers();
        rowSignature = Integer.MIN_VALUE;
        refreshUi();
    }

    private void startAll() {
        if (!ensureAccess()) return;
        long now = SystemClock.elapsedRealtime();
        int started = board.startEnabled(now, prefs.duration());
        if (started == 0 && !board.anyActive()) {
            statusLine = getString(R.string.none_enabled);
            refreshUi();
            return;
        }
        statusLine = null;
        refreshUi();
        publishNotification(true);
        schedulePump(0);
    }

    private void resumeAll() {
        if (!ensureAccess()) return;
        int resumed = board.resumeAll(SystemClock.elapsedRealtime());
        if (resumed == 0 && !board.anyRunningUnpaused()) return;
        statusLine = null;
        refreshUi();
        publishNotification(true);
        schedulePump(0);
    }

    private void startOne(int index) {
        if (!ensureAccess()) return;
        if (!board.startOne(index, SystemClock.elapsedRealtime(), prefs.duration())) {
            statusLine = getString(R.string.none_enabled);
            refreshUi();
            return;
        }
        statusLine = null;
        refreshUi();
        publishNotification(true);
        schedulePump(0);
    }

    private boolean ensureAccess() {
        if (ClickService.get() != null) return true;
        statusLine = getString(R.string.access_needed);
        refreshUi();
        try {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (RuntimeException ex) {
            statusLine = getString(R.string.access_settings_failed);
            refreshUi();
        }
        return false;
    }

    private void stopClicking(String reason) {
        int count = board.totalClicks();
        boolean was = board.anyActive();
        board.stopAll();
        clearInFlight(-1);
        handler.removeCallbacks(pumpTask);
        statusLine = was
                ? getString(R.string.stopped_with_count, reason, count)
                : getString(R.string.summary_ready, Prefs.durationLabel(prefs.duration()));
        refreshUi();
        if (foregroundStarted) publishNotification(true);
    }

    private void shutdown(String reason) {
        stopClicking(reason);
        stopForeground(STOP_FOREGROUND_REMOVE);
        foregroundStarted = false;
        stopSelf();
    }

    private void pump() {
        if (!alive) return;
        if (!Settings.canDrawOverlays(this)) {
            shutdown(getString(R.string.stopped_overlay));
            return;
        }
        long now = SystemClock.elapsedRealtime();
        board.noteExpired(now);
        if (ClickService.get() == null && board.anyActive()) {
            stopClicking(getString(R.string.stopped_access));
            return;
        }
        if (inFlight >= 0) {
            if (board.anyActive()) schedulePump(50);
            return;
        }
        int index = board.pollDue(now, false);
        if (index >= 0) {
            if (!beginFire(index)) schedulePump(40);
            refreshUi();
            return;
        }
        refreshUi();
        if (board.anyRunningUnpaused()) {
            schedulePump(Math.min(200L, board.nextWake(now)));
            maybeNotify();
        }
    }

    private boolean beginFire(int index) {
        if (markers[index] == null || draggingMarker == index) return false;
        int gen = board.slot(index).session.beginGesture();
        if (gen < 0) return false;
        inFlight = index;
        setPass(index, true);
        handler.post(() -> dispatchTap(index, gen));
        return true;
    }

    private void dispatchTap(int index, int gen) {
        ClickerBoard.Slot slot = board.slot(index);
        if (gen != slot.session.generation() || !slot.session.isRunning() || markers[index] == null) {
            if (inFlight == index) clearInFlight(index);
            schedulePump(16);
            return;
        }
        if (draggingMarker == index) {
            slot.session.cancelGesture(gen);
            if (inFlight == index) clearInFlight(index);
            slot.nextDue = SystemClock.elapsedRealtime() + 40L;
            schedulePump(40);
            return;
        }
        if (markers[index].getWidth() == 0 || markers[index].getHeight() == 0) {
            slot.session.cancelGesture(gen);
            if (inFlight == index) clearInFlight(index);
            slot.nextDue = SystemClock.elapsedRealtime() + 32L;
            schedulePump(32);
            return;
        }
        ClickService service = ClickService.get();
        if (service == null) {
            slot.session.cancelGesture(gen);
            if (inFlight == index) clearInFlight(index);
            stopClicking(getString(R.string.stopped_access));
            return;
        }
        int[] loc = new int[2];
        markers[index].getLocationOnScreen(loc);
        float x = loc[0] + markers[index].getWidth() / 2f;
        float y = loc[1] + markers[index].getHeight() / 2f;
        final long started = SystemClock.elapsedRealtime();
        Runnable timeout = () -> settle(index, gen, false, started, true);
        timeouts[index] = timeout;
        handler.postDelayed(timeout, ClickSession.GESTURE_TIMEOUT_MS);
        try {
            service.tap(x, y, ok -> handler.post(() -> {
                clearTimeout(index);
                settle(index, gen, ok, started, false);
            }));
        } catch (RuntimeException ex) {
            clearTimeout(index);
            settle(index, gen, false, started, false);
        }
    }

    private void settle(int index, int gen, boolean ok, long started, boolean timedOut) {
        long now = SystemClock.elapsedRealtime();
        int code = board.afterGesture(index, gen, ok, timedOut, now, now - started);
        if (inFlight == index && !board.slot(index).session.isInFlight()) {
            setPass(index, false);
            inFlight = -1;
        }
        if (code == 0) return;
        refreshUi();
        if (board.anyRunningUnpaused()) schedulePump(0);
        else if (foregroundStarted) publishNotification(false);
    }

    private void schedulePump(long delay) {
        if (!alive) return;
        handler.removeCallbacks(pumpTask);
        handler.postDelayed(pumpTask, Math.max(0L, delay));
    }

    private void clearInFlight(int index) {
        if (index < 0) {
            for (int i = 0; i < timeouts.length; i++) {
                clearTimeout(i);
                setPass(i, false);
            }
        } else {
            clearTimeout(index);
            setPass(index, false);
        }
        inFlight = -1;
    }

    private void clearTimeout(int index) {
        if (timeouts[index] == null) return;
        handler.removeCallbacks(timeouts[index]);
        timeouts[index] = null;
    }

    private void refreshUi() {
        syncMarkers();
        paintMarkers();
        if (panel == null) return;
        ensureRows();
        bindRows();
        int duration = prefs.duration();
        paintChip(R.id.dur_0, duration == 0);
        paintChip(R.id.dur_1, duration == 60_000);
        paintChip(R.id.dur_5, duration == 300_000);
        paintChip(R.id.dur_30, duration == 1_800_000);
        if (board.count() == 0) {
            summary.setText(statusLine != null ? statusLine : getString(R.string.summary_empty));
        } else if (board.anyRunningUnpaused()) {
            summary.setText(getString(R.string.summary_run, board.runningCount(), board.totalClicks()));
        } else if (board.anyActive()) {
            summary.setText(getString(R.string.summary_paused, board.totalClicks()));
        } else if (statusLine != null) {
            summary.setText(statusLine);
        } else {
            summary.setText(getString(R.string.summary_ready, Prefs.durationLabel(duration)));
        }
        boolean fast = board.overBudget();
        warn.setVisibility(fast ? View.VISIBLE : View.GONE);
        if (fast) warn.setText(getString(R.string.speed_warn, ClickerBoard.HONEST_TAPS_PER_SEC));
        addButton.setText(board.isFull() ? R.string.add_full : R.string.add_clicker);
        addButton.setEnabled(!board.isFull());
        addButton.setAlpha(board.isFull() ? 0.45f : 1f);
    }

    private void ensureRows() {
        if (rows == null) return;
        int signature = 0;
        for (int i = 0; i < ClickerBoard.MAX; i++) {
            if (board.slot(i).present) signature |= 1 << i;
        }
        if (signature == rowSignature) return;
        rowSignature = signature;
        rows.removeAllViews();
        for (int i = 0; i < ClickerBoard.MAX; i++) {
            if (!board.slot(i).present) continue;
            View row = LayoutInflater.from(this).inflate(R.layout.overlay_row, rows, false);
            wireRow(row, i);
            rows.addView(row);
        }
    }

    private void wireRow(View row, int index) {
        row.setTag(index);
        final int slot = index;
        row.findViewById(R.id.enabled).setOnClickListener(v -> {
            ClickerBoard.Slot current = board.slot(slot);
            boolean next = !current.enabled;
            board.setEnabled(slot, next);
            if (!next && inFlight == slot) clearInFlight(slot);
            saveRoster();
            refreshUi();
        });
        row.findViewById(R.id.start).setOnClickListener(v -> startOne(slot));
        row.findViewById(R.id.pause).setOnClickListener(v -> {
            ClickerBoard.Slot current = board.slot(slot);
            if (current.session.isPaused()) {
                if (!ensureAccess()) return;
                board.resumeOne(slot, SystemClock.elapsedRealtime());
                statusLine = null;
                schedulePump(0);
            } else {
                board.pauseOne(slot);
            }
            refreshUi();
            publishNotification(false);
        });
        row.findViewById(R.id.stop).setOnClickListener(v -> {
            board.stopOne(slot);
            if (inFlight == slot) clearInFlight(slot);
            if (!board.anyActive()) statusLine = getString(R.string.stopped_user);
            refreshUi();
            publishNotification(false);
        });
        row.findViewById(R.id.interval_minus).setOnClickListener(v -> stepInterval(slot, -1));
        row.findViewById(R.id.interval_plus).setOnClickListener(v -> stepInterval(slot, 1));
        row.findViewById(R.id.count_minus).setOnClickListener(v -> stepCount(slot, -1));
        row.findViewById(R.id.count_plus).setOnClickListener(v -> stepCount(slot, 1));
        row.findViewById(R.id.mode_cont).setOnClickListener(v -> {
            board.setContinuous(slot, true);
            saveRoster();
            refreshUi();
        });
        row.findViewById(R.id.mode_count).setOnClickListener(v -> {
            board.setContinuous(slot, false);
            saveRoster();
            refreshUi();
        });
        row.findViewById(R.id.delete).setOnClickListener(v -> {
            if (inFlight == slot) clearInFlight(slot);
            board.remove(slot);
            saveRoster();
            rowSignature = Integer.MIN_VALUE;
            syncMarkers();
            refreshUi();
        });
        EditText input = row.findViewById(R.id.interval_input);
        input.setOnFocusChangeListener((v, hasFocus) -> {
            setTyping(hasFocus);
            if (!hasFocus) commitInterval(slot, input);
        });
        input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (binding || !input.isFocused()) return;
                String text = editable.toString().trim();
                if (text.isEmpty()) return;
                try {
                    int value = Integer.parseInt(text);
                    if (value < ClickerBoard.MIN_INTERVAL_MS) return;
                    board.setInterval(slot, value);
                    saveRoster();
                    paintSpeed(row, board.slot(slot));
                } catch (NumberFormatException ignored) {
                }
            }
        });
        SeekBar seek = row.findViewById(R.id.interval_seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (!fromUser || binding) return;
                board.setInterval(slot, progress);
                saveRoster();
                paintSpeed(row, board.slot(slot));
                if (!input.isFocused()) {
                    binding = true;
                    input.setText(String.valueOf(board.slot(slot).intervalMs));
                    binding = false;
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                refreshUi();
            }
        });
    }

    private void stepInterval(int index, int direction) {
        board.setInterval(index, ClickerBoard.stepCustomInterval(board.slot(index).intervalMs, direction));
        saveRoster();
        refreshUi();
    }

    private void stepCount(int index, int direction) {
        board.setTargetCount(index, ClickerBoard.stepCount(board.slot(index).targetCount, direction));
        saveRoster();
        refreshUi();
    }

    private void commitInterval(int index, EditText input) {
        int value = ClickerBoard.MIN_INTERVAL_MS;
        try {
            String text = input.getText().toString().trim();
            if (!text.isEmpty()) value = Integer.parseInt(text);
        } catch (NumberFormatException ignored) {
            value = board.slot(index).intervalMs;
        }
        board.setInterval(index, value);
        saveRoster();
        refreshUi();
    }

    private void bindRows() {
        if (rows == null) return;
        binding = true;
        for (int i = 0; i < rows.getChildCount(); i++) {
            View row = rows.getChildAt(i);
            Object tag = row.getTag();
            if (!(tag instanceof Integer)) continue;
            int index = (Integer) tag;
            ClickerBoard.Slot slot = board.slot(index);
            if (!slot.present) continue;
            TextView badge = row.findViewById(R.id.badge);
            TextView title = row.findViewById(R.id.title);
            Button enabled = row.findViewById(R.id.enabled);
            TextView intervalShort = row.findViewById(R.id.interval_short);
            Button start = row.findViewById(R.id.start);
            Button pause = row.findViewById(R.id.pause);
            Button stop = row.findViewById(R.id.stop);
            View detail = row.findViewById(R.id.detail);
            badge.setText(String.valueOf(index + 1));
            badge.setBackground(circle(COLORS[index], 0));
            title.setText(getString(R.string.clicker_name, index + 1));
            title.setTextColor(board.selected() == index ? COLORS[index] : 0xFFEEF3EA);
            enabled.setText(slot.enabled ? R.string.enabled_on : R.string.enabled_off);
            paintSpeed(row, slot);
            intervalShort.setText(speedText(slot));
            boolean running = slot.session.isRunning();
            boolean paused = slot.session.isPaused();
            start.setEnabled(!running && slot.enabled);
            start.setAlpha(!running && slot.enabled ? 1f : 0.45f);
            pause.setEnabled(running);
            pause.setAlpha(running ? 1f : 0.45f);
            pause.setText(paused ? R.string.resume_all : R.string.pause_all);
            stop.setEnabled(running);
            stop.setAlpha(running ? 1f : 0.45f);
            detail.setVisibility(prefs.panelMode() == 2 ? View.VISIBLE : View.GONE);
            Button cont = row.findViewById(R.id.mode_cont);
            Button count = row.findViewById(R.id.mode_count);
            paintButton(cont, slot.continuous);
            paintButton(count, !slot.continuous);
            row.findViewById(R.id.count_box).setVisibility(slot.continuous ? View.GONE : View.VISIBLE);
            ((TextView) row.findViewById(R.id.count_label)).setText(
                    getString(R.string.count_label, slot.targetCount));
            EditText input = row.findViewById(R.id.interval_input);
            if (!input.isFocused()) input.setText(String.valueOf(slot.intervalMs));
            SeekBar seek = row.findViewById(R.id.interval_seek);
            int shown = Math.max(50, Math.min(5000, slot.intervalMs));
            if (seek.getProgress() != shown) seek.setProgress(shown);
            String state;
            if (!slot.enabled) state = getString(R.string.enabled_off);
            else if (paused) state = getString(R.string.summary_paused, slot.session.clicks());
            else if (running) state = getString(R.string.countdown_unlimited, slot.session.clicks());
            else state = "";
            if (!state.isEmpty()) intervalShort.setText(speedText(slot) + " · " + state);
        }
        binding = false;
    }

    private void paintSpeed(View row, ClickerBoard.Slot slot) {
        TextView speed = row.findViewById(R.id.speed);
        if (speed == null) return;
        speed.setText(speedText(slot));
        boolean capped = slot.intervalMs < ClickerBoard.DEVICE_FLOOR_MS || board.overBudget();
        speed.setTextColor(capped ? 0xFFFFB15A : 0xFFB7C2B8);
    }

    private String speedText(ClickerBoard.Slot slot) {
        int real = ClickerBoard.effectiveInterval(slot.intervalMs);
        String cps = formatCps(real);
        if (slot.intervalMs < real) {
            return getString(R.string.interval_capped, slot.intervalMs, real, cps);
        }
        return getString(R.string.interval_real, real, cps);
    }

    private String formatCps(int intervalMs) {
        double cps = 1000.0 / Math.max(1, intervalMs);
        return String.format(Locale.US, cps >= 10 ? "%.0f" : "%.1f", cps);
    }

    private void paintMarkers() {
        for (int i = 0; i < ClickerBoard.MAX; i++) {
            if (markers[i] == null || !board.slot(i).present) continue;
            ClickerBoard.Slot slot = board.slot(i);
            boolean running = slot.session.isRunning() && !slot.session.isPaused();
            boolean paused = slot.session.isPaused();
            int visual = (running ? 1 : 0) | (paused ? 2 : 0) | (slot.enabled ? 4 : 0) | (board.selected() == i ? 8 : 0);
            if (markerVisual[i] == visual) continue;
            markerVisual[i] = visual;
            int stroke = dp(board.selected() == i || running ? 4 : 3);
            GradientDrawable bg = circle(0xF0101410, 0);
            bg.setStroke(stroke, slot.enabled ? COLORS[i] : 0x66B7C2B8);
            markers[i].setBackground(bg);
            markers[i].setAlpha(slot.enabled ? 1f : 0.4f);
        }
    }

    private void applyMode() {
        if (panel == null || panelParams == null) return;
        int mode = prefs.panelMode();
        sizeButton.setText(mode == 0 ? R.string.size_small : mode == 1 ? R.string.size_medium : R.string.size_large);
        boolean details = mode == 2;
        boolean list = mode != 0;
        scroller.setVisibility(list ? View.VISIBLE : View.GONE);
        addButton.setVisibility(list ? View.VISIBLE : View.GONE);
        durationBox.setVisibility(details ? View.VISIBLE : View.GONE);
        closeButton.setVisibility(list ? View.VISIBLE : View.GONE);
        if (list) {
            int max = Math.round(safeArea().height() * (details ? 0.42f : 0.28f));
            scroller.getLayoutParams().height = Math.max(dp(96), max);
        }
        panelParams.width = dp(modeWidth());
        clampPanel();
        panelParams.x = panelX;
        panelParams.y = panelY;
        try {
            wm.updateViewLayout(panel, panelParams);
        } catch (RuntimeException ignored) {
        }
    }

    private int modeWidth() {
        int mode = prefs.panelMode();
        if (mode == 0) return 236;
        if (mode == 2) return 320;
        return 280;
    }

    private void wireDuration(int id, int value) {
        panel.findViewById(id).setOnClickListener(v -> {
            prefs.duration(value);
            if (board.anyActive()) board.applyDurationAll(SystemClock.elapsedRealtime(), value);
            refreshUi();
        });
    }

    private void paintChip(int id, boolean on) {
        if (panel == null) return;
        Button button = panel.findViewById(id);
        paintButton(button, on);
    }

    private void paintButton(Button button, boolean on) {
        button.setBackgroundResource(on ? R.drawable.chip_on : R.drawable.chip);
        button.setTextColor(on ? 0xFFD6FF4A : 0xFFB7C2B8);
    }

    private void placeAll() {
        for (int i = 0; i < ClickerBoard.MAX; i++) if (markers[i] != null) placeMarker(i);
        if (panelParams != null && panel != null) {
            panelParams.x = panelX;
            panelParams.y = panelY;
            try {
                wm.updateViewLayout(panel, panelParams);
            } catch (RuntimeException ignored) {
            }
        }
        if (nubParams != null && nub != null) {
            nubParams.x = panelX;
            nubParams.y = panelY;
            try {
                wm.updateViewLayout(nub, nubParams);
            } catch (RuntimeException ignored) {
            }
        }
    }

    private void placeMarker(int index) {
        if (markers[index] == null || markerParams[index] == null) return;
        int half = markerSize() / 2;
        markerParams[index].x = board.slot(index).x - half;
        markerParams[index].y = board.slot(index).y - half;
        try {
            wm.updateViewLayout(markers[index], markerParams[index]);
        } catch (RuntimeException ignored) {
        }
    }

    private void clampAll() {
        for (int i = 0; i < ClickerBoard.MAX; i++) if (board.slot(i).present) clampCenter(i);
        clampPanel();
    }

    private void clampCenter(int index) {
        Rect area = safeArea();
        int half = markerSize() / 2;
        int minX = area.left + half;
        int maxX = area.right - half;
        int minY = area.top + half;
        int maxY = area.bottom - half;
        if (maxX < minX) {
            minX = half;
            maxX = Math.max(half, screenWidth() - half);
        }
        if (maxY < minY) {
            minY = half;
            maxY = Math.max(half, screenHeight() - half);
        }
        ClickerBoard.Slot slot = board.slot(index);
        int x = Math.max(minX, Math.min(maxX, slot.x));
        int y = Math.max(minY, Math.min(maxY, slot.y));
        if (x != slot.x || y != slot.y) board.move(index, x, y);
    }

    private void clampPanel() {
        Rect area = safeArea();
        int width = panel != null && panel.getWidth() > 0 ? panel.getWidth() : dp(nub != null ? 52 : modeWidth());
        int height = panel != null && panel.getHeight() > 0 ? panel.getHeight() : dp(nub != null ? 52 : 96);
        int maxX = Math.max(area.left, area.right - width);
        int maxY = Math.max(area.top, area.bottom - height);
        panelX = Math.max(area.left, Math.min(maxX, panelX));
        panelY = Math.max(area.top, Math.min(maxY, panelY));
    }

    private void setPass(int index, boolean pass) {
        if (index < 0 || markerParams[index] == null || markers[index] == null) return;
        markerParams[index].flags = baseFlags() | (pass ? WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE : 0);
        try {
            wm.updateViewLayout(markers[index], markerParams[index]);
        } catch (RuntimeException ignored) {
        }
    }

    private void setTyping(boolean typing) {
        if (panel == null || panelParams == null) return;
        panelParams.flags = baseFlags();
        if (typing) panelParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        try {
            wm.updateViewLayout(panel, panelParams);
        } catch (RuntimeException ignored) {
        }
    }

    private void clearTyping() {
        setTyping(false);
    }

    private WindowManager.LayoutParams overlayParams(int width, int height) {
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                width,
                height,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                baseFlags(),
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 30) {
            params.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        } else if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return params;
    }

    private int baseFlags() {
        return WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
    }

    private GradientDrawable circle(int fill, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.OVAL);
        drawable.setColor(fill);
        if (stroke != 0) drawable.setStroke(dp(3), stroke);
        return drawable;
    }

    private Rect safeArea() {
        Rect rect = new Rect(0, 0, screenWidth(), screenHeight());
        if (Build.VERSION.SDK_INT >= 30 && wm != null) {
            android.graphics.Insets bars = wm.getMaximumWindowMetrics().getWindowInsets()
                    .getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            rect.inset(bars.left, bars.top, bars.right, bars.bottom);
        }
        if (rect.width() < dp(120) || rect.height() < dp(160)) {
            return new Rect(0, 0, screenWidth(), screenHeight());
        }
        return rect;
    }

    @SuppressWarnings("deprecation")
    private int screenWidth() {
        return screen()[0];
    }

    @SuppressWarnings("deprecation")
    private int screenHeight() {
        return screen()[1];
    }

    @SuppressWarnings("deprecation")
    private int[] screen() {
        if (wm != null && Build.VERSION.SDK_INT >= 30) {
            Rect bounds = wm.getMaximumWindowMetrics().getBounds();
            return new int[]{bounds.width(), bounds.height()};
        }
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        return new int[]{dm.widthPixels, dm.heightPixels};
    }

    private int markerSize() {
        return dp(52);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void saveRoster() {
        prefs.roster(board.encode());
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW);
        channel.setDescription(getString(R.string.channel_desc));
        channel.setSound(null, null);
        channel.enableVibration(false);
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private boolean enterForeground() {
        return publishNotification(true);
    }

    private void maybeNotify() {
        if (SystemClock.elapsedRealtime() - lastNotificationAt > 1000L) publishNotification(false);
    }

    private boolean publishNotification(boolean foreground) {
        Notification notification = buildNotification();
        try {
            if (foreground || !foregroundStarted) {
                if (Build.VERSION.SDK_INT >= 34) {
                    startForeground(
                            NOTIF_ID,
                            notification,
                            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
                } else {
                    startForeground(NOTIF_ID, notification);
                }
                foregroundStarted = true;
            } else {
                NotificationManager manager = getSystemService(NotificationManager.class);
                if (manager != null) manager.notify(NOTIF_ID, notification);
            }
            lastNotificationAt = SystemClock.elapsedRealtime();
            return true;
        } catch (RuntimeException ex) {
            foregroundStarted = false;
            return false;
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean running = board.anyRunningUnpaused();
        String text = running
                ? getString(R.string.notif_running, board.runningCount(), board.totalClicks())
                : getString(R.string.notif_idle);
        Notification.Builder builder = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(text)
                .setContentIntent(content)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE);
        if (running) {
            Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
            PendingIntent stopPi = PendingIntent.getService(
                    this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            builder.addAction(android.R.drawable.ic_media_pause, getString(R.string.notif_stop), stopPi);
        }
        return builder.build();
    }
}
