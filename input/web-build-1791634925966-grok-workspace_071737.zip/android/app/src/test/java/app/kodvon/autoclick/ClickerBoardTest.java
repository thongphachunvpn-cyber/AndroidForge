package app.kodvon.autoclick;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ClickerBoardTest {
    @Test
    public void stopsAtFiveAndKeepsIndependentIntervals() {
        ClickerBoard board = new ClickerBoard();
        for (int i = 0; i < 5; i++) assertEquals(i, board.add(i * 10, i));
        assertTrue(board.isFull());
        assertEquals(-1, board.add(9, 9));
        assertEquals(500, board.slot(0).intervalMs);
        assertEquals(1000, board.slot(1).intervalMs);
        assertEquals(300, board.slot(3).intervalMs);
        board.setInterval(1, 1500);
        assertEquals(1500, board.slot(1).intervalMs);
        assertEquals(500, board.slot(0).intervalMs);
        assertEquals(2000, board.slot(2).intervalMs);
    }

    @Test
    public void movingOnePointDoesNotMoveAnother() {
        ClickerBoard board = new ClickerBoard();
        board.add(10, 20);
        board.add(30, 40);
        board.move(1, 80, 90);
        assertEquals(10, board.slot(0).x);
        assertEquals(20, board.slot(0).y);
        assertEquals(80, board.slot(1).x);
        assertEquals(90, board.slot(1).y);
    }

    @Test
    public void pauseHoldsOnePointWithoutResettingItsCount() {
        ClickerBoard board = new ClickerBoard();
        board.add(1, 1);
        board.add(2, 2);
        assertTrue(board.startOne(0, 1_000L, 0));
        int gen = board.slot(0).session.beginGesture();
        assertTrue(gen > 0);
        assertTrue(board.slot(0).session.onGestureResult(gen, true));
        board.pauseOne(0);
        assertEquals(-1, board.pollDue(1_500L, false));
        assertTrue(board.resumeOne(0, 2_050L));
        assertEquals(0, board.pollDue(2_050L, false));
        assertEquals(1, board.slot(0).session.clicks());
        assertTrue(board.startOne(1, 3_000L, 60_000));
        assertEquals(0, board.slot(1).session.clicks());
        assertEquals(1, board.slot(0).session.clicks());
    }

    @Test
    public void dispatcherBusyDoesNotHandOutASecondPoint() {
        ClickerBoard board = new ClickerBoard();
        board.add(1, 1);
        board.add(2, 2);
        board.startEnabled(0L, 0);
        assertEquals(0, board.pollDue(0L, false));
        assertEquals(-1, board.pollDue(0L, true));
    }

    @Test
    public void countModeStopsWithoutTouchingTheOtherPoint() {
        ClickerBoard board = new ClickerBoard();
        board.add(1, 1);
        board.add(2, 2);
        board.setContinuous(0, false);
        board.setTargetCount(0, 1);
        board.startEnabled(0L, 0);
        int first = board.pollDue(0L, false);
        int gen = board.slot(first).session.beginGesture();
        assertEquals(2, board.afterGesture(first, gen, true, false, 30L, 30L));
        assertFalse(board.slot(0).session.isRunning());
        assertTrue(board.slot(1).session.isRunning());
        assertEquals(1, board.slot(0).session.clicks());
    }

    @Test
    public void customIntervalIsNotSnappedToTheOldPreset() {
        assertEquals(550, ClickerBoard.clampCustomInterval(550));
        assertEquals(50, ClickerBoard.clampCustomInterval(1));
        assertEquals(10_000, ClickerBoard.clampCustomInterval(99_000));
        assertEquals(80, ClickerBoard.effectiveInterval(50));
        assertEquals(550, ClickerBoard.effectiveInterval(550));
        assertEquals(520L, ClickerBoard.delayAfter(550, 30L, true));
        assertEquals(80L, ClickerBoard.delayAfter(50, 0L, false));
    }

    @Test
    public void sharedSpeedWarnsOnlyWhenPointsExceedTheDevice() {
        ClickerBoard calm = new ClickerBoard();
        calm.add(1, 1);
        calm.setInterval(0, 50);
        assertFalse(calm.overBudget());
        calm.add(2, 2);
        calm.setInterval(1, 80);
        assertTrue(calm.overBudget());
        calm.setEnabled(1, false);
        assertFalse(calm.overBudget());
    }

    @Test
    public void rosterRoundTripAndDelete() {
        ClickerBoard board = new ClickerBoard();
        board.add(4, 5);
        board.add(6, 7);
        board.setInterval(1, 1250);
        board.setContinuous(1, false);
        board.setTargetCount(1, 8);
        board.setEnabled(0, false);
        String raw = board.encode();
        ClickerBoard copy = new ClickerBoard();
        assertEquals(2, copy.decode(raw));
        assertFalse(copy.slot(0).enabled);
        assertEquals(500, copy.slot(0).intervalMs);
        assertEquals(4, copy.slot(0).x);
        assertFalse(copy.slot(1).continuous);
        assertEquals(1250, copy.slot(1).intervalMs);
        assertEquals(8, copy.slot(1).targetCount);
        assertTrue(copy.remove(0));
        assertEquals(1, copy.count());
        assertFalse(copy.slot(0).present);
        assertEquals("", new ClickerBoard().encode());
    }

    @Test
    public void stopAllDropsALateGesture() {
        ClickerBoard board = new ClickerBoard();
        board.add(1, 1);
        board.startOne(0, 0L, 0);
        int gen = board.slot(0).session.beginGesture();
        board.stopAll();
        assertEquals(0, board.afterGesture(0, gen, true, false, 10L, 10L));
        assertEquals(0, board.slot(0).session.clicks());
        assertFalse(board.anyActive());
    }
}
