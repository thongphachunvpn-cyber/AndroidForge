import java.io.File
import java.util.Properties

plugins {
    id("com.android.application")
}

val keystoreProperties = Properties()
val keystorePropertiesFile = sequenceOf(
    rootProject.file("keystore.properties"),
    rootProject.file("android/keystore.properties"),
).firstOrNull { it.exists() }
keystorePropertiesFile?.inputStream()?.use { keystoreProperties.load(it) }

fun secret(envName: String, propName: String): String? {
    val fromEnv = System.getenv(envName)?.trim()?.takeIf { it.isNotEmpty() }
    if (fromEnv != null) return fromEnv
    return keystoreProperties.getProperty(propName)?.trim()?.takeIf { it.isNotEmpty() }
}

val releaseStorePath = secret("KODVON_STORE_FILE", "storeFile")
val releaseStorePassword = secret("KODVON_STORE_PASSWORD", "storePassword")
val releaseKeyAlias = secret("KODVON_KEY_ALIAS", "keyAlias")
val releaseKeyPassword = secret("KODVON_KEY_PASSWORD", "keyPassword")
val releaseStoreFile: File? = releaseStorePath?.let { path ->
    val candidate = File(path)
    if (candidate.isAbsolute) candidate
    else sequenceOf(
        rootProject.file(path),
        rootProject.file("android/$path"),
    ).firstOrNull { it.exists() } ?: rootProject.file(path)
}
val releaseSigningReady = releaseStoreFile != null &&
    releaseStoreFile.exists() &&
    releaseStorePassword != null &&
    releaseKeyAlias != null &&
    releaseKeyPassword != null

android {
    namespace = "app.kodvon.autoclick"
    compileSdk = 36

    defaultConfig {
        applicationId = "app.kodvon.autoclick"
        minSdk = 26
        targetSdk = 36
        versionCode = 3
        versionName = "2.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    signingConfigs {
        if (releaseSigningReady) {
            create("release") {
                storeFile = releaseStoreFile!!
                storePassword = releaseStorePassword!!
                keyAlias = releaseKeyAlias!!
                keyPassword = releaseKeyPassword!!
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (releaseSigningReady) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    lint {
        abortOnError = true
        checkReleaseBuilds = true
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}
