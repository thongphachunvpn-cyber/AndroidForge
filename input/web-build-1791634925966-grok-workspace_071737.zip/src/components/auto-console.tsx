import { useEffect, useRef, useState } from "react";
import { clsx } from "clsx";

const COLORS = ["#d6ff4a", "#ff4d2e", "#3ee0ff", "#c084fc", "#ffb15a"];
const DEFAULTS = [500, 1000, 2000, 300, 1500];
const FLOOR = 80;
const DURATIONS = [
  { ms: 0, label: "ไม่จำกัด" },
  { ms: 60_000, label: "1 นาที" },
  { ms: 300_000, label: "5 นาที" },
  { ms: 1_800_000, label: "30 นาที" },
];

type Run = "stop" | "run" | "pause";
type Clicker = {
  id: number;
  enabled: boolean;
  interval: number;
  continuous: boolean;
  target: number;
  clicks: number;
  x: number;
  y: number;
  run: Run;
  nextDue: number;
};

function clampInterval(value: number) {
  if (!Number.isFinite(value)) return 500;
  return Math.max(50, Math.min(10_000, Math.round(value)));
}

function effective(ms: number) {
  return Math.max(FLOOR, clampInterval(ms));
}

function cps(ms: number) {
  const value = 1000 / effective(ms);
  return value >= 10 ? value.toFixed(0) : value.toFixed(1);
}

function makeClicker(id: number, x: number, y: number): Clicker {
  return {
    id,
    enabled: true,
    interval: DEFAULTS[id] ?? 500,
    continuous: true,
    target: 20,
    clicks: 0,
    x,
    y,
    run: "stop",
    nextDue: 0,
  };
}

export function AutoConsole() {
  const stageRef = useRef<HTMLDivElement>(null);
  const clickersRef = useRef<Clicker[]>([]);
  const deadlineRef = useRef(0);
  const drag = useRef<{ id: number; dx: number; dy: number } | null>(null);
  const panelDrag = useRef<{ dx: number; dy: number } | null>(null);
  const moved = useRef(false);

  const [clickers, setClickers] = useState<Clicker[]>(() => [makeClicker(0, 128, 168)]);
  const [selected, setSelected] = useState(0);
  const [panel, setPanel] = useState({ x: 12, y: 12, mode: 1, hidden: false });
  const [durationMs, setDurationMs] = useState(300_000);
  const [leftMs, setLeftMs] = useState(0);
  const [reward, setReward] = useState(0);
  const [lamp, setLamp] = useState(false);
  const [note, setNote] = useState("ลากวงกลมไปจุดที่จะแตะ แล้วกดเริ่ม จุดกับแผงแยกกัน");
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number; color: string }[]>([]);
  const [fullNotice, setFullNotice] = useState("");

  clickersRef.current = clickers;

  const enabledRate = clickers
    .filter((item) => item.enabled)
    .reduce((sum, item) => sum + 1000 / effective(item.interval), 0);
  const overBudget = enabledRate > 1000 / FLOOR + 0.2;
  const running = clickers.some((item) => item.run === "run");
  const paused = clickers.some((item) => item.run === "pause");
  const totalClicks = clickers.reduce((sum, item) => sum + item.clicks, 0);

  useEffect(() => {
    const timer = window.setInterval(() => {
      const stage = stageRef.current;
      const now = Date.now();
      if (deadlineRef.current > 0 && now >= deadlineRef.current) {
        deadlineRef.current = 0;
        setLeftMs(0);
        setClickers((prev) => prev.map((item) => (item.run === "stop" ? item : { ...item, run: "stop" })));
        setNote("ครบเวลาที่ตั้งไว้ จึงหยุดทุกจุด");
        return;
      }
      if (deadlineRef.current > 0) setLeftMs(Math.max(0, deadlineRef.current - now));
      const due = clickersRef.current
        .filter((item) => item.enabled && item.run === "run" && item.nextDue <= now)
        .sort((a, b) => a.nextDue - b.nextDue || a.id - b.id)[0];
      if (!due || !stage) return;
      const marker = stage.querySelector<HTMLElement>(`[data-marker="${due.id}"]`);
      const stageBox = stage.getBoundingClientRect();
      const box = marker?.getBoundingClientRect();
      const x = box ? box.left + box.width / 2 : stageBox.left + due.x + 24;
      const y = box ? box.top + box.height / 2 : stageBox.top + due.y + 24;
      const hit = document.elementsFromPoint(x, y).find((el) => {
        return stage.contains(el) && el instanceof HTMLElement && Boolean(el.dataset.hit);
      }) as HTMLElement | undefined;
      if (hit?.dataset.hit === "reward") setReward((n) => n + 1);
      if (hit?.dataset.hit === "lamp") setLamp((on) => !on);
      const rippleId = now + due.id;
      setRipples((items) => [
        ...items.slice(-8),
        { id: rippleId, x: x - stageBox.left, y: y - stageBox.top, color: COLORS[due.id] ?? "#d6ff4a" },
      ]);
      window.setTimeout(() => {
        setRipples((items) => items.filter((item) => item.id !== rippleId));
      }, 420);
      const next = clickersRef.current.map((item) => {
        if (item.id !== due.id) return item;
        const clicks = item.clicks + 1;
        const done = !item.continuous && clicks >= item.target;
        return { ...item, clicks, run: done ? ("stop" as const) : item.run, nextDue: now + effective(item.interval) };
      });
      clickersRef.current = next;
      setClickers(next);
    }, 40);
    return () => window.clearInterval(timer);
  }, []);

  function patch(id: number, change: Partial<Clicker>) {
    setClickers((prev) => prev.map((item) => (item.id === id ? { ...item, ...change } : item)));
  }

  function startOne(id: number) {
    const now = Date.now();
    if (durationMs > 0 && deadlineRef.current <= now) {
      deadlineRef.current = now + durationMs;
      setLeftMs(durationMs);
    }
    setClickers((prev) =>
      prev.map((item) => {
        if (item.id !== id || !item.enabled) return item;
        if (item.run === "pause") return { ...item, run: "run", nextDue: now };
        if (item.run === "run") return item;
        return { ...item, run: "run", clicks: 0, nextDue: now };
      }),
    );
    setNote("แตะตรงกลางวงกลม ไม่ใช่ตรงแผงควบคุม");
    setFullNotice("");
  }

  function startAll() {
    const now = Date.now();
    const targets = clickersRef.current.filter((item) => item.enabled && item.run !== "run");
    if (targets.length === 0 && !clickersRef.current.some((item) => item.enabled && item.run === "run")) {
      setFullNotice("ยังไม่มีตัวคลิกที่เปิดอยู่");
      return;
    }
    if (durationMs > 0) {
      deadlineRef.current = now + durationMs;
      setLeftMs(durationMs);
    }
    setClickers((prev) =>
      prev.map((item) => {
        if (!item.enabled || item.run === "run") return item;
        if (item.run === "pause") return { ...item, run: "run", nextDue: now };
        return { ...item, run: "run", clicks: 0, nextDue: now };
      }),
    );
    setNote("เริ่มทุกจุดที่เปิดไว้ แต่ละจุดใช้ความเร็วของตัวเอง");
    setFullNotice("");
  }

  function pauseAll() {
    setClickers((prev) => prev.map((item) => (item.run === "run" ? { ...item, run: "pause" } : item)));
    setNote("พักทุกจุด จำนวนครั้งยังอยู่");
  }

  function resumeAll() {
    const now = Date.now();
    setClickers((prev) => prev.map((item) => (item.run === "pause" ? { ...item, run: "run", nextDue: now } : item)));
    setNote("ทำต่อจากจำนวนเดิม");
  }

  function stopAll() {
    deadlineRef.current = 0;
    setLeftMs(0);
    const clicks = clickersRef.current.reduce((sum, item) => sum + item.clicks, 0);
    setClickers((prev) => prev.map((item) => ({ ...item, run: "stop" })));
    setNote(clicks > 0 ? `หยุดทั้งหมด · กดไป ${clicks} ครั้ง` : "หยุดแล้ว");
  }

  function addClicker() {
    setClickers((prev) => {
      if (prev.length >= 5) return prev;
      const used = new Set(prev.map((item) => item.id));
      let id = 0;
      while (used.has(id)) id += 1;
      const created = makeClicker(id, 70 + id * 26, 150 + (id % 2) * 42);
      setSelected(id);
      return [...prev, created];
    });
    setFullNotice("");
    setNote("เพิ่มจุดใหม่แล้ว ลากวงกลมไปตำแหน่งที่จะแตะ");
  }

  function onMarkerDown(event: React.PointerEvent<HTMLButtonElement>, id: number) {
    const item = clickersRef.current.find((entry) => entry.id === id);
    if (!item) return;
    moved.current = false;
    drag.current = { id, dx: event.clientX - item.x, dy: event.clientY - item.y };
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function onMarkerMove(event: React.PointerEvent<HTMLButtonElement>) {
    if (!drag.current || !stageRef.current) return;
    const bounds = stageRef.current.getBoundingClientRect();
    const next = {
      x: Math.min(bounds.width - 48, Math.max(0, event.clientX - drag.current.dx)),
      y: Math.min(bounds.height - 48, Math.max(0, event.clientY - drag.current.dy)),
    };
    const current = clickersRef.current.find((item) => item.id === drag.current?.id);
    if (current && Math.hypot(next.x - current.x, next.y - current.y) > 3) moved.current = true;
    patch(drag.current.id, next);
  }

  function onPanelDown(event: React.PointerEvent<HTMLDivElement>) {
    panelDrag.current = { dx: event.clientX - panel.x, dy: event.clientY - panel.y };
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function onPanelMove(event: React.PointerEvent<HTMLDivElement>) {
    if (!panelDrag.current || !stageRef.current) return;
    const bounds = stageRef.current.getBoundingClientRect();
    const width = panel.mode === 0 ? 210 : panel.mode === 2 ? 292 : 250;
    setPanel((current) => ({
      ...current,
      x: Math.min(bounds.width - width, Math.max(0, event.clientX - (panelDrag.current?.dx ?? 0))),
      y: Math.min(bounds.height - 72, Math.max(0, event.clientY - (panelDrag.current?.dy ?? 0))),
    }));
  }

  const modeLabel = panel.mode === 0 ? "เล็ก" : panel.mode === 2 ? "ใหญ่" : "กลาง";

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-3xl flex-col gap-4 px-4 py-4 sm:px-6 sm:py-6">
      <header>
        <p className="font-mono text-xs tracking-widest text-lime">Android · 5 จุด</p>
        <h1 className="text-balance text-3xl font-semibold tracking-tight sm:text-4xl">กดวน</h1>
        <p className="max-w-xl text-pretty text-sm text-fog">
          แผงลอยอยู่เหนือแอปอื่น มีจุดคลิกได้สูงสุด 5 จุด แต่ละจุดตั้งความเร็วเอง วงกลมคือตำแหน่งที่ถูกแตะ แผงควบคุมย้ายและย่อได้โดยไม่ดึงจุดคลิก
        </p>
      </header>

      <section className="rounded-card border border-line bg-panel p-4">
        <h2 className="text-lg font-semibold">ไฟล์ติดตั้งบนเครื่อง</h2>
        <p className="mt-1 text-sm text-pretty text-fog">
          รุ่นทดสอบ เซ็นด้วยคีย์ดีบักสำหรับติดตั้งเอง ยังไม่ใช่ไฟล์ Play Store เปิดไฟล์บนมือถือแล้วอนุญาตการติดตั้งจากเบราว์เซอร์ถ้าเครื่องถาม iOS ใช้ไฟล์นี้ไม่ได้
        </p>
        <a
          href="/kodvon-autoclick.apk"
          download="kodvon-autoclick.apk"
          className="mt-3 inline-flex min-h-12 items-center justify-center rounded-xl bg-lime px-4 font-semibold text-lime-ink"
        >
          ดาวน์โหลด APK
        </a>
      </section>

      <section className="rounded-card border border-line bg-panel p-3 sm:p-4">
        <p className="mb-3 text-sm text-fog" aria-live="polite">
          {note}
          {running ? ` · กำลังกด ${clickers.filter((item) => item.run === "run").length} จุด · ${totalClicks} ครั้ง` : ""}
          {durationMs > 0 && running ? ` · เหลือ ${clock(leftMs)}` : ""}
        </p>
        <div
          ref={stageRef}
          className="relative mx-auto h-[40rem] max-h-[78vh] w-full max-w-sm overflow-hidden rounded-card border border-line bg-ink"
        >
          <div className="flex items-center justify-between border-b border-line px-4 py-3 text-sm">
            <span>แอปอื่น</span>
            <span className="font-mono text-xs text-fog">ด้านล่างจุดคลิก</span>
          </div>
          <div className="space-y-3 p-4">
            <button
              type="button"
              data-hit="reward"
              onClick={() => setReward((n) => n + 1)}
              className="flex min-h-28 w-full flex-col items-start justify-between rounded-xl border border-line bg-panel-2 p-4 text-left"
            >
              <span className="text-sm text-fog">รับรางวัล</span>
              <span className="font-mono text-4xl tabular-nums">{reward}</span>
            </button>
            <button
              type="button"
              data-hit="lamp"
              aria-pressed={lamp}
              onClick={() => setLamp((on) => !on)}
              className="flex min-h-12 w-full items-center justify-between rounded-xl border border-line px-3"
            >
              <span>ไฟในแอป</span>
              <span className={clsx("h-6 w-11 rounded-full", lamp ? "bg-lime" : "bg-line")}>
                <span className={clsx("mt-0.5 block size-5 rounded-full bg-paper", lamp ? "ml-5" : "ml-0.5")} />
              </span>
            </button>
            <p className="text-sm text-pretty text-fog">
              ลากวงกลมไปทับปุ่ม แล้วกดเริ่มที่แผง การแตะเกิดตรงกลางวงกลม ย้ายจุดระหว่างทำงานได้
            </p>
          </div>

          {ripples.map((ripple) => (
            <span
              key={ripple.id}
              className="kod-ripple pointer-events-none absolute z-20 size-14 rounded-full border-2"
              style={{ left: ripple.x, top: ripple.y, borderColor: ripple.color }}
            />
          ))}

          {clickers.map((item) => (
            <button
              key={item.id}
              type="button"
              data-marker={item.id}
              aria-label={`ตัวคลิก ${item.id + 1} ลากเพื่อย้ายจุดกด`}
              onPointerDown={(event) => onMarkerDown(event, item.id)}
              onPointerMove={onMarkerMove}
              onPointerUp={() => {
                drag.current = null;
              }}
              onClick={() => {
                if (moved.current) {
                  moved.current = false;
                  return;
                }
                setSelected(item.id);
              }}
              className={clsx(
                "absolute z-30 size-12 touch-none rounded-full border-4 bg-ink text-sm font-semibold",
                !item.enabled && "opacity-40",
              )}
              style={{
                left: item.x,
                top: item.y,
                borderColor: COLORS[item.id],
                color: COLORS[item.id],
                boxShadow: selected === item.id ? `0 0 0 3px ${COLORS[item.id]}55` : undefined,
              }}
            >
              {item.id + 1}
              <span className="sr-only">
                {item.run === "run" ? "กำลังกด" : item.run === "pause" ? "พัก" : "หยุด"} {item.clicks} ครั้ง
              </span>
            </button>
          ))}

          {panel.hidden ? (
            <button
              type="button"
              className="absolute z-40 flex size-12 items-center justify-center rounded-full bg-lime text-xs font-semibold text-lime-ink"
              style={{ left: panel.x, top: panel.y }}
              onClick={() => setPanel((current) => ({ ...current, hidden: false }))}
            >
              แผง
            </button>
          ) : (
            <div
              className="absolute z-40 rounded-xl border border-line bg-panel p-2 shadow-lg"
              style={{ left: panel.x, top: panel.y, width: panel.mode === 0 ? 210 : panel.mode === 2 ? 292 : 250 }}
            >
              <div className="flex items-center gap-1">
                <div
                  className="min-h-11 flex-1 cursor-grab touch-none rounded-lg px-2 py-2 text-sm font-semibold"
                  onPointerDown={onPanelDown}
                  onPointerMove={onPanelMove}
                  onPointerUp={() => {
                    panelDrag.current = null;
                  }}
                >
                  กดวน
                  <span className="mt-0.5 block text-[11px] font-normal text-fog">ลากแถบนี้เพื่อย้ายแผง</span>
                </div>
                <button
                  type="button"
                  className="min-h-11 rounded-lg border border-line px-2 text-xs"
                  onClick={() => setPanel((current) => ({ ...current, mode: (current.mode + 1) % 3 }))}
                >
                  {modeLabel}
                </button>
                <button
                  type="button"
                  className="min-h-11 rounded-lg border border-line px-2 text-xs"
                  onClick={() => setPanel((current) => ({ ...current, hidden: true }))}
                >
                  ซ่อน
                </button>
              </div>
              <div className="mt-1 grid grid-cols-4 gap-1">
                <button type="button" className="col-span-1 min-h-11 rounded-lg bg-lime text-xs font-semibold text-lime-ink" onClick={startAll}>
                  เริ่ม
                </button>
                <button type="button" className="min-h-11 rounded-lg border border-line text-xs" onClick={pauseAll}>
                  พัก
                </button>
                <button type="button" className="min-h-11 rounded-lg border border-line text-xs" onClick={resumeAll}>
                  ต่อ
                </button>
                <button type="button" className="min-h-11 rounded-lg bg-ember text-xs font-semibold text-ember-ink" onClick={stopAll}>
                  หยุด
                </button>
              </div>
              <p className="mt-1 text-[11px] text-fog">
                {running
                  ? `กำลังกด ${clickers.filter((item) => item.run === "run").length} จุด`
                  : paused
                    ? "พักอยู่"
                    : "พร้อม"}
                {durationMs > 0 && running ? ` · ${clock(leftMs)}` : ""}
              </p>
              {overBudget ? (
                <p className="mt-1 text-[11px] text-pretty text-[#ffb15a]">
                  รวมกันเร็วกว่าที่เครื่องส่งแตะได้ ส่งทีละจุด ประมาณ 12 ครั้ง/วินาที จังหวะจริงจะไม่เร็วกว่านี้
                </p>
              ) : null}
              {panel.mode !== 0 ? (
                <div className={clsx("mt-2 space-y-2 overflow-y-auto pr-1", panel.mode === 2 ? "max-h-72" : "max-h-48")}>
                  {clickers.map((item) => (
                    <div key={item.id} className="rounded-lg border border-line p-2">
                      <div className="flex items-center gap-2">
                        <span
                          className="flex size-6 items-center justify-center rounded-full text-xs font-semibold text-ink"
                          style={{ background: COLORS[item.id] }}
                        >
                          {item.id + 1}
                        </span>
                        <span className="flex-1 text-sm">ตัวคลิก {item.id + 1}</span>
                        <button
                          type="button"
                          className="min-h-9 rounded-lg border border-line px-2 text-xs"
                          onClick={() => patch(item.id, { enabled: !item.enabled, run: item.enabled ? "stop" : item.run })}
                        >
                          {item.enabled ? "เปิด" : "ปิด"}
                        </button>
                      </div>
                      <p className="mt-1 text-[11px] text-fog">
                        {item.interval < effective(item.interval)
                          ? `ตั้ง ${item.interval} ms · ส่งจริงทุก ${effective(item.interval)} ms (${cps(item.interval)} ครั้ง/วิ)`
                          : `ทุก ${effective(item.interval)} ms · ${cps(item.interval)} ครั้ง/วิ`}
                        {item.run !== "stop" ? ` · ${item.clicks} ครั้ง` : ""}
                      </p>
                      <div className="mt-1 grid grid-cols-3 gap-1">
                        <button type="button" className="min-h-10 rounded-lg bg-lime text-xs font-semibold text-lime-ink disabled:opacity-40" disabled={!item.enabled || item.run === "run"} onClick={() => startOne(item.id)}>
                          เริ่ม
                        </button>
                        <button
                          type="button"
                          className="min-h-10 rounded-lg border border-line text-xs disabled:opacity-40"
                          disabled={item.run === "stop"}
                          onClick={() => patch(item.id, { run: item.run === "pause" ? "run" : "pause", nextDue: Date.now() })}
                        >
                          {item.run === "pause" ? "ต่อ" : "พัก"}
                        </button>
                        <button
                          type="button"
                          className="min-h-10 rounded-lg bg-ember text-xs font-semibold text-ember-ink disabled:opacity-40"
                          disabled={item.run === "stop"}
                          onClick={() => patch(item.id, { run: "stop" })}
                        >
                          หยุด
                        </button>
                      </div>
                      {panel.mode === 2 ? (
                        <div className="mt-2 space-y-2">
                          <div className="flex items-center gap-1">
                            <button type="button" className="min-h-10 min-w-10 rounded-lg border border-line" onClick={() => patch(item.id, { interval: clampInterval(item.interval - 50) })}>
                              −
                            </button>
                            <input
                              aria-label={`ช่วงเวลาตัวคลิก ${item.id + 1} มิลลิวินาที`}
                              inputMode="numeric"
                              className="h-10 w-full rounded-lg border border-line bg-ink text-center text-sm"
                              value={item.interval}
                              onChange={(event) => {
                                const raw = Number(event.target.value);
                                if (!Number.isFinite(raw)) return;
                                if (raw < 50) {
                                  patch(item.id, { interval: raw < 0 ? 50 : raw });
                                  return;
                                }
                                patch(item.id, { interval: clampInterval(raw) });
                              }}
                            />
                            <button type="button" className="min-h-10 min-w-10 rounded-lg border border-line" onClick={() => patch(item.id, { interval: clampInterval(item.interval + 50) })}>
                              +
                            </button>
                          </div>
                          <input
                            aria-label={`ความเร็วตัวคลิก ${item.id + 1}`}
                            type="range"
                            min={50}
                            max={5000}
                            step={50}
                            value={Math.min(5000, item.interval)}
                            onChange={(event) => patch(item.id, { interval: clampInterval(Number(event.target.value)) })}
                          />
                          <div className="grid grid-cols-2 gap-1">
                            <button type="button" className={clsx("min-h-10 rounded-lg border text-xs", item.continuous ? "border-lime text-lime" : "border-line text-fog")} onClick={() => patch(item.id, { continuous: true })}>
                              ต่อเนื่อง
                            </button>
                            <button type="button" className={clsx("min-h-10 rounded-lg border text-xs", !item.continuous ? "border-lime text-lime" : "border-line text-fog")} onClick={() => patch(item.id, { continuous: false })}>
                              ตามจำนวน
                            </button>
                          </div>
                          {!item.continuous ? (
                            <div className="flex items-center gap-1">
                              <button type="button" className="min-h-10 min-w-10 rounded-lg border border-line" onClick={() => patch(item.id, { target: Math.max(1, item.target - (item.target < 20 ? 1 : 5)) })}>
                                −
                              </button>
                              <p className="flex-1 text-center text-sm">{item.target} ครั้ง</p>
                              <button type="button" className="min-h-10 min-w-10 rounded-lg border border-line" onClick={() => patch(item.id, { target: Math.min(100_000, item.target + (item.target < 20 ? 1 : 5)) })}>
                                +
                              </button>
                            </div>
                          ) : null}
                          <button
                            type="button"
                            className="min-h-10 w-full rounded-lg border border-line text-xs"
                            onClick={() => {
                              setClickers((prev) => prev.filter((entry) => entry.id !== item.id));
                              setNote(`ลบตัวคลิก ${item.id + 1} แล้ว`);
                            }}
                          >
                            ลบตัวนี้
                          </button>
                        </div>
                      ) : null}
                    </div>
                  ))}
                  {panel.mode === 2 ? (
                    <div className="grid grid-cols-2 gap-1">
                      {DURATIONS.map((item) => (
                        <button
                          key={item.label}
                          type="button"
                          onClick={() => setDurationMs(item.ms)}
                          className={clsx("min-h-10 rounded-lg border text-xs", durationMs === item.ms ? "border-lime text-lime" : "border-line text-fog")}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  ) : null}
                </div>
              ) : null}
              {panel.mode !== 0 ? (
                <button
                  type="button"
                  className="mt-2 min-h-11 w-full rounded-lg border border-line text-sm disabled:opacity-40"
                  disabled={clickers.length >= 5}
                  onClick={() => {
                    if (clickers.length >= 5) {
                      setFullNotice("ครบ 5 ตัวแล้ว");
                      return;
                    }
                    addClicker();
                  }}
                >
                  {clickers.length >= 5 ? "ครบ 5 ตัวแล้ว" : "เพิ่มตัวคลิก"}
                </button>
              ) : null}
              {fullNotice ? <p className="mt-1 text-[11px] text-[#ffb15a]">{fullNotice}</p> : null}
            </div>
          )}
        </div>
      </section>
    </main>
  );
}

function clock(ms: number) {
  const sec = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`;
}
