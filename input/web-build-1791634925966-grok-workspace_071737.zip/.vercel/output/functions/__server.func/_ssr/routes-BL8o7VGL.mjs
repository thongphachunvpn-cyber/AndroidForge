import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as clsx } from "../_libs/clsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BL8o7VGL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COLORS = [
	"#d6ff4a",
	"#ff4d2e",
	"#3ee0ff",
	"#c084fc",
	"#ffb15a"
];
var DEFAULTS = [
	500,
	1e3,
	2e3,
	300,
	1500
];
var FLOOR = 80;
var DURATIONS = [
	{
		ms: 0,
		label: "ไม่จำกัด"
	},
	{
		ms: 6e4,
		label: "1 นาที"
	},
	{
		ms: 3e5,
		label: "5 นาที"
	},
	{
		ms: 18e5,
		label: "30 นาที"
	}
];
function clampInterval(value) {
	if (!Number.isFinite(value)) return 500;
	return Math.max(50, Math.min(1e4, Math.round(value)));
}
function effective(ms) {
	return Math.max(FLOOR, clampInterval(ms));
}
function cps(ms) {
	const value = 1e3 / effective(ms);
	return value >= 10 ? value.toFixed(0) : value.toFixed(1);
}
function makeClicker(id, x, y) {
	return {
		id,
		enabled: true,
		interval: DEFAULTS[id] ?? 500,
		continuous: true,
		target: 20,
		clicks: 0,
		x,
		y,
		run: "stop",
		nextDue: 0
	};
}
function AutoConsole() {
	const stageRef = (0, import_react.useRef)(null);
	const clickersRef = (0, import_react.useRef)([]);
	const deadlineRef = (0, import_react.useRef)(0);
	const drag = (0, import_react.useRef)(null);
	const panelDrag = (0, import_react.useRef)(null);
	const moved = (0, import_react.useRef)(false);
	const [clickers, setClickers] = (0, import_react.useState)(() => [makeClicker(0, 128, 168)]);
	const [selected, setSelected] = (0, import_react.useState)(0);
	const [panel, setPanel] = (0, import_react.useState)({
		x: 12,
		y: 12,
		mode: 1,
		hidden: false
	});
	const [durationMs, setDurationMs] = (0, import_react.useState)(3e5);
	const [leftMs, setLeftMs] = (0, import_react.useState)(0);
	const [reward, setReward] = (0, import_react.useState)(0);
	const [lamp, setLamp] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("ลากวงกลมไปจุดที่จะแตะ แล้วกดเริ่ม จุดกับแผงแยกกัน");
	const [ripples, setRipples] = (0, import_react.useState)([]);
	const [fullNotice, setFullNotice] = (0, import_react.useState)("");
	clickersRef.current = clickers;
	const overBudget = clickers.filter((item) => item.enabled).reduce((sum, item) => sum + 1e3 / effective(item.interval), 0) > 12.7;
	const running = clickers.some((item) => item.run === "run");
	const paused = clickers.some((item) => item.run === "pause");
	const totalClicks = clickers.reduce((sum, item) => sum + item.clicks, 0);
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => {
			const stage = stageRef.current;
			const now = Date.now();
			if (deadlineRef.current > 0 && now >= deadlineRef.current) {
				deadlineRef.current = 0;
				setLeftMs(0);
				setClickers((prev) => prev.map((item) => item.run === "stop" ? item : {
					...item,
					run: "stop"
				}));
				setNote("ครบเวลาที่ตั้งไว้ จึงหยุดทุกจุด");
				return;
			}
			if (deadlineRef.current > 0) setLeftMs(Math.max(0, deadlineRef.current - now));
			const due = clickersRef.current.filter((item) => item.enabled && item.run === "run" && item.nextDue <= now).sort((a, b) => a.nextDue - b.nextDue || a.id - b.id)[0];
			if (!due || !stage) return;
			const marker = stage.querySelector(`[data-marker="${due.id}"]`);
			const stageBox = stage.getBoundingClientRect();
			const box = marker?.getBoundingClientRect();
			const x = box ? box.left + box.width / 2 : stageBox.left + due.x + 24;
			const y = box ? box.top + box.height / 2 : stageBox.top + due.y + 24;
			const hit = document.elementsFromPoint(x, y).find((el) => {
				return stage.contains(el) && el instanceof HTMLElement && Boolean(el.dataset.hit);
			});
			if (hit?.dataset.hit === "reward") setReward((n) => n + 1);
			if (hit?.dataset.hit === "lamp") setLamp((on) => !on);
			const rippleId = now + due.id;
			setRipples((items) => [...items.slice(-8), {
				id: rippleId,
				x: x - stageBox.left,
				y: y - stageBox.top,
				color: COLORS[due.id] ?? "#d6ff4a"
			}]);
			window.setTimeout(() => {
				setRipples((items) => items.filter((item) => item.id !== rippleId));
			}, 420);
			const next = clickersRef.current.map((item) => {
				if (item.id !== due.id) return item;
				const clicks = item.clicks + 1;
				const done = !item.continuous && clicks >= item.target;
				return {
					...item,
					clicks,
					run: done ? "stop" : item.run,
					nextDue: now + effective(item.interval)
				};
			});
			clickersRef.current = next;
			setClickers(next);
		}, 40);
		return () => window.clearInterval(timer);
	}, []);
	function patch(id, change) {
		setClickers((prev) => prev.map((item) => item.id === id ? {
			...item,
			...change
		} : item));
	}
	function startOne(id) {
		const now = Date.now();
		if (durationMs > 0 && deadlineRef.current <= now) {
			deadlineRef.current = now + durationMs;
			setLeftMs(durationMs);
		}
		setClickers((prev) => prev.map((item) => {
			if (item.id !== id || !item.enabled) return item;
			if (item.run === "pause") return {
				...item,
				run: "run",
				nextDue: now
			};
			if (item.run === "run") return item;
			return {
				...item,
				run: "run",
				clicks: 0,
				nextDue: now
			};
		}));
		setNote("แตะตรงกลางวงกลม ไม่ใช่ตรงแผงควบคุม");
		setFullNotice("");
	}
	function startAll() {
		const now = Date.now();
		if (clickersRef.current.filter((item) => item.enabled && item.run !== "run").length === 0 && !clickersRef.current.some((item) => item.enabled && item.run === "run")) {
			setFullNotice("ยังไม่มีตัวคลิกที่เปิดอยู่");
			return;
		}
		if (durationMs > 0) {
			deadlineRef.current = now + durationMs;
			setLeftMs(durationMs);
		}
		setClickers((prev) => prev.map((item) => {
			if (!item.enabled || item.run === "run") return item;
			if (item.run === "pause") return {
				...item,
				run: "run",
				nextDue: now
			};
			return {
				...item,
				run: "run",
				clicks: 0,
				nextDue: now
			};
		}));
		setNote("เริ่มทุกจุดที่เปิดไว้ แต่ละจุดใช้ความเร็วของตัวเอง");
		setFullNotice("");
	}
	function pauseAll() {
		setClickers((prev) => prev.map((item) => item.run === "run" ? {
			...item,
			run: "pause"
		} : item));
		setNote("พักทุกจุด จำนวนครั้งยังอยู่");
	}
	function resumeAll() {
		const now = Date.now();
		setClickers((prev) => prev.map((item) => item.run === "pause" ? {
			...item,
			run: "run",
			nextDue: now
		} : item));
		setNote("ทำต่อจากจำนวนเดิม");
	}
	function stopAll() {
		deadlineRef.current = 0;
		setLeftMs(0);
		const clicks = clickersRef.current.reduce((sum, item) => sum + item.clicks, 0);
		setClickers((prev) => prev.map((item) => ({
			...item,
			run: "stop"
		})));
		setNote(clicks > 0 ? `หยุดทั้งหมด · กดไป ${clicks} ครั้ง` : "หยุดแล้ว");
	}
	function addClicker() {
		setClickers((prev) => {
			if (prev.length >= 5) return prev;
			const used = new Set(prev.map((item) => item.id));
			let id = 0;
			while (used.has(id)) id += 1;
			const created = makeClicker(id, 70 + id * 26, 150 + id % 2 * 42);
			setSelected(id);
			return [...prev, created];
		});
		setFullNotice("");
		setNote("เพิ่มจุดใหม่แล้ว ลากวงกลมไปตำแหน่งที่จะแตะ");
	}
	function onMarkerDown(event, id) {
		const item = clickersRef.current.find((entry) => entry.id === id);
		if (!item) return;
		moved.current = false;
		drag.current = {
			id,
			dx: event.clientX - item.x,
			dy: event.clientY - item.y
		};
		event.currentTarget.setPointerCapture(event.pointerId);
	}
	function onMarkerMove(event) {
		if (!drag.current || !stageRef.current) return;
		const bounds = stageRef.current.getBoundingClientRect();
		const next = {
			x: Math.min(bounds.width - 48, Math.max(0, event.clientX - drag.current.dx)),
			y: Math.min(bounds.height - 48, Math.max(0, event.clientY - drag.current.dy))
		};
		const current = clickersRef.current.find((item) => item.id === drag.current?.id);
		if (current && Math.hypot(next.x - current.x, next.y - current.y) > 3) moved.current = true;
		patch(drag.current.id, next);
	}
	function onPanelDown(event) {
		panelDrag.current = {
			dx: event.clientX - panel.x,
			dy: event.clientY - panel.y
		};
		event.currentTarget.setPointerCapture(event.pointerId);
	}
	function onPanelMove(event) {
		if (!panelDrag.current || !stageRef.current) return;
		const bounds = stageRef.current.getBoundingClientRect();
		const width = panel.mode === 0 ? 210 : panel.mode === 2 ? 292 : 250;
		setPanel((current) => ({
			...current,
			x: Math.min(bounds.width - width, Math.max(0, event.clientX - (panelDrag.current?.dx ?? 0))),
			y: Math.min(bounds.height - 72, Math.max(0, event.clientY - (panelDrag.current?.dy ?? 0)))
		}));
	}
	const modeLabel = panel.mode === 0 ? "เล็ก" : panel.mode === 2 ? "ใหญ่" : "กลาง";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen w-full max-w-3xl flex-col gap-4 px-4 py-4 sm:px-6 sm:py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-widest text-lime",
					children: "Android · 5 จุด"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-balance text-3xl font-semibold tracking-tight sm:text-4xl",
					children: "กดวน"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-xl text-pretty text-sm text-fog",
					children: "แผงลอยอยู่เหนือแอปอื่น มีจุดคลิกได้สูงสุด 5 จุด แต่ละจุดตั้งความเร็วเอง วงกลมคือตำแหน่งที่ถูกแตะ แผงควบคุมย้ายและย่อได้โดยไม่ดึงจุดคลิก"
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "ไฟล์ติดตั้งบนเครื่อง"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-pretty text-fog",
						children: "รุ่นทดสอบ เซ็นด้วยคีย์ดีบักสำหรับติดตั้งเอง ยังไม่ใช่ไฟล์ Play Store เปิดไฟล์บนมือถือแล้วอนุญาตการติดตั้งจากเบราว์เซอร์ถ้าเครื่องถาม iOS ใช้ไฟล์นี้ไม่ได้"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/kodvon-autoclick.apk",
						download: "kodvon-autoclick.apk",
						className: "mt-3 inline-flex min-h-12 items-center justify-center rounded-xl bg-lime px-4 font-semibold text-lime-ink",
						children: "ดาวน์โหลด APK"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-panel p-3 sm:p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-3 text-sm text-fog",
					"aria-live": "polite",
					children: [
						note,
						running ? ` · กำลังกด ${clickers.filter((item) => item.run === "run").length} จุด · ${totalClicks} ครั้ง` : "",
						durationMs > 0 && running ? ` · เหลือ ${clock(leftMs)}` : ""
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: stageRef,
					className: "relative mx-auto h-[40rem] max-h-[78vh] w-full max-w-sm overflow-hidden rounded-card border border-line bg-ink",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b border-line px-4 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "แอปอื่น" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-fog",
								children: "ด้านล่างจุดคลิก"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"data-hit": "reward",
									onClick: () => setReward((n) => n + 1),
									className: "flex min-h-28 w-full flex-col items-start justify-between rounded-xl border border-line bg-panel-2 p-4 text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-fog",
										children: "รับรางวัล"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-4xl tabular-nums",
										children: reward
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"data-hit": "lamp",
									"aria-pressed": lamp,
									onClick: () => setLamp((on) => !on),
									className: "flex min-h-12 w-full items-center justify-between rounded-xl border border-line px-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ไฟในแอป" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: clsx("h-6 w-11 rounded-full", lamp ? "bg-lime" : "bg-line"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: clsx("mt-0.5 block size-5 rounded-full bg-paper", lamp ? "ml-5" : "ml-0.5") })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-pretty text-fog",
									children: "ลากวงกลมไปทับปุ่ม แล้วกดเริ่มที่แผง การแตะเกิดตรงกลางวงกลม ย้ายจุดระหว่างทำงานได้"
								})
							]
						}),
						ripples.map((ripple) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "kod-ripple pointer-events-none absolute z-20 size-14 rounded-full border-2",
							style: {
								left: ripple.x,
								top: ripple.y,
								borderColor: ripple.color
							}
						}, ripple.id)),
						clickers.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"data-marker": item.id,
							"aria-label": `ตัวคลิก ${item.id + 1} ลากเพื่อย้ายจุดกด`,
							onPointerDown: (event) => onMarkerDown(event, item.id),
							onPointerMove: onMarkerMove,
							onPointerUp: () => {
								drag.current = null;
							},
							onClick: () => {
								if (moved.current) {
									moved.current = false;
									return;
								}
								setSelected(item.id);
							},
							className: clsx("absolute z-30 size-12 touch-none rounded-full border-4 bg-ink text-sm font-semibold", !item.enabled && "opacity-40"),
							style: {
								left: item.x,
								top: item.y,
								borderColor: COLORS[item.id],
								color: COLORS[item.id],
								boxShadow: selected === item.id ? `0 0 0 3px ${COLORS[item.id]}55` : void 0
							},
							children: [item.id + 1, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "sr-only",
								children: [
									item.run === "run" ? "กำลังกด" : item.run === "pause" ? "พัก" : "หยุด",
									" ",
									item.clicks,
									" ครั้ง"
								]
							})]
						}, item.id)),
						panel.hidden ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "absolute z-40 flex size-12 items-center justify-center rounded-full bg-lime text-xs font-semibold text-lime-ink",
							style: {
								left: panel.x,
								top: panel.y
							},
							onClick: () => setPanel((current) => ({
								...current,
								hidden: false
							})),
							children: "แผง"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute z-40 rounded-xl border border-line bg-panel p-2 shadow-lg",
							style: {
								left: panel.x,
								top: panel.y,
								width: panel.mode === 0 ? 210 : panel.mode === 2 ? 292 : 250
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-h-11 flex-1 cursor-grab touch-none rounded-lg px-2 py-2 text-sm font-semibold",
											onPointerDown: onPanelDown,
											onPointerMove: onPanelMove,
											onPointerUp: () => {
												panelDrag.current = null;
											},
											children: ["กดวน", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-0.5 block text-[11px] font-normal text-fog",
												children: "ลากแถบนี้เพื่อย้ายแผง"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "min-h-11 rounded-lg border border-line px-2 text-xs",
											onClick: () => setPanel((current) => ({
												...current,
												mode: (current.mode + 1) % 3
											})),
											children: modeLabel
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "min-h-11 rounded-lg border border-line px-2 text-xs",
											onClick: () => setPanel((current) => ({
												...current,
												hidden: true
											})),
											children: "ซ่อน"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 grid grid-cols-4 gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "col-span-1 min-h-11 rounded-lg bg-lime text-xs font-semibold text-lime-ink",
											onClick: startAll,
											children: "เริ่ม"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "min-h-11 rounded-lg border border-line text-xs",
											onClick: pauseAll,
											children: "พัก"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "min-h-11 rounded-lg border border-line text-xs",
											onClick: resumeAll,
											children: "ต่อ"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "min-h-11 rounded-lg bg-ember text-xs font-semibold text-ember-ink",
											onClick: stopAll,
											children: "หยุด"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-[11px] text-fog",
									children: [running ? `กำลังกด ${clickers.filter((item) => item.run === "run").length} จุด` : paused ? "พักอยู่" : "พร้อม", durationMs > 0 && running ? ` · ${clock(leftMs)}` : ""]
								}),
								overBudget ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-[11px] text-pretty text-[#ffb15a]",
									children: "รวมกันเร็วกว่าที่เครื่องส่งแตะได้ ส่งทีละจุด ประมาณ 12 ครั้ง/วินาที จังหวะจริงจะไม่เร็วกว่านี้"
								}) : null,
								panel.mode !== 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: clsx("mt-2 space-y-2 overflow-y-auto pr-1", panel.mode === 2 ? "max-h-72" : "max-h-48"),
									children: [clickers.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg border border-line p-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "flex size-6 items-center justify-center rounded-full text-xs font-semibold text-ink",
														style: { background: COLORS[item.id] },
														children: item.id + 1
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "flex-1 text-sm",
														children: ["ตัวคลิก ", item.id + 1]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														className: "min-h-9 rounded-lg border border-line px-2 text-xs",
														onClick: () => patch(item.id, {
															enabled: !item.enabled,
															run: item.enabled ? "stop" : item.run
														}),
														children: item.enabled ? "เปิด" : "ปิด"
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-1 text-[11px] text-fog",
												children: [item.interval < effective(item.interval) ? `ตั้ง ${item.interval} ms · ส่งจริงทุก ${effective(item.interval)} ms (${cps(item.interval)} ครั้ง/วิ)` : `ทุก ${effective(item.interval)} ms · ${cps(item.interval)} ครั้ง/วิ`, item.run !== "stop" ? ` · ${item.clicks} ครั้ง` : ""]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-1 grid grid-cols-3 gap-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														className: "min-h-10 rounded-lg bg-lime text-xs font-semibold text-lime-ink disabled:opacity-40",
														disabled: !item.enabled || item.run === "run",
														onClick: () => startOne(item.id),
														children: "เริ่ม"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														className: "min-h-10 rounded-lg border border-line text-xs disabled:opacity-40",
														disabled: item.run === "stop",
														onClick: () => patch(item.id, {
															run: item.run === "pause" ? "run" : "pause",
															nextDue: Date.now()
														}),
														children: item.run === "pause" ? "ต่อ" : "พัก"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														className: "min-h-10 rounded-lg bg-ember text-xs font-semibold text-ember-ink disabled:opacity-40",
														disabled: item.run === "stop",
														onClick: () => patch(item.id, { run: "stop" }),
														children: "หยุด"
													})
												]
											}),
											panel.mode === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2 space-y-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-1",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																type: "button",
																className: "min-h-10 min-w-10 rounded-lg border border-line",
																onClick: () => patch(item.id, { interval: clampInterval(item.interval - 50) }),
																children: "−"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																"aria-label": `ช่วงเวลาตัวคลิก ${item.id + 1} มิลลิวินาที`,
																inputMode: "numeric",
																className: "h-10 w-full rounded-lg border border-line bg-ink text-center text-sm",
																value: item.interval,
																onChange: (event) => {
																	const raw = Number(event.target.value);
																	if (!Number.isFinite(raw)) return;
																	if (raw < 50) {
																		patch(item.id, { interval: raw < 0 ? 50 : raw });
																		return;
																	}
																	patch(item.id, { interval: clampInterval(raw) });
																}
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																type: "button",
																className: "min-h-10 min-w-10 rounded-lg border border-line",
																onClick: () => patch(item.id, { interval: clampInterval(item.interval + 50) }),
																children: "+"
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														"aria-label": `ความเร็วตัวคลิก ${item.id + 1}`,
														type: "range",
														min: 50,
														max: 5e3,
														step: 50,
														value: Math.min(5e3, item.interval),
														onChange: (event) => patch(item.id, { interval: clampInterval(Number(event.target.value)) })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "grid grid-cols-2 gap-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															className: clsx("min-h-10 rounded-lg border text-xs", item.continuous ? "border-lime text-lime" : "border-line text-fog"),
															onClick: () => patch(item.id, { continuous: true }),
															children: "ต่อเนื่อง"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															className: clsx("min-h-10 rounded-lg border text-xs", !item.continuous ? "border-lime text-lime" : "border-line text-fog"),
															onClick: () => patch(item.id, { continuous: false }),
															children: "ตามจำนวน"
														})]
													}),
													!item.continuous ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-1",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																type: "button",
																className: "min-h-10 min-w-10 rounded-lg border border-line",
																onClick: () => patch(item.id, { target: Math.max(1, item.target - (item.target < 20 ? 1 : 5)) }),
																children: "−"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																className: "flex-1 text-center text-sm",
																children: [item.target, " ครั้ง"]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																type: "button",
																className: "min-h-10 min-w-10 rounded-lg border border-line",
																onClick: () => patch(item.id, { target: Math.min(1e5, item.target + (item.target < 20 ? 1 : 5)) }),
																children: "+"
															})
														]
													}) : null,
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														className: "min-h-10 w-full rounded-lg border border-line text-xs",
														onClick: () => {
															setClickers((prev) => prev.filter((entry) => entry.id !== item.id));
															setNote(`ลบตัวคลิก ${item.id + 1} แล้ว`);
														},
														children: "ลบตัวนี้"
													})
												]
											}) : null
										]
									}, item.id)), panel.mode === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-2 gap-1",
										children: DURATIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setDurationMs(item.ms),
											className: clsx("min-h-10 rounded-lg border text-xs", durationMs === item.ms ? "border-lime text-lime" : "border-line text-fog"),
											children: item.label
										}, item.label))
									}) : null]
								}) : null,
								panel.mode !== 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "mt-2 min-h-11 w-full rounded-lg border border-line text-sm disabled:opacity-40",
									disabled: clickers.length >= 5,
									onClick: () => {
										if (clickers.length >= 5) {
											setFullNotice("ครบ 5 ตัวแล้ว");
											return;
										}
										addClicker();
									},
									children: clickers.length >= 5 ? "ครบ 5 ตัวแล้ว" : "เพิ่มตัวคลิก"
								}) : null,
								fullNotice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-[11px] text-[#ffb15a]",
									children: fullNotice
								}) : null
							]
						})
					]
				})]
			})
		]
	});
}
function clock(ms) {
	const sec = Math.max(0, Math.ceil(ms / 1e3));
	return `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`;
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AutoConsole, {});
}
//#endregion
export { Home as component };
