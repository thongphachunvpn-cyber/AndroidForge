//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-GIP1Fl5G.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BiKh_opw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BiKh_opw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BiMqZQwg.js"]
	}
} });
//#endregion
export { tsrStartManifest };
