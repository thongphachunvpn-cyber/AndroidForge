pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

// AndroidForge runs android/gradlew with this directory as the working
// directory. Gradle only treats that as a build when settings live here.
rootProject.name = "kodvon"
include(":app")
project(":app").projectDir = file("android/app")
