import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Hammer, c as Download, i as LoaderCircle, l as ChevronDown, o as FolderOpen, r as Square, s as ExternalLink, t as X, u as Check } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C2HMPmO6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ForgeMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 48 48",
		className,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			transform: "rotate(-38 24 24)",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "21.5",
					y: "10",
					width: "5",
					height: "26",
					rx: "1.6",
					fill: "#8b5a2b"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M14 12h20l-3 6H17l-3-6Z",
					fill: "#9eb0c2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M17 18h14v3H17z",
					fill: "#6e8496"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			transform: "rotate(40 24 24)",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "22",
					y: "14",
					width: "4.5",
					height: "22",
					rx: "1.5",
					fill: "#c4894a"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "12",
					y: "8",
					width: "24",
					height: "9",
					rx: "2",
					fill: "#4f86ad"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "14",
					y: "10",
					width: "20",
					height: "2",
					rx: "1",
					fill: "#8ec0de"
				})
			]
		})]
	});
}
var API = "https://api.github.com";
var CONN_KEY = "androidforge.conn.v1";
var RUN_KEY = "androidforge.run.v1";
var WORKFLOW_ANDROID = "build-android.yml";
var WORKFLOW_DESKTOP = "build-desktop.yml";
var UPSTREAM = "https://github.com/Professional-X/AndroidForge";
var GhError = class extends Error {
	status;
	constructor(message, status) {
		super(message);
		this.name = "GhError";
		this.status = status;
	}
};
function loadConn() {
	if (typeof window === "undefined") return null;
	try {
		const raw = localStorage.getItem(CONN_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!parsed.pat || !parsed.owner || !parsed.repo) return null;
		return parsed;
	} catch {
		return null;
	}
}
function saveConn(conn) {
	localStorage.setItem(CONN_KEY, JSON.stringify(conn));
}
function clearConn() {
	localStorage.removeItem(CONN_KEY);
	localStorage.removeItem(RUN_KEY);
}
function loadRun() {
	if (typeof window === "undefined") return null;
	try {
		const raw = localStorage.getItem(RUN_KEY);
		if (!raw) return null;
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
function saveRun(run) {
	localStorage.setItem(RUN_KEY, JSON.stringify(run));
}
function clearRun() {
	localStorage.removeItem(RUN_KEY);
}
function formatBytes(n) {
	if (!n) return "0 B";
	const units = [
		"B",
		"KB",
		"MB",
		"GB"
	];
	let i = 0;
	let value = n;
	while (value >= 1024 && i < units.length - 1) {
		value /= 1024;
		i += 1;
	}
	return `${value.toFixed(value >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}
function formatDuration(sec) {
	return `${Math.floor(sec / 60)}:${(sec % 60).toString().padStart(2, "0")}`;
}
function arrayBufferToBase64(buffer) {
	const bytes = new Uint8Array(buffer);
	const chunk = 32768;
	let binary = "";
	for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunk)));
	return btoa(binary);
}
async function gh(pat, path, init = {}) {
	const headers = new Headers(init.headers);
	headers.set("Accept", "application/vnd.github+json");
	headers.set("Authorization", `Bearer ${pat}`);
	headers.set("X-GitHub-Api-Version", "2022-11-28");
	if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
	const res = await fetch(`${API}${path}`, {
		...init,
		headers
	});
	if (res.status === 204) return void 0;
	const text = await res.text();
	let body = null;
	if (text) try {
		body = JSON.parse(text);
	} catch {
		body = text;
	}
	if (!res.ok) throw new GhError(typeof body === "object" && body && "message" in body ? String(body.message) : `GitHub returned HTTP ${res.status}`, res.status);
	return body;
}
async function hasWorkflow(pat, owner, repo) {
	try {
		await gh(pat, `/repos/${owner}/${repo}/contents/.github/workflows/${WORKFLOW_ANDROID}`);
		return true;
	} catch (error) {
		if (error instanceof GhError && error.status === 404) return false;
		throw error;
	}
}
async function detectRepo(pat, manual) {
	const user = await gh(pat, "/user");
	const override = manual?.trim().replace(/^\/+|\/+$/g, "");
	if (override) {
		const [owner, repo] = override.split("/");
		if (!owner || !repo || override.split("/").length !== 2) throw new Error("Repository must look like owner/AndroidForge.");
		if (!await hasWorkflow(pat, owner, repo)) throw new Error(`${owner}/${repo} has no ${WORKFLOW_ANDROID}. Fork ${UPSTREAM} first.`);
		return {
			owner,
			repo
		};
	}
	try {
		if ((await gh(pat, `/repos/${user.login}/AndroidForge`))?.name) return {
			owner: user.login,
			repo: "AndroidForge"
		};
	} catch (error) {
		if (!(error instanceof GhError) || error.status !== 404) throw error;
	}
	const repos = await gh(pat, "/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member");
	if (!Array.isArray(repos)) throw new Error("Could not list your repositories. The token needs the repo scope.");
	const named = repos.find((repo) => repo.name === "AndroidForge");
	if (named) return {
		owner: named.owner.login,
		repo: named.name
	};
	const scan = repos.slice(0, 40);
	for (const repo of scan) if (await hasWorkflow(pat, repo.owner.login, repo.name)) return {
		owner: repo.owner.login,
		repo: repo.name
	};
	throw new Error(`No AndroidForge workflow found. Fork ${UPSTREAM}, then detect again or type owner/repo.`);
}
async function updateRef(pat, owner, repo, branch, sha) {
	await gh(pat, `/repos/${owner}/${repo}/git/refs/heads/${branch}`, {
		method: "PATCH",
		body: JSON.stringify({
			sha,
			force: false
		})
	});
}
async function uploadAndDispatch(opts) {
	const { conn, onLog, onStatus } = opts;
	onLog("Verifying repository access…");
	onStatus("Checking repository…");
	const repoInfo = await gh(conn.pat, `/repos/${conn.owner}/${conn.repo}`);
	onLog(`${repoInfo.full_name} · branch ${repoInfo.default_branch}`);
	onStatus("Reading ZIP…");
	onLog(`Reading ${opts.fileName} (${formatBytes(opts.buffer.byteLength)})…`);
	const base64 = arrayBufferToBase64(opts.buffer);
	const safeName = opts.fileName.replace(/[^a-zA-Z0-9._-]/g, "_");
	const commitPath = `input/web-build-${Date.now()}-${safeName}`;
	const message = `Web build upload: ${opts.fileName} [AndroidForge]`;
	onStatus("Uploading source…");
	onLog("Creating blob…");
	const blob = await gh(conn.pat, `/repos/${conn.owner}/${conn.repo}/git/blobs`, {
		method: "POST",
		body: JSON.stringify({
			content: base64,
			encoding: "base64"
		})
	});
	onLog(`Blob ${blob.sha.slice(0, 7)}`);
	async function commitOnHead() {
		const ref = await gh(conn.pat, `/repos/${conn.owner}/${conn.repo}/git/refs/heads/${repoInfo.default_branch}`);
		const head = await gh(conn.pat, `/repos/${conn.owner}/${conn.repo}/git/commits/${ref.object.sha}`);
		const tree = await gh(conn.pat, `/repos/${conn.owner}/${conn.repo}/git/trees`, {
			method: "POST",
			body: JSON.stringify({
				base_tree: head.tree.sha,
				tree: [{
					path: commitPath,
					mode: "100644",
					type: "blob",
					sha: blob.sha
				}]
			})
		});
		return (await gh(conn.pat, `/repos/${conn.owner}/${conn.repo}/git/commits`, {
			method: "POST",
			body: JSON.stringify({
				message,
				tree: tree.sha,
				parents: [ref.object.sha]
			})
		})).sha;
	}
	onStatus("Committing ZIP…");
	let commitSha = await commitOnHead();
	try {
		await updateRef(conn.pat, conn.owner, conn.repo, repoInfo.default_branch, commitSha);
	} catch (error) {
		if (!(error instanceof GhError) || error.status !== 422) throw error;
		onLog("Branch moved. Retrying on the new HEAD…");
		commitSha = await commitOnHead();
		await updateRef(conn.pat, conn.owner, conn.repo, repoInfo.default_branch, commitSha);
	}
	onLog(`Committed ${commitPath} (${commitSha.slice(0, 7)})`);
	const wantAndroid = opts.target === "android" || opts.target === "all";
	const wantDesktop = opts.target !== "android";
	const desktopTarget = opts.target === "linux" || opts.target === "windows" ? opts.target : "all";
	onStatus("Starting GitHub Actions…");
	if (wantAndroid) {
		await gh(conn.pat, `/repos/${conn.owner}/${conn.repo}/actions/workflows/${WORKFLOW_ANDROID}/dispatches`, {
			method: "POST",
			body: JSON.stringify({
				ref: repoInfo.default_branch,
				inputs: {
					zip_source: "input-directory",
					zip_path: commitPath,
					zip_url: "",
					release_tag: "",
					build_variant: opts.variant,
					enable_ndk: opts.enableNdk ? "true" : "false"
				}
			})
		});
		onLog("Android workflow dispatched.");
	}
	if (wantDesktop) try {
		await gh(conn.pat, `/repos/${conn.owner}/${conn.repo}/actions/workflows/${WORKFLOW_DESKTOP}/dispatches`, {
			method: "POST",
			body: JSON.stringify({
				ref: repoInfo.default_branch,
				inputs: {
					zip_path: commitPath,
					target: desktopTarget
				}
			})
		});
		onLog(`Desktop workflow dispatched (${desktopTarget}).`);
	} catch (error) {
		if (wantAndroid && error instanceof GhError && error.status === 404) onLog("This fork has no desktop workflow. Continuing with Android.");
		else throw error;
	}
	onStatus("Waiting for the run…");
	return {
		runs: await waitForRuns(conn, repoInfo.default_branch, commitSha, onLog),
		branch: repoInfo.default_branch,
		commitPath
	};
}
async function waitForRuns(conn, branch, sha, onLog) {
	for (let attempt = 0; attempt < 8; attempt += 1) {
		await sleep(attempt === 0 ? 2500 : 2e3);
		const matches = ((await gh(conn.pat, `/repos/${conn.owner}/${conn.repo}/actions/runs?per_page=12&event=workflow_dispatch`)).workflow_runs ?? []).filter((run) => run.head_branch === branch && run.head_sha === sha);
		if (matches.length > 0) {
			for (const run of matches) onLog(`Run ${run.id} queued · ${run.name}`);
			return matches;
		}
		onLog("Still waiting for Actions to register the run…");
	}
	throw new Error("The workflow was dispatched, but the run did not appear. Check the Actions tab.");
}
async function fetchRun(conn, runId) {
	return gh(conn.pat, `/repos/${conn.owner}/${conn.repo}/actions/runs/${runId}`);
}
async function fetchSteps(conn, runId) {
	const page = await gh(conn.pat, `/repos/${conn.owner}/${conn.repo}/actions/runs/${runId}/jobs`);
	const steps = [];
	for (const job of page.jobs ?? []) for (const step of job.steps ?? []) steps.push({
		...step,
		job: job.name
	});
	return steps;
}
async function collectAssets(conn, runIds, onLog) {
	const tags = /* @__PURE__ */ new Set();
	for (const id of runIds) {
		tags.add(`web-build-output-${id}`);
		tags.add(`web-build-output-${id}-linux`);
		tags.add(`web-build-output-${id}-windows`);
	}
	for (let attempt = 1; attempt <= 8; attempt += 1) {
		const assets = [];
		for (const tag of tags) try {
			const release = await gh(conn.pat, `/repos/${conn.owner}/${conn.repo}/releases/tags/${encodeURIComponent(tag)}`);
			for (const asset of release.assets ?? []) {
				const name = asset.name.toLowerCase();
				if (name.endsWith(".apk") || name.endsWith(".aab") || name.endsWith(".tar.gz") || name.endsWith(".zip")) assets.push({
					...asset,
					releaseTag: tag
				});
			}
		} catch (error) {
			if (!(error instanceof GhError) || error.status !== 404) onLog(`${tag}: ${error instanceof Error ? error.message : "request failed"}`);
		}
		if (assets.length > 0) return assets;
		if (attempt < 8) {
			onLog(`No release files yet. Retrying (${attempt + 1}/8)…`);
			await sleep(3e3);
		}
	}
	return [];
}
function pickPrimary(assets) {
	const apks = assets.filter((asset) => asset.name.toLowerCase().endsWith(".apk"));
	if (apks.length) return apks.find((asset) => /release/i.test(asset.name)) ?? apks[0];
	const tar = assets.find((asset) => asset.name.toLowerCase().endsWith(".tar.gz"));
	if (tar) return tar;
	return assets[0];
}
function assetKind(name) {
	const lower = name.toLowerCase();
	if (lower.endsWith(".apk")) return "Android APK";
	if (lower.endsWith(".aab")) return "Android App Bundle";
	if (lower.endsWith(".tar.gz")) return "Linux bundle";
	if (lower.endsWith(".zip")) return "Windows bundle";
	return "Binary";
}
function sleep(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}
var TARGETS = [
	{
		value: "android",
		label: "Android (APK)"
	},
	{
		value: "linux",
		label: "Linux x64 (tar.gz)"
	},
	{
		value: "windows",
		label: "Windows x64 (zip)"
	},
	{
		value: "all-desktop",
		label: "All desktop (Linux + Windows)"
	},
	{
		value: "all",
		label: "All (Android + Linux + Windows)"
	}
];
var VARIANTS = [
	{
		value: "auto",
		label: "auto (try debug, then release, then bundle)"
	},
	{
		value: "debug",
		label: "debug"
	},
	{
		value: "release",
		label: "release"
	},
	{
		value: "bundle",
		label: "bundle (.aab)"
	}
];
function ForgeApp() {
	const [pat, setPat] = (0, import_react.useState)("");
	const [manualRepo, setManualRepo] = (0, import_react.useState)("");
	const [showAdvanced, setShowAdvanced] = (0, import_react.useState)(false);
	const [conn, setConn] = (0, import_react.useState)(null);
	const [detecting, setDetecting] = (0, import_react.useState)(false);
	const [file, setFile] = (0, import_react.useState)(null);
	const [dragOver, setDragOver] = (0, import_react.useState)(false);
	const [target, setTarget] = (0, import_react.useState)("android");
	const [variant, setVariant] = (0, import_react.useState)("auto");
	const [enableNdk, setEnableNdk] = (0, import_react.useState)(false);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [statusText, setStatusText] = (0, import_react.useState)("");
	const [log, setLog] = (0, import_react.useState)([]);
	const [run, setRun] = (0, import_react.useState)(null);
	const [runIds, setRunIds] = (0, import_react.useState)([]);
	const [runUrl, setRunUrl] = (0, import_react.useState)("");
	const [startedAt, setStartedAt] = (0, import_react.useState)(null);
	const [now, setNow] = (0, import_react.useState)(Date.now());
	const [steps, setSteps] = (0, import_react.useState)([]);
	const [assets, setAssets] = (0, import_react.useState)(null);
	const [resultNote, setResultNote] = (0, import_react.useState)("");
	const [resultOk, setResultOk] = (0, import_react.useState)(false);
	const logRef = (0, import_react.useRef)(null);
	const polling = (0, import_react.useRef)(null);
	const androidOnly = target === "android" || target === "all";
	function pushLog(line) {
		setLog((prev) => [...prev, line]);
	}
	(0, import_react.useEffect)(() => {
		const saved = loadConn();
		if (saved) {
			setConn(saved);
			setPat(saved.pat);
			setManualRepo(`${saved.owner}/${saved.repo}`);
		}
		const active = loadRun();
		if (saved && active && active.owner === saved.owner && active.repo === saved.repo) {
			setRunIds(active.runIds);
			setRunUrl(active.primaryUrl);
			setStartedAt(active.startedAt);
			setPhase("run");
			setStatusText("Resuming the build…");
			pushLog(`Resumed run ${active.primaryId}.`);
			startPolling(saved, active);
		}
		return () => stopPolling();
	}, []);
	(0, import_react.useEffect)(() => {
		if (phase !== "run" || !startedAt) return;
		const timer = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(timer);
	}, [phase, startedAt]);
	(0, import_react.useEffect)(() => {
		if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
	}, [log]);
	function stopPolling() {
		if (polling.current != null) {
			window.clearInterval(polling.current);
			polling.current = null;
		}
	}
	function startPolling(activeConn, saved) {
		stopPolling();
		const tick = () => void poll(activeConn, saved);
		tick();
		polling.current = window.setInterval(tick, 8e3);
	}
	async function poll(activeConn, saved) {
		try {
			const runs = await Promise.all(saved.runIds.map((id) => fetchRun(activeConn, id)));
			const primary = runs.find((item) => item.id === saved.primaryId) ?? runs[0];
			setRun(primary);
			setRunUrl(primary.html_url);
			const lists = await Promise.all(saved.runIds.map((id) => fetchSteps(activeConn, id)));
			setSteps(lists.flat());
			if (!runs.every((item) => item.status === "completed")) return;
			stopPolling();
			clearRun();
			const failed = runs.some((item) => item.conclusion !== "success");
			setPhase("done");
			setResultOk(!failed);
			if (failed) {
				const conclusion = runs.map((item) => item.conclusion ?? "unknown").join(", ");
				setResultNote(`Build finished: ${conclusion}. The Actions log has the diagnosis.`);
				pushLog(`Finished with ${conclusion}.`);
				setAssets([]);
				return;
			}
			setResultNote("Build succeeded. Fetching the release files…");
			pushLog("Build succeeded. Looking for release assets…");
			const found = await collectAssets(activeConn, saved.runIds, pushLog);
			setAssets(found);
			setResultNote(found.length ? "Build succeeded. Download is ready." : "Build succeeded, but no APK or desktop bundle was on the release yet.");
		} catch (error) {
			pushLog(error instanceof Error ? error.message : "Could not refresh the run.");
		}
	}
	async function onDetect() {
		const token = pat.trim();
		if (!token) {
			toast.error("Enter a GitHub token first.");
			return;
		}
		setDetecting(true);
		try {
			const found = await detectRepo(token, showAdvanced ? manualRepo : void 0);
			const next = {
				pat: token,
				owner: found.owner,
				repo: found.repo
			};
			saveConn(next);
			setConn(next);
			setManualRepo(`${found.owner}/${found.repo}`);
			toast.success(`Connected to ${found.owner}/${found.repo}`);
		} catch (error) {
			const message = error instanceof Error ? error.message : "Could not detect a repository.";
			toast.error(message);
		} finally {
			setDetecting(false);
		}
	}
	function onClear() {
		stopPolling();
		clearConn();
		setConn(null);
		setPat("");
		setManualRepo("");
		setFile(null);
		setPhase("idle");
		setLog([]);
		setRun(null);
		setSteps([]);
		setAssets(null);
		setStatusText("");
		toast("Token cleared from this browser.");
	}
	function takeFile(next) {
		if (!next) return;
		if (!next.name.toLowerCase().endsWith(".zip")) {
			toast.error("Choose a .zip file.");
			return;
		}
		if (next.size > 104857600) {
			toast.error(`${formatBytes(next.size)} is over the 100 MB GitHub limit.`);
			return;
		}
		setFile(next);
	}
	async function onBuild() {
		if (!conn) {
			toast.error("Connect a token first.");
			return;
		}
		if (!file) {
			toast.error("Choose a source ZIP first.");
			return;
		}
		if (file.size > 52428800) toast("Large ZIP. Encoding and upload can take a while.");
		stopPolling();
		setPhase("upload");
		setLog([]);
		setSteps([]);
		setAssets(null);
		setRun(null);
		setResultNote("");
		setStatusText("Reading ZIP…");
		try {
			const buffer = await file.arrayBuffer();
			const { runs } = await uploadAndDispatch({
				conn,
				fileName: file.name,
				buffer,
				target,
				variant,
				enableNdk,
				onLog: pushLog,
				onStatus: setStatusText
			});
			const primary = runs[0];
			const saved = {
				runIds: runs.map((item) => item.id),
				primaryId: primary.id,
				primaryUrl: primary.html_url,
				startedAt: Date.now(),
				owner: conn.owner,
				repo: conn.repo
			};
			saveRun(saved);
			setRunIds(saved.runIds);
			setRun(primary);
			setRunUrl(primary.html_url);
			setStartedAt(saved.startedAt);
			setPhase("run");
			setStatusText("Build is running on GitHub…");
			startPolling(conn, saved);
		} catch (error) {
			const message = error instanceof Error ? error.message : "Build failed to start.";
			pushLog(message);
			setStatusText(message);
			setPhase("idle");
			toast.error(message);
		}
	}
	const elapsed = startedAt ? Math.max(0, Math.floor((now - startedAt) / 1e3)) : 0;
	const progress = (0, import_react.useMemo)(() => {
		if (phase === "done") return resultOk ? 100 : 100;
		if (phase === "upload") return 12;
		if (!steps.length) return run ? 22 : 8;
		const done = steps.filter((step) => step.status === "completed").length;
		return Math.min(96, Math.max(22, Math.round(done / steps.length * 100)));
	}, [
		phase,
		resultOk,
		run,
		steps
	]);
	const primary = assets && assets.length ? pickPrimary(assets) : null;
	const badge = !run && phase === "idle" && log.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: "err",
		children: "failed"
	}) : badgeFor(run, phase);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-border bg-panel",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-3xl flex-col items-center px-5 py-8 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ForgeMark, { className: "h-11 w-11" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-4xl font-bold tracking-tight text-accent",
							children: "AndroidForge"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-md text-sm leading-6 text-muted",
						children: "Upload an Android source ZIP → we build the APK → you download it."
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex max-w-3xl flex-col gap-5 px-4 py-7 pb-24",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border border-border bg-panel p-5 sm:p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepTitle, {
								n: 1,
								title: "Connect with your GitHub token"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mb-2 block text-sm text-muted",
								htmlFor: "pat",
								children: [
									"GitHub Personal Access Token",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs",
										children: "(classic PAT with repo + workflow, or fine-grained Contents, Actions, and Releases: read and write)"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "pat",
								type: "password",
								autoComplete: "off",
								placeholder: "ghp_…",
								value: pat,
								onChange: (event) => setPat(event.target.value),
								onKeyDown: (event) => {
									if (event.key === "Enter") onDetect();
								},
								className: "w-full rounded-md border border-border-strong bg-bg px-3 py-3 font-mono text-sm text-fg",
								suppressHydrationWarning: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-xs leading-5 text-muted",
								children: [
									"The token stays in this browser (localStorage) and is sent directly to api.github.com. It never touches any other server.",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										className: "font-semibold text-accent hover:text-accent-2",
										href: "https://github.com/settings/tokens/new?scopes=repo,workflow&description=AndroidForge",
										target: "_blank",
										rel: "noreferrer",
										children: "Create a token →"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "mt-3 flex items-center gap-1 text-xs text-muted",
								onClick: () => setShowAdvanced((open) => !open),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `h-3.5 w-3.5 ${showAdvanced ? "rotate-180" : ""}` }), "Use a specific repository"]
							}),
							showAdvanced ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: manualRepo,
								onChange: (event) => setManualRepo(event.target.value),
								placeholder: "owner/AndroidForge",
								className: "mt-2 w-full rounded-md border border-border-strong bg-bg px-3 py-3 text-sm",
								"aria-label": "Repository",
								suppressHydrationWarning: true
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => void onDetect(),
										disabled: detecting,
										className: "inline-flex h-11 items-center gap-2 rounded-md bg-accent px-5 text-sm font-bold text-ink disabled:opacity-50",
										children: [detecting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : null, "Detect & save"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: onClear,
										className: "inline-flex h-11 items-center rounded-md border border-border-strong bg-panel-2 px-5 text-sm font-semibold text-fg",
										children: "Clear"
									}),
									conn ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1.5 rounded-md border border-ok bg-ok-bg px-3 py-1.5 text-xs font-medium text-ok",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" }),
											conn.owner,
											"/",
											conn.repo
										]
									}) : null
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border border-border bg-panel p-5 sm:p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepTitle, {
								n: 2,
								title: "Upload source ZIP"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								htmlFor: "zip",
								onDragOver: (event) => {
									event.preventDefault();
									setDragOver(true);
								},
								onDragLeave: () => setDragOver(false),
								onDrop: (event) => {
									event.preventDefault();
									setDragOver(false);
									takeFile(event.dataTransfer.files?.[0] ?? null);
								},
								className: `flex min-h-24 cursor-pointer flex-col items-center justify-center gap-2 rounded-md border border-dashed px-4 py-6 text-center text-sm ${file ? "border-ok text-ok" : dragOver ? "border-accent text-fg" : "border-border-strong text-muted"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: `h-5 w-5 ${file ? "text-ok" : "text-accent"}` }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: file ? `${file.name} (${formatBytes(file.size)})` : "Drop or click to choose a .zip file" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "zip",
										type: "file",
										accept: ".zip,application/zip",
										className: "sr-only",
										suppressHydrationWarning: true,
										onChange: (event) => takeFile(event.target.files?.[0] ?? null)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 grid gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm text-muted",
									htmlFor: "target",
									children: ["Target platform", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										id: "target",
										value: target,
										onChange: (event) => setTarget(event.target.value),
										className: "mt-1.5 w-full rounded-md border border-border-strong bg-bg px-3 py-3 text-sm text-fg",
										suppressHydrationWarning: true,
										children: TARGETS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: item.value,
											children: item.label
										}, item.value))
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm text-muted",
									htmlFor: "variant",
									children: [
										"Build variant ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs",
											children: "(Android only)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											id: "variant",
											value: variant,
											disabled: !androidOnly,
											onChange: (event) => setVariant(event.target.value),
											className: "mt-1.5 w-full rounded-md border border-border-strong bg-bg px-3 py-3 text-sm text-fg disabled:opacity-50",
											suppressHydrationWarning: true,
											children: VARIANTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: item.value,
												children: item.label
											}, item.value))
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-4 flex items-center gap-2 text-sm text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: enableNdk,
										disabled: !androidOnly,
										onChange: (event) => setEnableNdk(event.target.checked),
										className: "h-4 w-4 accent-accent",
										suppressHydrationWarning: true
									}),
									"Force-install NDK ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs",
										children: "(Android only)"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => void onBuild(),
									disabled: !conn || !file || phase === "upload" || phase === "run",
									className: "inline-flex h-12 items-center gap-2 rounded-md bg-accent px-5 text-sm font-bold text-ink disabled:opacity-50",
									children: [phase === "upload" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hammer, { className: "h-4 w-4" }), "Build"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted",
									children: statusText
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-xs leading-5 text-muted",
								children: [
									"The ZIP is committed to ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-fg",
										children: "input/"
									}),
									" on your fork, then GitHub Actions builds it. Fork",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										className: "text-accent hover:text-accent-2",
										href: UPSTREAM,
										target: "_blank",
										rel: "noreferrer",
										children: "Professional-X/AndroidForge"
									}),
									" ",
									"once if you have not already. Limit 100 MB."
								]
							})
						]
					}),
					phase === "run" || phase === "done" || log.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border border-border bg-panel p-5 sm:p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepTitle, {
								n: 3,
								title: "Build progress"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-3 sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "Status",
										value: badge
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "Run",
										value: runIds.length ? runIds.length > 1 ? `${runIds.length} runs` : String(runIds[0]) : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "Elapsed",
										value: startedAt ? formatDuration(elapsed) : "0:00"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 h-2 overflow-hidden rounded-full border border-border bg-bg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-accent transition-[width] duration-500",
									style: { width: `${progress}%` }
								})
							}),
							steps.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 space-y-1.5",
								children: steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-2 text-xs text-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepDot, {
										conclusion: step.conclusion,
										status: step.status
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [step.name, runIds.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-border-strong",
										children: [" · ", step.job]
									}) : null] })]
								}, `${step.job}-${step.name}-${index}`))
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
								className: "mt-4",
								open: true,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
									className: "cursor-pointer text-sm text-muted",
									children: "Live log"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
									ref: logRef,
									className: "mt-2 max-h-72 overflow-auto rounded-md border border-border bg-bg p-3 font-mono text-xs leading-5 whitespace-pre-wrap text-code",
									children: log.join("\n") || "Waiting…"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap gap-3",
								children: [runUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: runUrl,
									target: "_blank",
									rel: "noreferrer",
									className: "inline-flex h-11 items-center gap-2 rounded-md border border-border-strong bg-panel-2 px-4 text-sm font-semibold",
									children: ["Open run on GitHub", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-3.5 w-3.5" })]
								}) : null, phase === "run" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										stopPolling();
										setPhase("idle");
										setStatusText("Polling stopped. The build keeps running on GitHub.");
									},
									className: "inline-flex h-11 items-center gap-2 rounded-md border border-border-strong bg-panel-2 px-4 text-sm font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "h-3.5 w-3.5" }), "Stop polling"]
								}) : null]
							})
						]
					}) : null,
					phase === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border border-border bg-panel p-5 sm:p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepTitle, {
								n: 4,
								title: "Download"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `text-sm ${resultOk ? "text-ok" : "text-err"}`,
								children: resultNote
							}),
							runUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: runUrl,
								target: "_blank",
								rel: "noreferrer",
								className: "mt-2 inline-flex items-center gap-1 text-xs text-accent hover:text-accent-2",
								children: ["View the run", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-3 w-3" })]
							}) : null,
							primary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssetRow, {
									asset: primary,
									featured: true
								}), assets && assets.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted",
										children: [
											"All files (",
											assets.length,
											")"
										]
									}), assets.filter((asset) => asset !== primary).map((asset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssetRow, { asset }, `${asset.releaseTag}-${asset.name}`))]
								}) : null]
							}) : null
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							["Token stays here", "Saved only in localStorage and sent straight to GitHub."],
							["Your runner builds it", "Actions detects Gradle, Flutter, JDK, and NDK."],
							["Download the release", "The APK is attached to a release on your fork."]
						].map(([title, copy]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-border bg-panel px-4 py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold",
								children: title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs leading-5 text-muted",
								children: copy
							})]
						}, title))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "border-t border-border px-4 py-5 text-center text-xs text-muted",
				children: [
					"AndroidForge — build an APK from a source ZIP on your own GitHub Actions runner.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "text-accent hover:text-accent-2",
						href: UPSTREAM,
						target: "_blank",
						rel: "noreferrer",
						children: "Upstream source"
					})
				]
			})
		]
	});
}
function StepTitle({ n, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
		className: "mb-4 flex items-center gap-2 border-b border-border pb-3 text-lg font-semibold",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "inline-flex h-7 w-7 items-center justify-center rounded-full bg-accent text-sm font-extrabold text-ink",
			children: n
		}), title]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-border bg-bg px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs tracking-wide text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-base font-bold text-accent",
			children: value
		})]
	});
}
function badgeFor(run, phase) {
	if (!run && phase === "upload") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: "queued",
		children: "uploading"
	});
	if (!run) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: "queued",
		children: "queued"
	});
	if (run.status === "queued") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: "queued",
		children: "queued"
	});
	if (run.status === "in_progress" || run.status === "waiting" || run.status === "pending") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: "run",
		children: "in progress"
	});
	if (run.conclusion === "success") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: "ok",
		children: "success"
	});
	if (run.conclusion === "cancelled") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: "err",
		children: "cancelled"
	});
	if (run.conclusion === "failure") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: "err",
		children: "failed"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: "queued",
		children: run.conclusion ?? run.status
	});
}
function Pill({ children, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex rounded px-2 py-0.5 text-xs font-bold tracking-wide uppercase ${tone === "ok" ? "bg-ok-bg text-ok" : tone === "err" ? "bg-err-bg text-err" : tone === "run" ? "bg-panel-2 text-accent-2" : "bg-panel-2 text-muted"}`,
		children
	});
}
function StepDot({ conclusion, status }) {
	if (conclusion === "success") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 h-3.5 w-3.5 shrink-0 text-ok" });
	if (conclusion === "failure") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "mt-0.5 h-3.5 w-3.5 shrink-0 text-err" });
	if (conclusion === "skipped") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "mt-0.5 h-3.5 w-3.5 shrink-0 text-center text-muted",
		children: "–"
	});
	if (status === "in_progress") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mt-0.5 h-3.5 w-3.5 shrink-0 animate-spin text-accent" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-border-strong" });
}
function AssetRow({ asset, featured }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex flex-col gap-3 rounded-lg border px-4 py-3 sm:flex-row sm:items-center sm:justify-between ${featured ? "border-accent bg-panel-2" : "border-border bg-bg"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "truncate text-sm font-semibold",
				children: asset.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 text-xs text-muted",
				children: [
					formatBytes(asset.size),
					" · ",
					assetKind(asset.name),
					" · ",
					asset.releaseTag
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			href: asset.browser_download_url,
			className: `inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-md px-4 text-sm font-bold ${featured ? "bg-accent text-ink" : "border border-border-strong bg-panel-2 text-fg"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), "Download"]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ForgeApp, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		theme: "dark",
		position: "bottom-right"
	})] });
}
//#endregion
export { Home as component };
