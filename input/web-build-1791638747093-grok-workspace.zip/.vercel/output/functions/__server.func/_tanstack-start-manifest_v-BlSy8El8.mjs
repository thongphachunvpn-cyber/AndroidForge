//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BlSy8El8.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BNEe9kKP.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BNEe9kKP.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Crdi09PD.js"]
	}
} });
//#endregion
export { tsrStartManifest };
