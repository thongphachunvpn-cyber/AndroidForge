import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  Check,
  ChevronDown,
  Download,
  ExternalLink,
  FolderOpen,
  Hammer,
  LoaderCircle,
  Square,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { ForgeMark } from "@/components/forge-mark";
import {
  UPSTREAM,
  assetKind,
  clearConn,
  clearRun,
  collectAssets,
  detectRepo,
  fetchRun,
  fetchSteps,
  formatBytes,
  formatDuration,
  loadConn,
  loadRun,
  MAX_BYTES,
  pickPrimary,
  saveConn,
  saveRun,
  uploadAndDispatch,
  type Conn,
  type JobStep,
  type ReleaseAsset,
  type SavedRun,
  type Target,
  type Variant,
  type WorkflowRun,
} from "@/lib/forge";

const TARGETS: { value: Target; label: string }[] = [
  { value: "android", label: "Android (APK)" },
  { value: "linux", label: "Linux x64 (tar.gz)" },
  { value: "windows", label: "Windows x64 (zip)" },
  { value: "all-desktop", label: "All desktop (Linux + Windows)" },
  { value: "all", label: "All (Android + Linux + Windows)" },
];

const VARIANTS: { value: Variant; label: string }[] = [
  { value: "auto", label: "auto (try debug, then release, then bundle)" },
  { value: "debug", label: "debug" },
  { value: "release", label: "release" },
  { value: "bundle", label: "bundle (.aab)" },
];

type StepRow = JobStep & { job: string };

export function ForgeApp() {
  const [pat, setPat] = useState("");
  const [manualRepo, setManualRepo] = useState("");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [conn, setConn] = useState<Conn | null>(null);
  const [detecting, setDetecting] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [target, setTarget] = useState<Target>("android");
  const [variant, setVariant] = useState<Variant>("auto");
  const [enableNdk, setEnableNdk] = useState(false);
  const [phase, setPhase] = useState<"idle" | "upload" | "run" | "done">("idle");
  const [statusText, setStatusText] = useState("");
  const [log, setLog] = useState<string[]>([]);
  const [run, setRun] = useState<WorkflowRun | null>(null);
  const [runIds, setRunIds] = useState<number[]>([]);
  const [runUrl, setRunUrl] = useState("");
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [now, setNow] = useState(Date.now());
  const [steps, setSteps] = useState<StepRow[]>([]);
  const [assets, setAssets] = useState<ReleaseAsset[] | null>(null);
  const [resultNote, setResultNote] = useState("");
  const [resultOk, setResultOk] = useState(false);
  const logRef = useRef<HTMLPreElement>(null);
  const polling = useRef<number | null>(null);
  const androidOnly = target === "android" || target === "all";

  function pushLog(line: string) {
    setLog((prev) => [...prev, line]);
  }

  useEffect(() => {
    const saved = loadConn();
    if (saved) {
      setConn(saved);
      setPat(saved.pat);
      setManualRepo(`${saved.owner}/${saved.repo}`);
    }
    const active = loadRun();
    if (saved && active && active.owner === saved.owner && active.repo === saved.repo) {
      setRunIds(active.runIds);
      setRunUrl(active.primaryUrl);
      setStartedAt(active.startedAt);
      setPhase("run");
      setStatusText("Resuming the build…");
      pushLog(`Resumed run ${active.primaryId}.`);
      startPolling(saved, active);
    }
    return () => stopPolling();
    // Resume once on mount.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (phase !== "run" || !startedAt) return;
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [phase, startedAt]);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [log]);

  function stopPolling() {
    if (polling.current != null) {
      window.clearInterval(polling.current);
      polling.current = null;
    }
  }

  function startPolling(activeConn: Conn, saved: SavedRun) {
    stopPolling();
    const tick = () => void poll(activeConn, saved);
    tick();
    polling.current = window.setInterval(tick, 8000);
  }

  async function poll(activeConn: Conn, saved: SavedRun) {
    try {
      const runs = await Promise.all(saved.runIds.map((id) => fetchRun(activeConn, id)));
      const primary = runs.find((item) => item.id === saved.primaryId) ?? runs[0];
      setRun(primary);
      setRunUrl(primary.html_url);
      const lists = await Promise.all(saved.runIds.map((id) => fetchSteps(activeConn, id)));
      setSteps(lists.flat());
      const finished = runs.every((item) => item.status === "completed");
      if (!finished) return;
      stopPolling();
      clearRun();
      const failed = runs.some((item) => item.conclusion !== "success");
      setPhase("done");
      setResultOk(!failed);
      if (failed) {
        const conclusion = runs.map((item) => item.conclusion ?? "unknown").join(", ");
        setResultNote(`Build finished: ${conclusion}. The Actions log has the diagnosis.`);
        pushLog(`Finished with ${conclusion}.`);
        setAssets([]);
        return;
      }
      setResultNote("Build succeeded. Fetching the release files…");
      pushLog("Build succeeded. Looking for release assets…");
      const found = await collectAssets(activeConn, saved.runIds, pushLog);
      setAssets(found);
      setResultNote(
        found.length
          ? "Build succeeded. Download is ready."
          : "Build succeeded, but no APK or desktop bundle was on the release yet.",
      );
    } catch (error) {
      pushLog(error instanceof Error ? error.message : "Could not refresh the run.");
    }
  }

  async function onDetect() {
    const token = pat.trim();
    if (!token) {
      toast.error("Enter a GitHub token first.");
      return;
    }
    setDetecting(true);
    try {
      const found = await detectRepo(token, showAdvanced ? manualRepo : undefined);
      const next = { pat: token, owner: found.owner, repo: found.repo };
      saveConn(next);
      setConn(next);
      setManualRepo(`${found.owner}/${found.repo}`);
      toast.success(`Connected to ${found.owner}/${found.repo}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Could not detect a repository.";
      toast.error(message);
    } finally {
      setDetecting(false);
    }
  }

  function onClear() {
    stopPolling();
    clearConn();
    setConn(null);
    setPat("");
    setManualRepo("");
    setFile(null);
    setPhase("idle");
    setLog([]);
    setRun(null);
    setSteps([]);
    setAssets(null);
    setStatusText("");
    toast("Token cleared from this browser.");
  }

  function takeFile(next: File | null) {
    if (!next) return;
    if (!next.name.toLowerCase().endsWith(".zip")) {
      toast.error("Choose a .zip file.");
      return;
    }
    if (next.size > MAX_BYTES) {
      toast.error(`${formatBytes(next.size)} is over the 100 MB GitHub limit.`);
      return;
    }
    setFile(next);
  }

  async function onBuild() {
    if (!conn) {
      toast.error("Connect a token first.");
      return;
    }
    if (!file) {
      toast.error("Choose a source ZIP first.");
      return;
    }
    if (file.size > 50 * 1024 * 1024) {
      toast("Large ZIP. Encoding and upload can take a while.");
    }
    stopPolling();
    setPhase("upload");
    setLog([]);
    setSteps([]);
    setAssets(null);
    setRun(null);
    setResultNote("");
    setStatusText("Reading ZIP…");
    try {
      const buffer = await file.arrayBuffer();
      const { runs } = await uploadAndDispatch({
        conn,
        fileName: file.name,
        buffer,
        target,
        variant,
        enableNdk,
        onLog: pushLog,
        onStatus: setStatusText,
      });
      const primary = runs[0];
      const saved: SavedRun = {
        runIds: runs.map((item) => item.id),
        primaryId: primary.id,
        primaryUrl: primary.html_url,
        startedAt: Date.now(),
        owner: conn.owner,
        repo: conn.repo,
      };
      saveRun(saved);
      setRunIds(saved.runIds);
      setRun(primary);
      setRunUrl(primary.html_url);
      setStartedAt(saved.startedAt);
      setPhase("run");
      setStatusText("Build is running on GitHub…");
      startPolling(conn, saved);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Build failed to start.";
      pushLog(message);
      setStatusText(message);
      setPhase("idle");
      toast.error(message);
    }
  }

  const elapsed = startedAt ? Math.max(0, Math.floor((now - startedAt) / 1000)) : 0;
  const progress = useMemo(() => {
    if (phase === "done") return resultOk ? 100 : 100;
    if (phase === "upload") return 12;
    if (!steps.length) return run ? 22 : 8;
    const done = steps.filter((step) => step.status === "completed").length;
    return Math.min(96, Math.max(22, Math.round((done / steps.length) * 100)));
  }, [phase, resultOk, run, steps]);

  const primary = assets && assets.length ? pickPrimary(assets) : null;
  const badge =
    !run && phase === "idle" && log.length > 0 ? (
      <Pill tone="err">failed</Pill>
    ) : (
      badgeFor(run, phase)
    );

  return (
    <div className="min-h-screen bg-bg text-fg">
      <header className="border-b border-border bg-panel">
        <div className="mx-auto flex max-w-3xl flex-col items-center px-5 py-8 text-center">
          <div className="mb-3 flex items-center gap-3">
            <ForgeMark className="h-11 w-11" />
            <h1 className="text-4xl font-bold tracking-tight text-accent">AndroidForge</h1>
          </div>
          <p className="max-w-md text-sm leading-6 text-muted">
            Upload an Android source ZIP → we build the APK → you download it.
          </p>
        </div>
      </header>

      <main className="mx-auto flex max-w-3xl flex-col gap-5 px-4 py-7 pb-24">
        <section className="rounded-xl border border-border bg-panel p-5 sm:p-6">
          <StepTitle n={1} title="Connect with your GitHub token" />
          <label className="mb-2 block text-sm text-muted" htmlFor="pat">
            GitHub Personal Access Token{" "}
            <span className="text-xs">
              (classic PAT with repo + workflow, or fine-grained Contents, Actions, and Releases:
              read and write)
            </span>
          </label>
          <input
            id="pat"
            type="password"
            autoComplete="off"
            placeholder="ghp_…"
            value={pat}
            onChange={(event) => setPat(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") void onDetect();
            }}
            className="w-full rounded-md border border-border-strong bg-bg px-3 py-3 font-mono text-sm text-fg"
            suppressHydrationWarning
          />
          <p className="mt-2 text-xs leading-5 text-muted">
            The token stays in this browser (localStorage) and is sent directly to api.github.com.
            It never touches any other server.{" "}
            <a
              className="font-semibold text-accent hover:text-accent-2"
              href="https://github.com/settings/tokens/new?scopes=repo,workflow&description=AndroidForge"
              target="_blank"
              rel="noreferrer"
            >
              Create a token →
            </a>
          </p>

          <button
            type="button"
            className="mt-3 flex items-center gap-1 text-xs text-muted"
            onClick={() => setShowAdvanced((open) => !open)}
          >
            <ChevronDown className={`h-3.5 w-3.5 ${showAdvanced ? "rotate-180" : ""}`} />
            Use a specific repository
          </button>
          {showAdvanced ? (
            <input
              value={manualRepo}
              onChange={(event) => setManualRepo(event.target.value)}
              placeholder="owner/AndroidForge"
              className="mt-2 w-full rounded-md border border-border-strong bg-bg px-3 py-3 text-sm"
              aria-label="Repository"
              suppressHydrationWarning
            />
          ) : null}

          <div className="mt-4 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => void onDetect()}
              disabled={detecting}
              className="inline-flex h-11 items-center gap-2 rounded-md bg-accent px-5 text-sm font-bold text-ink disabled:opacity-50"
            >
              {detecting ? <LoaderCircle className="h-4 w-4 animate-spin" /> : null}
              Detect & save
            </button>
            <button
              type="button"
              onClick={onClear}
              className="inline-flex h-11 items-center rounded-md border border-border-strong bg-panel-2 px-5 text-sm font-semibold text-fg"
            >
              Clear
            </button>
            {conn ? (
              <span className="inline-flex items-center gap-1.5 rounded-md border border-ok bg-ok-bg px-3 py-1.5 text-xs font-medium text-ok">
                <Check className="h-3.5 w-3.5" />
                {conn.owner}/{conn.repo}
              </span>
            ) : null}
          </div>
        </section>

        <section className="rounded-xl border border-border bg-panel p-5 sm:p-6">
          <StepTitle n={2} title="Upload source ZIP" />
          <label
            htmlFor="zip"
            onDragOver={(event) => {
              event.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(event) => {
              event.preventDefault();
              setDragOver(false);
              takeFile(event.dataTransfer.files?.[0] ?? null);
            }}
            className={`flex min-h-24 cursor-pointer flex-col items-center justify-center gap-2 rounded-md border border-dashed px-4 py-6 text-center text-sm ${
              file
                ? "border-ok text-ok"
                : dragOver
                  ? "border-accent text-fg"
                  : "border-border-strong text-muted"
            }`}
          >
            <FolderOpen className={`h-5 w-5 ${file ? "text-ok" : "text-accent"}`} />
            <span>
              {file
                ? `${file.name} (${formatBytes(file.size)})`
                : "Drop or click to choose a .zip file"}
            </span>
            <input
              id="zip"
              type="file"
              accept=".zip,application/zip"
              className="sr-only"
              suppressHydrationWarning
              onChange={(event) => takeFile(event.target.files?.[0] ?? null)}
            />
          </label>

          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <label className="block text-sm text-muted" htmlFor="target">
              Target platform
              <select
                id="target"
                value={target}
                onChange={(event) => setTarget(event.target.value as Target)}
                className="mt-1.5 w-full rounded-md border border-border-strong bg-bg px-3 py-3 text-sm text-fg"
                suppressHydrationWarning
              >
                {TARGETS.map((item) => (
                  <option key={item.value} value={item.value}>
                    {item.label}
                  </option>
                ))}
              </select>
            </label>
            <label className="block text-sm text-muted" htmlFor="variant">
              Build variant <span className="text-xs">(Android only)</span>
              <select
                id="variant"
                value={variant}
                disabled={!androidOnly}
                onChange={(event) => setVariant(event.target.value as Variant)}
                className="mt-1.5 w-full rounded-md border border-border-strong bg-bg px-3 py-3 text-sm text-fg disabled:opacity-50"
                suppressHydrationWarning
              >
                {VARIANTS.map((item) => (
                  <option key={item.value} value={item.value}>
                    {item.label}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <label className="mt-4 flex items-center gap-2 text-sm text-muted">
            <input
              type="checkbox"
              checked={enableNdk}
              disabled={!androidOnly}
              onChange={(event) => setEnableNdk(event.target.checked)}
              className="h-4 w-4 accent-accent"
              suppressHydrationWarning
            />
            Force-install NDK <span className="text-xs">(Android only)</span>
          </label>

          <div className="mt-4 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => void onBuild()}
              disabled={!conn || !file || phase === "upload" || phase === "run"}
              className="inline-flex h-12 items-center gap-2 rounded-md bg-accent px-5 text-sm font-bold text-ink disabled:opacity-50"
            >
              {phase === "upload" ? (
                <LoaderCircle className="h-4 w-4 animate-spin" />
              ) : (
                <Hammer className="h-4 w-4" />
              )}
              Build
            </button>
            <span className="text-xs text-muted">{statusText}</span>
          </div>
          <p className="mt-3 text-xs leading-5 text-muted">
            The ZIP is committed to <span className="text-fg">input/</span> on your fork, then GitHub
            Actions builds it. Fork{" "}
            <a className="text-accent hover:text-accent-2" href={UPSTREAM} target="_blank" rel="noreferrer">
              Professional-X/AndroidForge
            </a>{" "}
            once if you have not already. Limit 100 MB.
          </p>
        </section>

        {phase === "run" || phase === "done" || log.length > 0 ? (
          <section className="rounded-xl border border-border bg-panel p-5 sm:p-6">
            <StepTitle n={3} title="Build progress" />
            <div className="grid gap-3 sm:grid-cols-3">
              <Stat label="Status" value={badge} />
              <Stat
                label="Run"
                value={
                  runIds.length
                    ? runIds.length > 1
                      ? `${runIds.length} runs`
                      : String(runIds[0])
                    : "—"
                }
              />
              <Stat label="Elapsed" value={startedAt ? formatDuration(elapsed) : "0:00"} />
            </div>
            <div className="mt-4 h-2 overflow-hidden rounded-full border border-border bg-bg">
              <div className="h-full bg-accent transition-[width] duration-500" style={{ width: `${progress}%` }} />
            </div>
            {steps.length > 0 ? (
              <ul className="mt-4 space-y-1.5">
                {steps.map((step, index) => (
                  <li key={`${step.job}-${step.name}-${index}`} className="flex items-start gap-2 text-xs text-muted">
                    <StepDot conclusion={step.conclusion} status={step.status} />
                    <span>
                      {step.name}
                      {runIds.length > 1 ? <span className="text-border-strong"> · {step.job}</span> : null}
                    </span>
                  </li>
                ))}
              </ul>
            ) : null}
            <details className="mt-4" open>
              <summary className="cursor-pointer text-sm text-muted">Live log</summary>
              <pre
                ref={logRef}
                className="mt-2 max-h-72 overflow-auto rounded-md border border-border bg-bg p-3 font-mono text-xs leading-5 whitespace-pre-wrap text-code"
              >
                {log.join("\n") || "Waiting…"}
              </pre>
            </details>
            <div className="mt-4 flex flex-wrap gap-3">
              {runUrl ? (
                <a
                  href={runUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex h-11 items-center gap-2 rounded-md border border-border-strong bg-panel-2 px-4 text-sm font-semibold"
                >
                  Open run on GitHub
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              ) : null}
              {phase === "run" ? (
                <button
                  type="button"
                  onClick={() => {
                    stopPolling();
                    setPhase("idle");
                    setStatusText("Polling stopped. The build keeps running on GitHub.");
                  }}
                  className="inline-flex h-11 items-center gap-2 rounded-md border border-border-strong bg-panel-2 px-4 text-sm font-semibold"
                >
                  <Square className="h-3.5 w-3.5" />
                  Stop polling
                </button>
              ) : null}
            </div>
          </section>
        ) : null}

        {phase === "done" ? (
          <section className="rounded-xl border border-border bg-panel p-5 sm:p-6">
            <StepTitle n={4} title="Download" />
            <p className={`text-sm ${resultOk ? "text-ok" : "text-err"}`}>{resultNote}</p>
            {runUrl ? (
              <a
                href={runUrl}
                target="_blank"
                rel="noreferrer"
                className="mt-2 inline-flex items-center gap-1 text-xs text-accent hover:text-accent-2"
              >
                View the run
                <ExternalLink className="h-3 w-3" />
              </a>
            ) : null}
            {primary ? (
              <div className="mt-4">
                <AssetRow asset={primary} featured />
                {assets && assets.length > 1 ? (
                  <div className="mt-3 space-y-2">
                    <p className="text-xs text-muted">All files ({assets.length})</p>
                    {assets
                      .filter((asset) => asset !== primary)
                      .map((asset) => (
                        <AssetRow key={`${asset.releaseTag}-${asset.name}`} asset={asset} />
                      ))}
                  </div>
                ) : null}
              </div>
            ) : null}
          </section>
        ) : null}

        <section className="grid gap-3 sm:grid-cols-3">
          {[
            ["Token stays here", "Saved only in localStorage and sent straight to GitHub."],
            ["Your runner builds it", "Actions detects Gradle, Flutter, JDK, and NDK."],
            ["Download the release", "The APK is attached to a release on your fork."],
          ].map(([title, copy]) => (
            <div key={title} className="rounded-xl border border-border bg-panel px-4 py-4">
              <h2 className="text-sm font-semibold">{title}</h2>
              <p className="mt-1 text-xs leading-5 text-muted">{copy}</p>
            </div>
          ))}
        </section>
      </main>

      <footer className="border-t border-border px-4 py-5 text-center text-xs text-muted">
        AndroidForge — build an APK from a source ZIP on your own GitHub Actions runner.{" "}
        <a className="text-accent hover:text-accent-2" href={UPSTREAM} target="_blank" rel="noreferrer">
          Upstream source
        </a>
      </footer>
    </div>
  );
}

function StepTitle({ n, title }: { n: number; title: string }) {
  return (
    <h2 className="mb-4 flex items-center gap-2 border-b border-border pb-3 text-lg font-semibold">
      <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-accent text-sm font-extrabold text-ink">
        {n}
      </span>
      {title}
    </h2>
  );
}

function Stat({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="rounded-md border border-border bg-bg px-3 py-3">
      <div className="text-xs tracking-wide text-muted uppercase">{label}</div>
      <div className="mt-1 text-base font-bold text-accent">{value}</div>
    </div>
  );
}

function badgeFor(run: WorkflowRun | null, phase: "idle" | "upload" | "run" | "done") {
  if (!run && phase === "upload") return <Pill tone="queued">uploading</Pill>;
  if (!run) return <Pill tone="queued">queued</Pill>;
  if (run.status === "queued") return <Pill tone="queued">queued</Pill>;
  if (run.status === "in_progress" || run.status === "waiting" || run.status === "pending") {
    return <Pill tone="run">in progress</Pill>;
  }
  if (run.conclusion === "success") return <Pill tone="ok">success</Pill>;
  if (run.conclusion === "cancelled") return <Pill tone="err">cancelled</Pill>;
  if (run.conclusion === "failure") return <Pill tone="err">failed</Pill>;
  return <Pill tone="queued">{run.conclusion ?? run.status}</Pill>;
}

function Pill({
  children,
  tone,
}: {
  children: ReactNode;
  tone: "queued" | "run" | "ok" | "err";
}) {
  const toneClass =
    tone === "ok"
      ? "bg-ok-bg text-ok"
      : tone === "err"
        ? "bg-err-bg text-err"
        : tone === "run"
          ? "bg-panel-2 text-accent-2"
          : "bg-panel-2 text-muted";
  return (
    <span className={`inline-flex rounded px-2 py-0.5 text-xs font-bold tracking-wide uppercase ${toneClass}`}>
      {children}
    </span>
  );
}

function StepDot({ conclusion, status }: { conclusion: string | null; status: string }) {
  if (conclusion === "success") return <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ok" />;
  if (conclusion === "failure") return <X className="mt-0.5 h-3.5 w-3.5 shrink-0 text-err" />;
  if (conclusion === "skipped") return <span className="mt-0.5 h-3.5 w-3.5 shrink-0 text-center text-muted">–</span>;
  if (status === "in_progress") {
    return <LoaderCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 animate-spin text-accent" />;
  }
  return <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-border-strong" />;
}

function AssetRow({ asset, featured }: { asset: ReleaseAsset; featured?: boolean }) {
  return (
    <div
      className={`flex flex-col gap-3 rounded-lg border px-4 py-3 sm:flex-row sm:items-center sm:justify-between ${
        featured ? "border-accent bg-panel-2" : "border-border bg-bg"
      }`}
    >
      <div className="min-w-0">
        <div className="truncate text-sm font-semibold">{asset.name}</div>
        <div className="mt-1 text-xs text-muted">
          {formatBytes(asset.size)} · {assetKind(asset.name)} · {asset.releaseTag}
        </div>
      </div>
      <a
        href={asset.browser_download_url}
        className={`inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-md px-4 text-sm font-bold ${
          featured ? "bg-accent text-ink" : "border border-border-strong bg-panel-2 text-fg"
        }`}
      >
        <Download className="h-4 w-4" />
        Download
      </a>
    </div>
  );
}
