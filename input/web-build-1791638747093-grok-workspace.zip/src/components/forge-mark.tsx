export function ForgeMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 48 48"
      className={className}
      aria-hidden="true"
    >
      <g transform="rotate(-38 24 24)">
        <rect x="21.5" y="10" width="5" height="26" rx="1.6" fill="#8b5a2b" />
        <path d="M14 12h20l-3 6H17l-3-6Z" fill="#9eb0c2" />
        <path d="M17 18h14v3H17z" fill="#6e8496" />
      </g>
      <g transform="rotate(40 24 24)">
        <rect x="22" y="14" width="4.5" height="22" rx="1.5" fill="#c4894a" />
        <rect x="12" y="8" width="24" height="9" rx="2" fill="#4f86ad" />
        <rect x="14" y="10" width="20" height="2" rx="1" fill="#8ec0de" />
      </g>
    </svg>
  );
}
