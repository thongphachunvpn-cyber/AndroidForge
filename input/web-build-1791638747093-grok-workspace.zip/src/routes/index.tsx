import { createFileRoute } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { ForgeApp } from "@/components/forge-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <>
      <ForgeApp />
      <Toaster theme="dark" position="bottom-right" />
    </>
  );
}
