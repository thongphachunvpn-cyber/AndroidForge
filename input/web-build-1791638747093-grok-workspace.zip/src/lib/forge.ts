const API = "https://api.github.com";
const CONN_KEY = "androidforge.conn.v1";
const RUN_KEY = "androidforge.run.v1";

export const WORKFLOW_ANDROID = "build-android.yml";
export const WORKFLOW_DESKTOP = "build-desktop.yml";
export const UPSTREAM = "https://github.com/Professional-X/AndroidForge";
export const MAX_BYTES = 100 * 1024 * 1024;

export type Target = "android" | "linux" | "windows" | "all-desktop" | "all";
export type Variant = "auto" | "debug" | "release" | "bundle";

export type Conn = {
  pat: string;
  owner: string;
  repo: string;
};

export type SavedRun = {
  runIds: number[];
  primaryId: number;
  primaryUrl: string;
  startedAt: number;
  owner: string;
  repo: string;
};

export type WorkflowRun = {
  id: number;
  name: string;
  status: string;
  conclusion: string | null;
  html_url: string;
  head_branch: string;
  head_sha: string;
  event: string;
  created_at: string;
};

export type JobStep = {
  name: string;
  status: string;
  conclusion: string | null;
};

export type ReleaseAsset = {
  name: string;
  size: number;
  browser_download_url: string;
  releaseTag: string;
};

export class GhError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = "GhError";
    this.status = status;
  }
}

export function loadConn(): Conn | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(CONN_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Conn;
    if (!parsed.pat || !parsed.owner || !parsed.repo) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function saveConn(conn: Conn) {
  localStorage.setItem(CONN_KEY, JSON.stringify(conn));
}

export function clearConn() {
  localStorage.removeItem(CONN_KEY);
  localStorage.removeItem(RUN_KEY);
}

export function loadRun(): SavedRun | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(RUN_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as SavedRun;
  } catch {
    return null;
  }
}

export function saveRun(run: SavedRun) {
  localStorage.setItem(RUN_KEY, JSON.stringify(run));
}

export function clearRun() {
  localStorage.removeItem(RUN_KEY);
}

export function formatBytes(n: number) {
  if (!n) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  let value = n;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i += 1;
  }
  return `${value.toFixed(value >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}

export function formatDuration(sec: number) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function arrayBufferToBase64(buffer: ArrayBuffer) {
  const bytes = new Uint8Array(buffer);
  const chunk = 0x8000;
  let binary = "";
  for (let i = 0; i < bytes.length; i += chunk) {
  binary += String.fromCharCode.apply(
    null,
    Array.from(bytes.subarray(i, i + chunk)),
  );
  }
  return btoa(binary);
}

async function gh<T>(pat: string, path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  headers.set("Accept", "application/vnd.github+json");
  headers.set("Authorization", `Bearer ${pat}`);
  headers.set("X-GitHub-Api-Version", "2022-11-28");
  if (init.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  const res = await fetch(`${API}${path}`, { ...init, headers });
  if (res.status === 204) return undefined as T;
  const text = await res.text();
  let body: unknown = null;
  if (text) {
    try {
      body = JSON.parse(text);
    } catch {
      body = text;
    }
  }
  if (!res.ok) {
    const message =
      typeof body === "object" && body && "message" in body
        ? String((body as { message: unknown }).message)
        : `GitHub returned HTTP ${res.status}`;
    throw new GhError(message, res.status);
  }
  return body as T;
}

async function hasWorkflow(pat: string, owner: string, repo: string) {
  try {
    await gh(
      pat,
      `/repos/${owner}/${repo}/contents/.github/workflows/${WORKFLOW_ANDROID}`,
    );
    return true;
  } catch (error) {
    if (error instanceof GhError && error.status === 404) return false;
    throw error;
  }
}

export async function detectRepo(pat: string, manual?: string) {
  const user = await gh<{ login: string }>(pat, "/user");
  const override = manual?.trim().replace(/^\/+|\/+$/g, "");
  if (override) {
    const [owner, repo] = override.split("/");
    if (!owner || !repo || override.split("/").length !== 2) {
      throw new Error("Repository must look like owner/AndroidForge.");
    }
    const ok = await hasWorkflow(pat, owner, repo);
    if (!ok) {
      throw new Error(
        `${owner}/${repo} has no ${WORKFLOW_ANDROID}. Fork ${UPSTREAM} first.`,
      );
    }
    return { owner, repo };
  }

  try {
    const direct = await gh<{ name: string }>(pat, `/repos/${user.login}/AndroidForge`);
    if (direct?.name) return { owner: user.login, repo: "AndroidForge" };
  } catch (error) {
    if (!(error instanceof GhError) || error.status !== 404) throw error;
  }

  const repos = await gh<Array<{ name: string; full_name: string; owner: { login: string } }>>(
    pat,
    "/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member",
  );
  if (!Array.isArray(repos)) {
    throw new Error("Could not list your repositories. The token needs the repo scope.");
  }

  const named = repos.find((repo) => repo.name === "AndroidForge");
  if (named) return { owner: named.owner.login, repo: named.name };

  const scan = repos.slice(0, 40);
  for (const repo of scan) {
    if (await hasWorkflow(pat, repo.owner.login, repo.name)) {
      return { owner: repo.owner.login, repo: repo.name };
    }
  }
  throw new Error(
    `No AndroidForge workflow found. Fork ${UPSTREAM}, then detect again or type owner/repo.`,
  );
}

type RefObj = { object: { sha: string } };
type CommitObj = { sha: string; tree: { sha: string } };
type TreeObj = { sha: string };
type BlobObj = { sha: string };
type RepoInfo = { full_name: string; default_branch: string };

async function updateRef(
  pat: string,
  owner: string,
  repo: string,
  branch: string,
  sha: string,
) {
  await gh(pat, `/repos/${owner}/${repo}/git/refs/heads/${branch}`, {
    method: "PATCH",
    body: JSON.stringify({ sha, force: false }),
  });
}

export async function uploadAndDispatch(opts: {
  conn: Conn;
  fileName: string;
  buffer: ArrayBuffer;
  target: Target;
  variant: Variant;
  enableNdk: boolean;
  onLog: (line: string) => void;
  onStatus: (status: string) => void;
}) {
  const { conn, onLog, onStatus } = opts;
  onLog("Verifying repository access…");
  onStatus("Checking repository…");
  const repoInfo = await gh<RepoInfo>(conn.pat, `/repos/${conn.owner}/${conn.repo}`);
  onLog(`${repoInfo.full_name} · branch ${repoInfo.default_branch}`);

  onStatus("Reading ZIP…");
  onLog(`Reading ${opts.fileName} (${formatBytes(opts.buffer.byteLength)})…`);
  const base64 = arrayBufferToBase64(opts.buffer);
  const safeName = opts.fileName.replace(/[^a-zA-Z0-9._-]/g, "_");
  const commitPath = `input/web-build-${Date.now()}-${safeName}`;
  const message = `Web build upload: ${opts.fileName} [AndroidForge]`;

  onStatus("Uploading source…");
  onLog("Creating blob…");
  const blob = await gh<BlobObj>(conn.pat, `/repos/${conn.owner}/${conn.repo}/git/blobs`, {
    method: "POST",
    body: JSON.stringify({ content: base64, encoding: "base64" }),
  });
  onLog(`Blob ${blob.sha.slice(0, 7)}`);

  async function commitOnHead() {
    const ref = await gh<RefObj>(
      conn.pat,
      `/repos/${conn.owner}/${conn.repo}/git/refs/heads/${repoInfo.default_branch}`,
    );
    const head = await gh<CommitObj>(
      conn.pat,
      `/repos/${conn.owner}/${conn.repo}/git/commits/${ref.object.sha}`,
    );
    const tree = await gh<TreeObj>(conn.pat, `/repos/${conn.owner}/${conn.repo}/git/trees`, {
      method: "POST",
      body: JSON.stringify({
        base_tree: head.tree.sha,
        tree: [{ path: commitPath, mode: "100644", type: "blob", sha: blob.sha }],
      }),
    });
    const commit = await gh<CommitObj>(conn.pat, `/repos/${conn.owner}/${conn.repo}/git/commits`, {
      method: "POST",
      body: JSON.stringify({ message, tree: tree.sha, parents: [ref.object.sha] }),
    });
    return commit.sha;
  }

  onStatus("Committing ZIP…");
  let commitSha = await commitOnHead();
  try {
    await updateRef(conn.pat, conn.owner, conn.repo, repoInfo.default_branch, commitSha);
  } catch (error) {
    if (!(error instanceof GhError) || error.status !== 422) throw error;
    onLog("Branch moved. Retrying on the new HEAD…");
    commitSha = await commitOnHead();
    await updateRef(conn.pat, conn.owner, conn.repo, repoInfo.default_branch, commitSha);
  }
  onLog(`Committed ${commitPath} (${commitSha.slice(0, 7)})`);

  const wantAndroid = opts.target === "android" || opts.target === "all";
  const wantDesktop = opts.target !== "android";
  const desktopTarget =
    opts.target === "linux" || opts.target === "windows" ? opts.target : "all";

  onStatus("Starting GitHub Actions…");
  if (wantAndroid) {
    await gh(conn.pat, `/repos/${conn.owner}/${conn.repo}/actions/workflows/${WORKFLOW_ANDROID}/dispatches`, {
      method: "POST",
      body: JSON.stringify({
        ref: repoInfo.default_branch,
        inputs: {
          zip_source: "input-directory",
          zip_path: commitPath,
          zip_url: "",
          release_tag: "",
          build_variant: opts.variant,
          enable_ndk: opts.enableNdk ? "true" : "false",
        },
      }),
    });
    onLog("Android workflow dispatched.");
  }
  if (wantDesktop) {
    try {
      await gh(conn.pat, `/repos/${conn.owner}/${conn.repo}/actions/workflows/${WORKFLOW_DESKTOP}/dispatches`, {
        method: "POST",
        body: JSON.stringify({
          ref: repoInfo.default_branch,
          inputs: { zip_path: commitPath, target: desktopTarget },
        }),
      });
      onLog(`Desktop workflow dispatched (${desktopTarget}).`);
    } catch (error) {
      if (wantAndroid && error instanceof GhError && error.status === 404) {
        onLog("This fork has no desktop workflow. Continuing with Android.");
      } else {
        throw error;
      }
    }
  }

  onStatus("Waiting for the run…");
  const runs = await waitForRuns(conn, repoInfo.default_branch, commitSha, onLog);
  return { runs, branch: repoInfo.default_branch, commitPath };
}

async function waitForRuns(conn: Conn, branch: string, sha: string, onLog: (line: string) => void) {
  for (let attempt = 0; attempt < 8; attempt += 1) {
    await sleep(attempt === 0 ? 2500 : 2000);
    const page = await gh<{ workflow_runs: WorkflowRun[] }>(
      conn.pat,
      `/repos/${conn.owner}/${conn.repo}/actions/runs?per_page=12&event=workflow_dispatch`,
    );
    const matches = (page.workflow_runs ?? []).filter(
      (run) => run.head_branch === branch && run.head_sha === sha,
    );
    if (matches.length > 0) {
      for (const run of matches) onLog(`Run ${run.id} queued · ${run.name}`);
      return matches;
    }
    onLog("Still waiting for Actions to register the run…");
  }
  throw new Error("The workflow was dispatched, but the run did not appear. Check the Actions tab.");
}

export async function fetchRun(conn: Conn, runId: number) {
  return gh<WorkflowRun>(conn.pat, `/repos/${conn.owner}/${conn.repo}/actions/runs/${runId}`);
}

export async function fetchSteps(conn: Conn, runId: number) {
  const page = await gh<{
    jobs: Array<{ name: string; steps?: JobStep[] }>;
  }>(conn.pat, `/repos/${conn.owner}/${conn.repo}/actions/runs/${runId}/jobs`);
  const steps: Array<JobStep & { job: string }> = [];
  for (const job of page.jobs ?? []) {
    for (const step of job.steps ?? []) {
      steps.push({ ...step, job: job.name });
    }
  }
  return steps;
}

export async function collectAssets(conn: Conn, runIds: number[], onLog: (line: string) => void) {
  const tags = new Set<string>();
  for (const id of runIds) {
    tags.add(`web-build-output-${id}`);
    tags.add(`web-build-output-${id}-linux`);
    tags.add(`web-build-output-${id}-windows`);
  }
  for (let attempt = 1; attempt <= 8; attempt += 1) {
    const assets: ReleaseAsset[] = [];
    for (const tag of tags) {
      try {
        const release = await gh<{
          html_url: string;
          assets: Array<{ name: string; size: number; browser_download_url: string }>;
        }>(conn.pat, `/repos/${conn.owner}/${conn.repo}/releases/tags/${encodeURIComponent(tag)}`);
        for (const asset of release.assets ?? []) {
          const name = asset.name.toLowerCase();
          if (
            name.endsWith(".apk") ||
            name.endsWith(".aab") ||
            name.endsWith(".tar.gz") ||
            name.endsWith(".zip")
          ) {
            assets.push({ ...asset, releaseTag: tag });
          }
        }
      } catch (error) {
        if (!(error instanceof GhError) || error.status !== 404) {
          onLog(`${tag}: ${error instanceof Error ? error.message : "request failed"}`);
        }
      }
    }
    if (assets.length > 0) return assets;
    if (attempt < 8) {
      onLog(`No release files yet. Retrying (${attempt + 1}/8)…`);
      await sleep(3000);
    }
  }
  return [];
}

export function pickPrimary(assets: ReleaseAsset[]) {
  const apks = assets.filter((asset) => asset.name.toLowerCase().endsWith(".apk"));
  if (apks.length) return apks.find((asset) => /release/i.test(asset.name)) ?? apks[0];
  const tar = assets.find((asset) => asset.name.toLowerCase().endsWith(".tar.gz"));
  if (tar) return tar;
  return assets[0];
}

export function assetKind(name: string) {
  const lower = name.toLowerCase();
  if (lower.endsWith(".apk")) return "Android APK";
  if (lower.endsWith(".aab")) return "Android App Bundle";
  if (lower.endsWith(".tar.gz")) return "Linux bundle";
  if (lower.endsWith(".zip")) return "Windows bundle";
  return "Binary";
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
